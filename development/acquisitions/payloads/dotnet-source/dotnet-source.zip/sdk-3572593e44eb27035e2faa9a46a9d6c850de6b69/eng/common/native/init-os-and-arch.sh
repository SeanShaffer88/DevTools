#!/bin/sh

# Use uname to determine what the OS is.
OSName=$(uname -s | tr '[:upper:]' '[:lower:]')

if command -v getprop && getprop ro.product.system.model 2>&1 | grep -qi android; then
    OSName="android"
fi

# OpenHarmony/HarmonyOS hosts report `HarmonyOS` (or `Linux` on some devices)
# from uname, so query the OHOS parameter service as well.
if command -v param >/dev/null 2>&1 && param get const.ohos.fullname 2>/dev/null | grep -qi '^openharmony'; then
    OSName="openharmony"
fi

case "$OSName" in
freebsd|linux|netbsd|openbsd|sunos|android|haiku)
    os="$OSName" ;;
harmonyos|openharmony)
    os=openharmony ;;
darwin)
    os=osx ;;
*)
    echo "Unsupported OS $OSName detected!"
    exit 1 ;;
esac

# On Solaris, `uname -m` is discouraged, see https://docs.oracle.com/cd/E36784_01/html/E36870/uname-1.html
# and `uname -p` returns processor type (e.g. i386 on amd64).
# The appropriate tool to determine CPU is isainfo(1) https://docs.oracle.com/cd/E36784_01/html/E36870/isainfo-1.html.
if [ "$os" = "sunos" ]; then
    if uname -o 2>&1 | grep -q illumos; then
        os="illumos"
    else
        os="solaris"
    fi
    CPUName=$(isainfo -n)
elif [ "$os" = "freebsd" ]; then
    # FreeBSD's `uname -m` is the machine class ("powerpc" for every PowerPC
    # variant); `uname -p` gives the specific processor (e.g. powerpc64le).
    CPUName=$(uname -p)
else
    # For the rest of the operating systems, use uname(1) to determine what the CPU is.
    CPUName=$(uname -m)
fi

case "$CPUName" in
    arm64|aarch64)
        arch=arm64
        if [ "$(getconf LONG_BIT)" -lt 64 ]; then
            # This is 32-bit OS running on 64-bit CPU (for example Raspberry Pi OS)
            arch=arm
        fi
        ;;

    loongarch64)
        arch=loongarch64
        ;;

    riscv64)
        arch=riscv64
        ;;

    amd64|x86_64)
        arch=x64
        ;;

    armv7l|armv8l)
        # shellcheck disable=SC1091
        if (NAME=""; . /etc/os-release; test "$NAME" = "Tizen"); then
            arch=armel
        else
            arch=arm
        fi
        ;;

    armv6l)
        arch=armv6
        ;;

    i[3-6]86)
        echo "Unsupported CPU $CPUName detected, build might not succeed!"
        arch=x86
        ;;

    s390x)
        arch=s390x
        ;;

    ppc64le|powerpc64le)
        arch=ppc64le
        ;;
    *)
        echo "Unknown CPU $CPUName detected!"
        exit 1
        ;;
esac
