// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

#:property RollForward=LatestMajor

// Evaluates conditional test scopes from test/ConditionalTests.props.
// It can output either the scopes to skip based on changed files and build context or the concrete
// test projects in one configured scope for targeted local validation.
//
// Usage:
//   dotnet run EvaluateConditionalTestScopes.cs -- --repo-root <path> [--target-branch <branch>] [--build-reason <reason>] [--output-variable <name>]
//   dotnet run EvaluateConditionalTestScopes.cs -- --repo-root <path> --list-test-projects <scope>
//
// When --target-branch is not provided, no scopes are skipped (safe default for local dev).
// Changed files are determined via `git diff --name-only --no-renames origin/<target-branch>...HEAD`.
// --list-test-projects expands the configured TestProjects globs and writes one repo-relative
// "Targeted test project:" line per concrete project without evaluating the git diff.
//
// Output variable format (set via ##vso when running in Azure Pipelines):
//   - Empty string: no scopes skipped, all tests run.
//   - "__all__": every defined scope is skipped.
//   - '|'-separated scope names (e.g. "TemplateEngine|ILLink"): only listed scopes are skipped.
//     '|' is used rather than ';' so the list survives Azure DevOps (which decodes '%3B' back to ';'
//     in ##vso commands) and MSBuild's /p: property-list parser. ConditionalTests.targets converts
//     '|' back to ';'.
//     The human-readable log line below ("Skipped test scopes: ...") still uses ';' for readability.

using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Xml.Linq;

var targetBranch = GetArg("--target-branch");
var buildReason = GetArg("--build-reason") ?? "";
var repoRoot = GetArg("--repo-root");
var outputVariable = GetArg("--output-variable");
var listTestProjects = GetArg("--list-test-projects");

if (string.IsNullOrEmpty(repoRoot) || !Directory.Exists(repoRoot))
{
    Console.Error.WriteLine("Error: --repo-root is required and must point to an existing directory.");
    return 1;
}
repoRoot = Path.GetFullPath(repoRoot);

var propsFile = Path.Combine(repoRoot, "test", "ConditionalTests.props");
if (!File.Exists(propsFile))
{
    Console.Error.WriteLine($"Error: ConditionalTests.props not found at expected location: {propsFile}");
    return 1;
}

// Parse ConditionalTests.props
var doc = XDocument.Load(propsFile);
var scopes = doc.Descendants("ConditionalTestScope").ToList();

// Parse GlobalTriggerPaths
var globalTriggerPaths = (doc.Descendants("GlobalTriggerPaths").FirstOrDefault()?.Value ?? "")
    .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

// Validate configuration
if (!ValidateConfiguration(repoRoot, scopes, globalTriggerPaths))
{
    return 1;
}

if (!string.IsNullOrEmpty(listTestProjects))
{
    var scope = scopes.SingleOrDefault(
        scope => string.Equals(
            scope.Attribute("Include")?.Value,
            listTestProjects,
            StringComparison.OrdinalIgnoreCase));
    if (scope is null)
    {
        Console.Error.WriteLine($"Error: Conditional test scope '{listTestProjects}' was not found.");
        return 1;
    }

    var testProjectPatterns = (scope.Element("TestProjects")?.Value ?? "")
        .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    var testProjects = Directory
        .EnumerateFiles(repoRoot, "*.csproj", SearchOption.AllDirectories)
        .Select(path => Path.GetRelativePath(repoRoot, path).Replace('\\', '/'))
        .Where(path => testProjectPatterns.Any(pattern => GlobMatches(path, pattern.Replace('\\', '/'))))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .Order(StringComparer.OrdinalIgnoreCase)
        .ToList();

    if (testProjects.Count == 0)
    {
        Console.Error.WriteLine($"Error: Conditional test scope '{listTestProjects}' did not match any test projects.");
        return 1;
    }

    foreach (var testProject in testProjects)
    {
        Console.WriteLine($"Targeted test project: {testProject}");
    }

    return 0;
}

bool isCI = buildReason is not "" and not "PullRequest";

// Get changed files via git diff
var changedFiles = GetChangedFiles(targetBranch, repoRoot);
bool hasChangedFiles = changedFiles.Count > 0;

Console.WriteLine($"Build reason: {buildReason}");
Console.WriteLine($"Target branch: {targetBranch ?? "(none)"}");
Console.WriteLine($"Is CI (non-PR): {isCI}");
Console.WriteLine($"Changed files: {changedFiles.Count}");

// Check global triggers — if any changed file matches, no scopes are skipped
bool globalTriggered = false;
if (hasChangedFiles && globalTriggerPaths.Length > 0)
{
    foreach (var changedFile in changedFiles)
    {
        var normalized = changedFile.Replace('\\', '/');
        foreach (var pattern in globalTriggerPaths)
        {
            if (GlobMatches(normalized, pattern.Replace('\\', '/')))
            {
                globalTriggered = true;
                Console.WriteLine($"Global trigger matched: '{normalized}' against '{pattern}' — no scopes skipped");
                break;
            }
        }
        if (globalTriggered)
        {
            break;
        }
    }
}

var skippedScopes = new List<string>();

// If global triggered, nothing is skipped — done
if (globalTriggered)
{
    Console.WriteLine("All scopes will run (global trigger).");
}
else
{
    foreach (var scope in scopes)
    {
        var name = scope.Attribute("Include")?.Value ?? "";
        var runAlways = (scope.Element("RunAlways")?.Value ?? "")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var triggerPaths = (scope.Element("TriggerPaths")?.Value ?? "")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        bool shouldRun = false;
        string reason = "no trigger match";

        // Check RunAlways conditions
        if (runAlways.Contains("CI", StringComparer.OrdinalIgnoreCase) && isCI)
        {
            shouldRun = true;
            reason = "RunAlways=CI";
        }
        // If no changed files info available (local dev), run everything
        else if (!hasChangedFiles)
        {
            shouldRun = true;
            reason = "no changed files (safe fallback)";
        }
        // Check if any changed file matches trigger paths
        else
        {
            foreach (var changedFile in changedFiles)
            {
                var normalized = changedFile.Replace('\\', '/');
                foreach (var pattern in triggerPaths)
                {
                    if (GlobMatches(normalized, pattern.Replace('\\', '/')))
                    {
                        shouldRun = true;
                        reason = $"matched '{normalized}' against '{pattern}'";
                        break;
                    }
                }
                if (shouldRun)
                {
                    break;
                }
            }
        }

        if (shouldRun)
        {
            Console.WriteLine($"Scope '{name}': RUN ({reason})");
        }
        else
        {
            skippedScopes.Add(name);
            Console.WriteLine($"Scope '{name}': SKIP ({reason})");
        }
    }
}

var result = skippedScopes.Count > 0 && skippedScopes.Count == scopes.Count ? "__all__"
    : skippedScopes.Count > 0 ? string.Join(";", skippedScopes)
    : "";

// Set Azure DevOps pipeline variable if running in CI and output variable was specified
if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("TF_BUILD")) && !string.IsNullOrEmpty(outputVariable))
{
    // Join with '|' as the separator (see the output-format note at the top of this file).
    var pipelineValue = result.Replace(";", "|");
    Console.WriteLine($"##vso[task.setvariable variable={outputVariable}]{pipelineValue}");
}

Console.WriteLine($"Skipped test scopes: {(result == "" ? "(none)" : result)}");
return 0;

// --- Helpers ---

static List<string> GetChangedFiles(string? targetBranch, string repoRoot)
{
    if (string.IsNullOrEmpty(targetBranch))
    {
        return [];
    }

    try
    {
        // Strip refs/heads/ prefix if present (AzDO may provide full ref)
        if (targetBranch.StartsWith("refs/heads/", StringComparison.OrdinalIgnoreCase))
        {
            targetBranch = targetBranch["refs/heads/".Length..];
        }

        var psi = new ProcessStartInfo("git", ["diff", "--name-only", "--no-renames", $"origin/{targetBranch}...HEAD"])
        {
            WorkingDirectory = repoRoot,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        var result = Process.RunAndCaptureText(psi);

        if (result.ExitStatus.ExitCode != 0)
        {
            return [];
        }

        return result.StandardOutput
            .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .ToList();
    }
    catch
    {
        return [];
    }
}

static bool GlobMatches(string path, string pattern)
{
    // Convert glob to regex: ** = any path, * = any segment chars, ? = single char
    // Handle **/ (globstar followed by separator) specially: it matches zero or more path segments.
    var regexPattern = "^" +
        Regex.Escape(pattern)
            .Replace("\\*\\*/", "@@GLOBSTAR_SLASH@@")
            .Replace("\\*\\*", ".*")
            .Replace("\\*", "[^/]*")
            .Replace("\\?", "[^/]")
            .Replace("@@GLOBSTAR_SLASH@@", "(.+/)?") +
        "$";
    return Regex.IsMatch(path, regexPattern, RegexOptions.IgnoreCase);
}

static string? GetArg(string name)
{
    var args = Environment.GetCommandLineArgs();
    for (int i = 0; i < args.Length - 1; i++)
    {
        if (args[i].Equals(name, StringComparison.OrdinalIgnoreCase))
        {
            return args[i + 1];
        }
    }
    return null;
}

static bool ValidateConfiguration(string repoRoot, List<XElement> scopes, string[] globalTriggerPaths)
{
    var errors = new List<string>();
    var scopeNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

    foreach (var scope in scopes)
    {
        var scopeName = scope.Attribute("Include")?.Value;
        if (string.IsNullOrWhiteSpace(scopeName))
        {
            errors.Add("ConditionalTestScope is missing a name (Include attribute).");
            continue;
        }

        if (!scopeNames.Add(scopeName))
        {
            errors.Add($"Conditional test scope name '{scopeName}' is duplicated. Scope names must be unique (case-insensitive).");
        }

        var triggerPaths = (scope.Element("TriggerPaths")?.Value ?? "")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var testProjects = (scope.Element("TestProjects")?.Value ?? "")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        // Validate required metadata elements exist
        var mechanism = scope.Element("Mechanism")?.Value;
        if (string.IsNullOrWhiteSpace(mechanism))
        {
            errors.Add($"Scope '{scopeName}' is missing required <Mechanism> element.");
        }
        if (triggerPaths.Length == 0)
        {
            errors.Add($"Scope '{scopeName}' is missing required <TriggerPaths> element or has no paths defined.");
        }
        if (string.Equals(mechanism, "project", StringComparison.OrdinalIgnoreCase) && testProjects.Length == 0)
        {
            errors.Add($"Scope '{scopeName}' uses Mechanism=project but is missing <TestProjects> or has no paths defined.");
        }

        // Flag unrecognized child elements (catches typos like <TriggerPath> instead of <TriggerPaths>)
        var knownElements = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "Mechanism", "TestProjects", "TriggerPaths", "RunAlways" };
        foreach (var element in scope.Elements())
        {
            if (!knownElements.Contains(element.Name.LocalName))
            {
                errors.Add($"Scope '{scopeName}' has unrecognized element <{element.Name.LocalName}>. Known elements: {string.Join(", ", knownElements)}.");
            }
        }

        foreach (var pattern in triggerPaths)
        {
            ValidatePatternBaseDir(repoRoot, pattern, $"scope '{scopeName}' TriggerPaths", errors);
        }
        foreach (var pattern in testProjects)
        {
            ValidatePatternBaseDir(repoRoot, pattern, $"scope '{scopeName}' TestProjects", errors);
        }
    }

    foreach (var pattern in globalTriggerPaths)
    {
        ValidatePatternBaseDir(repoRoot, pattern, "GlobalTriggerPaths", errors);
    }

    foreach (var error in errors)
    {
        Console.WriteLine($"##[error]{error}");
    }

    return errors.Count == 0;
}

static void ValidatePatternBaseDir(string repoRoot, string pattern, string context, List<string> errors)
{
    var normalized = pattern.Replace('\\', '/');
    var firstWildcard = normalized.IndexOfAny(['*', '?']);
    if (firstWildcard < 0)
    {
        // No glob — treat as literal path
        var fullPath = Path.Combine(repoRoot, normalized.Replace('/', Path.DirectorySeparatorChar));
        if (!File.Exists(fullPath) && !Directory.Exists(fullPath))
        {
            errors.Add($"{context}: '{pattern}' does not exist in the repo.");
        }
        return;
    }

    // Get the directory portion before the first wildcard. The wildcard may appear
    // within a path segment (e.g. "test/dotnet-format.*/**"), so trim back to the last
    // '/' to avoid treating a partial segment name as a real directory.
    var prefixBeforeWildcard = normalized[..firstWildcard];
    var lastSlash = prefixBeforeWildcard.LastIndexOf('/');
    var baseDir = lastSlash >= 0 ? prefixBeforeWildcard[..lastSlash] : "";
    if (string.IsNullOrEmpty(baseDir))
    {
        return;
    }

    var fullBaseDir = Path.Combine(repoRoot, baseDir.Replace('/', Path.DirectorySeparatorChar));
    if (!Directory.Exists(fullBaseDir))
    {
        errors.Add($"{context}: '{pattern}' — base directory '{baseDir}' does not exist in the repo.");
    }
}
