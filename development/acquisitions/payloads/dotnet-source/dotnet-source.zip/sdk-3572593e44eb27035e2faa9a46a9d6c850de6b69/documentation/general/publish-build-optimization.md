# Publish Build Optimization

## Overview

When `dotnet publish` runs, it implicitly runs a full `Build` before the publish step.
This is necessary because the SDK cannot assume the previous `dotnet build` used the same
configuration (e.g., the default build configuration is `Debug` while publish defaults to
`Release`), runtime identifier, or other settings.

However, for some publish modes, the full `Build` output (written to `bin\<config>\<tfm>\<rid>\`)
is never used by the publish pipeline. The publish steps read from intermediate outputs
(`obj\`) and resolution items, not from the `bin\` directory. This means the `Build` step
produces artifacts that are confusing to users and automation, as `bin\<config>\<tfm>\<rid>\`
contains a full self-contained managed deployment that is not the intended output.

## How Publish Modes Work Today

### Common Architecture

All publish modes share this flow:

1. **Build** (or equivalent) — produces the IL assembly at `@(IntermediateAssembly)` in `obj\`
2. **ComputeResolvedFilesToPublishList** — collects files to publish from `@(IntermediateAssembly)`,
   `@(RuntimeCopyLocalItems)`, `@(RuntimePackAsset)`, and content items
3. **Post-processing** — mode-specific transformations (ILC, ILLink, crossgen2, bundler)
4. **Copy to PublishDir** — final output written to `bin\<config>\<tfm>\<rid>\publish\`

Key insight: All post-processing steps read from `@(IntermediateAssembly)` (obj) and
`@(ResolvedFileToPublish)` (resolved from NuGet/project references), **never** from the
`Build` output directory.

### PublishAot (Native AOT)

**Status: Optimized by default in .NET 12**

- `IlcCompile` reads `@(IntermediateAssembly)` from `obj\` and produces a native binary
- The full `Build` was running a self-contained deployment to `bin\<config>\<tfm>\<rid>\`,
  including apphost, managed DLLs, deps.json, runtimeconfig.json, and runtime pack files
- **None of these files are used** by the AOT pipeline
- **Optimization**: Replace `Build` with `Compile` (plus resource/satellite targets)
- **Default**: The optimization is enabled by default in .NET 12. Set
  `UseOptimizedPublish=false` to restore full `Build` behavior.
- .NET 11 keeps the optimization opt-in to preserve compatibility.
- `UseOptimizedPublish` currently has no effect when `PublishAot` is not enabled
- `--no-build` continues to skip the build regardless of `UseOptimizedPublish`

Target chain for optimized AOT publish:
```
_CheckForInvalidConfigurationAndPlatform → BuildOnlySettings → PrepareForBuild → PreBuildEvent → ResolveReferences → PrepareResources → ResolveKeySource → Compile → CreateSatelliteAssemblies
```

`ResolveReferences` builds project references before resource preparation, and `Compile`
includes `CoreCompile`.
The optimized path retains the configuration/platform validation target and its SDK
hooks, including runtime identifier/platform compatibility and apphost/hosting checks.
`NoBuild=true` continues to use the separate no-build publish path.

After compilation and additional optimized-build targets, `IncrementalClean` records
the current intermediate outputs and removes tracked outputs that are no longer produced.
This also removes obsolete managed build-directory outputs from an earlier full build.
If the optimized build fails, `_CleanRecordFileWrites` preserves prior and newly generated
file tracking without deleting stale outputs. A subsequent `dotnet clean` can remove the
tracked compiler outputs, including intermediate DLL, PDB, and generated XML documentation.
This retains build cleanup bookkeeping; it does not add tracking for every native compiler
or publish artifact.

For tool projects (`PackAsTool=true`) with explicit `PackAsToolShimRuntimeIdentifiers`,
the PackTool SDK adds `GenerateShimsAssets` to the optimized-build extension point.
Shims are generated before incremental cleanup and publish file collection, so requested
`publish\shims\<rid>\` assets are preserved without copying the managed deployment to
the build directory. Projects without requested shims do not add this step, and no-build
publish continues to locate and reuse shims from a previous build rather than generate them.
Generation, incremental-build discovery, and no-build discovery share the staging directory
`$(PackagedShimOutputRootDirectory)\shims\$(TargetFramework)\`. It does not depend on
`SelfContained`, which can be inferred differently during build and publish. This allows
both Build and optimized publish outputs to be reused by a subsequent no-build publish.
Relative staging roots, including the default `$(OutDir)`, are resolved against the
project directory rather than the MSBuild process working directory.

### PublishTrimmed (IL Trimming)

**Status: Not yet optimized — candidate for future optimization**

- `ILLink` (the IL trimmer) processes `@(ResolvedFileToPublish)` items marked with
  `PostprocessAssembly=true`
- These items come from `ComputeResolvedFilesToPublishList` which reads from
  `@(IntermediateAssembly)` (obj) and resolved references
- The `Build` output in `bin\` is not consumed by the trimmer
- The same `Compile`-based optimization would apply here

### PublishReadyToRun (R2R / Crossgen2)

**Status: Not yet optimized — candidate for future optimization**

- `RunCrossgen2` processes `@(ResolvedFileToPublish)` items
- Input assemblies come from resolution, not from `Build` output
- Same optimization opportunity as trimming

### PublishSingleFile (Single-File Bundling)

**Status: Not yet optimized — candidate for future optimization**

- `GenerateSingleFileBundle` bundles `@(ResolvedFileToPublish)` items into one executable
- All inputs come from resolved items and `@(IntermediateAssembly)`
- Same optimization opportunity

### Combined Modes

These modes can be combined (e.g., `PublishAot` implies `PublishTrimmed`). The optimization
applies when the outermost mode is optimized:

| Combination | Optimized? | Notes |
|---|---|---|
| PublishAot (implies trimmed) | ✅ Yes | Set `UseOptimizedPublish=false` to opt out |
| PublishTrimmed + PublishSingleFile | ❌ Not yet | Future candidate |
| PublishReadyToRun + PublishSingleFile | ❌ Not yet | Future candidate |
| PublishTrimmed alone | ❌ Not yet | Future candidate |
| PublishReadyToRun alone | ❌ Not yet | Future candidate |

## Default Behavior: AOT Publish Build Optimization

### What Changed

Starting in .NET 12, `dotnet publish` with `PublishAot=true` no longer runs a full `Build`
before publish. Instead, it runs only `Compile` (and resource/satellite assembly targets).
.NET 11 preserves full `Build` behavior by default and requires
`UseOptimizedPublish=true` to enable the optimization.

### Impact

- **BeforeBuild / AfterBuild targets**: These will not execute during AOT publish. If you have
  custom targets attached to `BeforeBuild`, `AfterBuild`, or using
  `BeforeTargets="Build"` / `AfterTargets="Build"`, they will not run.
  - **Workaround**: Attach your targets to `BeforeTargets="Publish"` / `AfterTargets="Publish"`,
    or to `BeforeTargets="Compile"` / `AfterTargets="Compile"` instead.
- **PreBuildEvent / PostBuildEvent**: `PreBuildEvent` still executes when the optimization
  is enabled; `PostBuildEvent` is skipped. Both are skipped with `--no-build`.
- **Third-party NuGet Build hooks**: Targets from NuGet packages that hook into `Build` will be
  skipped (consistent with `--no-build` behavior).
- **Output directory**: `bin\<config>\<tfm>\<rid>\` will no longer contain managed apphost,
  DLLs, deps.json, runtimeconfig.json, or runtime pack files. Only `native\` and `publish\`
  subdirectories will be present, along with `shims\` for explicitly requested tool shims.

### Opt-Out

To restore the previous behavior of running a full `Build` before AOT publish, set:

```xml
<PropertyGroup>
  <UseOptimizedPublish>false</UseOptimizedPublish>
</PropertyGroup>
```

Or pass it on the command line:

```
dotnet publish /p:UseOptimizedPublish=false
```

## Future Work

The same optimization could be applied to `PublishTrimmed`, `PublishReadyToRun`, and
`PublishSingleFile` modes, as they all share the same architecture of reading from
`@(IntermediateAssembly)` and resolved references rather than `Build` output. Each mode
would need:

1. Compatibility analysis for Build hooks used by projects and NuGet packages
2. The same target chain: `BuildOnlySettings → PrepareForBuild → PrepareResources → Compile → CreateSatelliteAssemblies`
3. Tests verifying the expected build and publish outputs
4. Documentation of the breaking change for that mode
