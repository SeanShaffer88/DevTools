# `dotnetup env` command design (replaces `dotnetup defaultinstall`)

## Problem

`dotnetup defaultinstall <user|system>` is misnamed and under-specified:

- It's not really about a "default install" — it's about how `dotnet` ends up on your `PATH` and what `DOTNET_ROOT` points at.
- The argument values `user` / `system` mean different things on Windows vs Unix today:
  - Windows `user` ≈ user PATH + `DOTNET_ROOT` (registry-level env vars)
  - Windows `system` ≈ admin PATH + `DOTNET_ROOT`
  - Unix `user` ≈ shell profile, dotnet enabled
  - Unix `system` ≈ shell profile, dotnetup only (no `DOTNET_ROOT`)
- It doesn't persist `DotnetAccessMode` in `dotnetup.config.json`, even though the `init`
  walkthrough writes that exact preference (see `DotnetupConfig.DotnetAccessMode`).
- It pre-dates the PowerShell-profile-on-Windows work, so it doesn't know that
  shell-profile mode is now a valid Windows option.

## Goals

1. Replace `defaultinstall` with a clearly-named command whose argument values map 1:1
   to the renamed `DotnetAccessMode`.
2. Always persist the chosen mode to `DotnetupConfig` so re-runs and the init flow stay
   consistent.
3. **Support re-sync**: re-running `env set <same-mode>` re-applies the mode without
   needing to remember any extra state — useful when something else has clobbered
   the env vars dotnetup manages. The mode is stored in `dotnetup.config.json` and
   shown by `env show`, so the user doesn't need to remember it.
4. Make the command idempotent: running it again with the same mode is a no-op,
   switching modes correctly undoes the previously applied changes.
5. Manage **whether `dotnetup` itself is on `PATH`** as a first-class, persisted setting
   that is orthogonal to the dotnet-access mode — so the install script only has to
   download `dotnetup`, and running `dotnetup` manages its own `PATH` entry. See
   [`dotnetup` on PATH: an orthogonal setting](#dotnetup-on-path-an-orthogonal-setting).

## Non-goals

- Adding a way to inspect / change which *shell* the profile gets written to beyond the
  existing `--shell` option.
- Backwards-compat alias for `defaultinstall`. Clean rename.

## Proposal

Replace `dotnetup defaultinstall <user|system>` with a noun-verb `env` command family
backed by a renamed three-value `DotnetAccessMode` enum:

```
dotnetup env set <none|shell|everywhere>   # persist mode in config and apply
dotnetup env show                   # display current mode; if applied state has
                                    # drifted from the configured mode, report that
                                    # too
dotnetup env script                 # print a shell-specific script that exports
                                    # PATH/DOTNET_ROOT for the current dotnet
                                    # install (formerly `dotnetup print-env-script`)
dotnetup env clear                  # remove all dotnetup environment wiring
```

`env set` is idempotent — running it again with the same mode is a no-op (and is also
how you re-sync after something else has clobbered your PATH; see the key scenario
below).

Modes:

- `none` — Don't modify your environment; use `dotnetup dotnet` to invoke.
- `shell` — Wire dotnetup into your shell's profile file (only shells that load
  profiles see the user dotnet).
- `everywhere` — Wire dotnetup into your shell profile, put the managed dotnet on the
  Windows system `PATH`, and set user-level `DOTNET_ROOT` so cmd.exe, IDEs, shortcuts,
  and framework-dependent apphosts also see it.

`DotnetAccessMode` enum renames 1:1: `None` / `Shell` / `Everywhere`. JSON serialization
follows.

A second, orthogonal setting — whether `dotnetup` itself is on `PATH` — is described in
[`dotnetup` on PATH: an orthogonal setting](#dotnetup-on-path-an-orthogonal-setting)
below. It is still under discussion.

Apply logic lives in a shared `DotnetAccessModeApplier` helper so that `dotnetup init`
and `dotnetup env set` go through the same code path. The walkthrough refactors in
#53838 / #53837 then only need to change the question-asking layer, not the apply
layer.

The existing top-level `dotnetup print-env-script` command moves under the `env`
family as `dotnetup env script` (it generates env-var wiring — same domain). To
avoid breaking managed profile blocks written by previous dotnetup versions, the
old `print-env-script` name is kept as a hidden top-level alias.

The rest of this document explains the reasoning behind each choice and the
alternatives considered.

## Key scenario: re-sync after a system .NET update overwrites the system PATH

A user has chosen `Shell` mode. In `Shell` mode dotnetup writes the user dotnet path
only to the user's shell profile. That means **only PowerShell** sees the user
dotnet on PATH — the profile prepends the user dotnet path to `$env:PATH`. `cmd.exe`
reads no profile, so from cmd `dotnet` still resolves to whatever the Windows
system/user env-var `PATH` says, which on a typical box is the admin-installed
`C:\Program Files\dotnet\`.

To make `cmd.exe` (and GUI apps, IDE shortcuts launched from Start menu, etc.) see
the user dotnet, the user picks `Everywhere` mode. That mode inserts the user dotnet path
in the Windows system `PATH` immediately before the Program Files dotnet path and sets
user-level `DOTNET_ROOT`, **in addition to** writing the shell profile.

Later, a system .NET SDK or runtime installer runs (for example, via a Visual Studio
update). If its installer rewrites the system `PATH` and removes or reorders dotnetup's
entry, the Program Files dotnet path can take precedence again.

The fix: rerun `dotnetup env set everywhere`. This restores the dotnetup entry immediately
before the Program Files dotnet entry. Because `env set` is idempotent, this works whether
the mode was already applied or not.

The mode the user picked is stored in `dotnetup.config.json` and is shown by
`dotnetup env show`, so the user doesn't need to remember it.

## Naming the noun

We use `env` as the command noun.  It doesn't just manage manage `PATH` — it also
writes `DOTNET_ROOT` and (in the "everywhere" mode) edits the Windows env-var registry.

## Naming the modes: `None / Shell / Everywhere`

```
DotnetAccessMode.None       // dotnetup doesn't wire anything; user invokes via `dotnetup dotnet`
DotnetAccessMode.Shell      // write to the shell's profile file only
DotnetAccessMode.Everywhere // shell profile + Windows system PATH + user DOTNET_ROOT
```

Why these names:

- `None` — unambiguous; matches the `dotnetup defaultinstall none` reading.
- `Shell` — more recognizable than `Profile`. PowerShell users know `$PROFILE` but
  Unix newcomers may not parse "profile" without explanation. "Shell" is the
  user-visible thing it affects.
- `Everywhere` — captures "all shells and apps see it", parallel to `None`. It also reads
  as powerful and cautionary, which fits a mode that edits machine-visible env vars. Avoids:
  - `System` — collides with "system .NET install" (admin MSI in `C:\Program Files`).
  - `Global` — collides with `dotnet tool install --global`.
  - `Env` — would be `env set env` (awful given the chosen noun).
  - `Full` — fine, and slightly shorter, but less descriptive of *what* it does and
    doesn't signal caution the way `Everywhere` does.

Help text writes itself:

- `none` — Don't modify your environment; use `dotnetup dotnet` to invoke.
- `shell` — Wire dotnetup into your shell's profile file.
- `everywhere` — Wire dotnetup into your shell profile, put the managed dotnet on the
  Windows system `PATH`, and set user-level `DOTNET_ROOT`.

### Renamed `DotnetAccessMode` enum

```
DotnetAccessMode.None       = old DotnetupDotnet       // no PATH wiring
DotnetAccessMode.Shell      = old ShellProfile         // shell profile file only
DotnetAccessMode.Everywhere = old FullPathReplacement  // env-var PATH + shell profile
```

The JSON serialization writes the new lowercase names (`none` / `shell` / `everywhere`)
via the built-in string-enum converter (camel-case, integer values rejected). Legacy
spellings from earlier internal builds (`full` / `fullpathreplacement`, and the old
`pathPreference` property) are **not** accepted: an unrecognized value is treated as a
corrupt config, which re-defaults on the next write rather than silently mapping to a mode.

## `dotnetup` on PATH: an orthogonal setting

### The problem this solves

The `env` mode above governs how the **managed dotnet** is surfaced. But there is a
second, separate concern tangled into the same mechanism today: whether **`dotnetup`
itself** is on `PATH`.

Previously, in `Shell` / `Everywhere` mode the managed profile block prepended the dotnetup
directory to `PATH`. In `None` mode the block was removed entirely — which also dropped
`dotnetup` from `PATH`. That is incoherent precisely for `None`, whose whole point is
"invoke .NET via `dotnetup dotnet`": that workflow is impossible unless `dotnetup` is
discoverable on `PATH`.

The get-dotnetup install script also has some logic for the PATH: it prints/sets a `PATH`
entry for the dotnetup dir. However, we don't want to rely on the install script for this.
**The install script should only download `dotnetup`; running `dotnetup` should manage its
own `PATH` entry.** That makes `dotnetupOnPath` a first-class, consistently-managed setting
rather than an install-time side effect.

### The model: two orthogonal settings, one derived mechanism

| Setting | Values | Meaning |
| --- | --- | --- |
| **`accessMode`** (dotnet access) | `none` / `shell` / `everywhere` | How the managed **dotnet** is surfaced (the modes above). |
| **`dotnetupOnPath`** (dotnetup discoverability) | `true` / `false` | Whether the **dotnetup** executable directory is on `PATH` so `dotnetup` can be invoked. |

`dotnetupOnPath` is orthogonal to all three `accessMode` values
and, while installed, is normally on.

**Whether the profile contains a dotnetup-managed section at all is *derived*, not a
third user-facing knob.** The managed block is a single call to `dotnetup env script`
(e.g. `eval "$(dotnetup env script …)"` on Unix; the PowerShell equivalent on Windows).
There are not separate "dotnet" and "dotnetup" lines — the **arguments passed to
`env script`** determine what the generated script wires, and the two settings map onto
those arguments:

- The generated script **wires dotnet** (`DOTNET_ROOT` + the managed dotnet on `PATH`)
  iff `accessMode ∈ {shell, everywhere}`.
- The generated script **adds the dotnetup directory to `PATH`** iff
  `dotnetupOnPath = true` (Unix).
- If neither applies (`accessMode = none` **and** `dotnetupOnPath = false`) → there is nothing
  for the script to do, so the managed block is removed entirely.

These two aspects are the existing `includeDotnet` and dotnetup-dir inputs to
`GenerateEnvScript`. The `env script` surface expresses them as two selection flags,
`--dotnet` and `--dotnetup` (see [`env script` flag surface](#env-script-flag-surface)).
The applier bakes the explicit flags into the profile block at apply time, so the
persisted block is deterministic and never depends on the command's default.

Exposing "touch the profile at all" as a separate setting would add a knob that is only
meaningful on Windows (where `dotnetupOnPath` uses the user `PATH` env var and needs no
profile), so we keep it derived to avoid complexity.

### Mechanism per OS

- **Unix:** the managed block is one `env script` call whose arguments select whether it
  wires dotnet and whether it adds the dotnetup directory. `dotnetupOnPath = false` drops
  the dotnetup-dir argument; the block is removed only when the script would wire nothing.
- **Windows:** `dotnetupOnPath` is written to the **user `PATH` env var** (so cmd,
  PowerShell, and GUI-launched apps all see it — not only PowerShell). For simplicity
  the PowerShell profile block **also** includes the dotnetup directory (driven by the
  same `env script` arguments as Unix), even though that is redundant with the user
  `PATH` entry inside PowerShell. The duplication is harmless — both entries point at the
  same directory — and it keeps profile generation identical across operating systems.
  Consequences: clearing `dotnetupOnPath` must remove it from **both** places on Windows
  (the profile's `env script` arguments and the user `PATH` entry), and `env show` drift
  detection treats the **user `PATH` env var as authoritative** for `dotnetupOnPath` on
  Windows (the profile copy is just a convenience).

Because dotnetup has no `uninstall` command, **`dotnetupOnPath = false` is the way to
remove `dotnetup` from `PATH`** — it removes the Unix profile line and the Windows user
`PATH` entry.

### Config schema

```jsonc
{
  "schemaVersion": "1",
  "accessMode": "shell",   // renamed from "pathPreference"
  "dotnetupOnPath": true   // new; defaults to true when absent
}
```

No `schemaVersion` bump. Builds have shipped **internally** with the original shape
(`pathPreference` + the pre-rename enum spellings `DotnetupDotnet` / `ShellProfile` /
`FullPathReplacement`). No config files have shipped publicly, so rather than a migration the
reader simply does not honor the legacy shape:

- The legacy `pathPreference` property name is ignored (an unknown property does not crash), so
  `accessMode` falls back to its default (`shell`).
- Only the current `accessMode` values `none` / `shell` / `everywhere` (case-insensitive) are
  accepted; a pre-rename enum spelling is treated as a corrupt value.
- A missing `dotnetupOnPath` defaults to `true`.

Either way, the next write rewrites the file in the new shape, so a handful of internal configs
re-default once instead of carrying a stream-manipulating compatibility shim indefinitely. Because
no config files have shipped publicly, `schemaVersion` stays `"1"`.

### Command UI (recommended)

Keep everything under the `env` noun. Dotnet access stays the positional argument (the
primary axis); `dotnetupOnPath` is an option. A bare `env set` re-syncs the stored
config.

```
dotnetup env set <none|shell|everywhere>                     # set dotnet access, leave dotnetupOnPath as-is
dotnetup env set --dotnetup-on-path <true|false>      # change only dotnetupOnPath
dotnetup env set <mode> --dotnetup-on-path <true|false> # set both at once
dotnetup env set                                      # no args: re-apply stored config (fix drift)
dotnetup env clear                                    # fully unwire: == env set none --dotnetup-on-path false
dotnetup env show                                     # report both axes + drift
dotnetup env script                                   # unchanged
```

Examples:

```
dotnetup env set shell                       # dotnet on shell PATH; dotnetup stays on PATH
dotnetup env set none                        # stop exposing dotnet; keep `dotnetup` runnable
dotnetup env set --dotnetup-on-path false    # remove dotnetup from PATH (the "unset", any mode)
dotnetup env set none --dotnetup-on-path false # fully unwire everything
dotnetup env clear                           # same as the line above; the "undo everything" verb
```

`env clear` is the one verb that removes *everything* dotnetup wired into the
environment — it sets `env = none` **and** `dotnetupOnPath = false`, leaving no managed
profile block and no dotnetup `PATH` entry. It is the closest thing to an "env uninstall"
given dotnetup has no `uninstall` command. (This is distinct from the rejected `env reset`
shortcut discussed below, which would only have aliased `env set none` and left dotnetup
on `PATH`.)

`env show`, in sync:

```
dotnetup environment:
  dotnet access    shell      managed dotnet is added to your shell profile
  dotnetup on PATH   yes        via ~/.bashrc

In sync.
```

`env show`, with drift:

```
dotnetup environment:
  dotnet access    shell
  dotnetup on PATH   yes
  ⚠ drift:
    - shell profile is missing the managed dotnet lines
  Run 'dotnetup env set' to re-sync.
```

**Alternative UI considered:** two sibling verbs — `env set <none|shell|everywhere>` for
dotnet and `env dotnetup-path <true|false>` for dotnetup. Cleaner orthogonality, but two
verbs to discover and a less-obvious bare re-sync. Current lean is the single-`set`
form above.

### `env script` flag surface

`env script` keeps its two stable auxiliary options — `--shell <name>` (which provider)
and `--dotnet-install-path | -d <path>` (which install to wire) — and gains two
**selection flags** for *what* the generated script wires:

| Invocation | Generated script wires |
| --- | --- |
| `env script` (no selection) | follows the stored config (`accessMode` → dotnet, `dotnetupOnPath` → dotnetup); both when no config exists yet |
| `env script --dotnet --dotnetup` | both (explicit — what the applier bakes into profiles) |
| `env script --dotnetup` | dotnetup only |
| `env script --dotnet` | dotnet only |
| `env script --dotnetup-only` | dotnetup only (hidden legacy alias for `--dotnetup`) |

Semantics are a **selection set**: passing any of `--dotnet` / `--dotnetup` emits **only** the
listed parts. With no selection flag the script follows the stored config, so a human typing
`eval "$(dotnetup env script)"` activates their configured setup; when no config exists yet it
falls back to wiring both (the back-compat behavior the legacy `print-env-script` profile blocks
rely on). Help text states this explicitly so `--dotnet` isn't misread as additive: *"By default
the script follows your configured env settings. Pass `--dotnet` and/or `--dotnetup` to emit only
the parts you list."*

- **Profiles are always explicit.** The applier bakes `--dotnet --dotnetup`,
  `--dotnetup`, or `--dotnet` (never relying on the default), so a persisted block is
  deterministic and unaffected by any future change to the default.
- **`--dotnetup-only` stays as a hidden legacy alias** for `--dotnetup`, so managed
  blocks written by older dotnetup versions (which call the hidden `print-env-script`
  alias with `--dotnetup-only`) keep working through the compat window, then it's
  removed. Combining `--dotnetup-only` with `--dotnet`/`--dotnetup` is contradictory and
  is rejected with an error; in practice only old profiles emit it and never in
  combination.
- "Neither" is not an expressible state — when a mode would wire nothing, the applier
  removes the managed block instead of emitting an empty `env script` call.

### Composition table (what actually gets written)

| `env` | `dotnetupOnPath` | Unix profile (`env script` wires) | Windows user `PATH` | Windows system `PATH` / user `DOTNET_ROOT` | Windows profile (`env script` wires) |
| --- | --- | --- | --- | --- | --- |
| none | true | dotnetup only | dotnetup | — | dotnetup only |
| none | false | (block removed) | — | — | (block removed) |
| shell | true | dotnetup + dotnet | dotnetup | — | dotnetup + dotnet |
| shell | false | dotnet only | — | — | dotnet only |
| everywhere | true | n/a (`everywhere` is Windows-only) | dotnetup | managed dotnet / managed root | dotnetup + dotnet |
| everywhere | false | n/a (`everywhere` is Windows-only) | — | managed dotnet / managed root | dotnet only |

The Unix and Windows profile columns are driven by the same `env script` arguments
(identical wherever both platforms support the mode; `everywhere` is Windows-only). The Windows
user `PATH` column controls whether dotnetup itself is discoverable. In `everywhere`, the
managed dotnet is instead inserted into the system `PATH`, while `DOTNET_ROOT` is set at
user scope.

### Open questions

1. **UI shape** *(resolved)*: a flag on `env set` (single-verb model), not a separate
   `env dotnetup-path` verb. dotnet access stays the positional; `dotnetupOnPath` is the
   `--dotnetup-on-path` option.
2. **Option spelling** *(resolved)*: value form `--dotnetup-on-path <true|false>` (explicit,
   script-friendly, and absent = leave unchanged), not a `--no-` flag pair. Accepted as
   the best option despite being slightly verbose — it's an uncommon operation, and the
   `dotnetup-` prefix usefully signals it's about dotnetup itself rather than dotnet.
   (`--self-on-path <true|false>` was considered as a terser form; rejected for being more
   jargon-y.)
3. **Config rename** *(resolved)*: rename `pathPreference` → `accessMode`. The legacy shape is not
   carried forward: the old `pathPreference` property name is ignored and the pre-rename enum
   spellings are not accepted. Since only internal preview builds wrote them, an old config simply
   re-defaults to `shell` on the next write rather than requiring a compatibility shim.
4. **Init prompt** *(resolved)*: keep the silent default `dotnetupOnPath = true`. We are
   **not** touching the init walkthrough UI in this PR; a dedicated prompt can be added
   later (likely will be), but it's out of scope here.
5. **`env script` flag surface** *(resolved — see [`env script` flag surface](#env-script-flag-surface))*:
   two selection flags `--dotnet` / `--dotnetup`; no selection follows the stored config
   (falling back to both when no config exists); profiles bake explicit flags; `--dotnetup-only`
   retained as a hidden legacy alias for `--dotnetup` during the `print-env-script` compat window.

## Command shape: alternatives considered

Why not the obvious extensions:

- `env apply` (re-apply current config without changing it) — equivalent to
  rerunning `env set <same-mode>`. `env show` tells you the mode if you've
  forgotten. Skipped to keep the verb surface minimal.
- `env reset` — one-token shortcut for `env set none`. Skipped for the same reason.
  Note this is *not* the same as `env clear` (which is kept): `reset` would have left
  dotnetup on `PATH`, whereas `env clear` also clears `dotnetupOnPath`, fully unwiring
  the environment.

Either can be added later without breaking the v1 surface.

Alternative command shapes considered and rejected:

| Syntax                                                          | Why not                                                            |
| --------------------------------------------------------------- | ------------------------------------------------------------------ |
| `dotnetup configure-env [<mode>]`                               | Flat, no verb family; verb-led breaks noun-verb convention.        |
| `dotnetup config set env <mode>` / `dotnetup config apply`      | git-style; lower-level feel; not the dotnetup CLI's style.         |
| `dotnetup enable <mode>` / `disable` / `refresh` / `status`     | `enable`/`disable` overload heavily with channel install verbs.    |
| `dotnetup path set <mode>` / `path show`                        | `path` is narrower than what we do (DOTNET_ROOT, profile script).  |
