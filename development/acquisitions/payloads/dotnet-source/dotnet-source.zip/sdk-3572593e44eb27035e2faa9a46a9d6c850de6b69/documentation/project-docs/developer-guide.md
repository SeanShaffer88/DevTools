Developer Guide
===============

## Prerequisites

In order to build and test the .NET Core Command-line Interface (CLI), you need the following installed on you machine:

### For Windows

1. git (available from the [Git Website](http://www.git-scm.com/)) on the PATH.
2. Visual Studio "Desktop development with C++" workload with all defaults (see [Native AOT prerequisites](https://learn.microsoft.com/dotnet/core/deploying/native-aot/?tabs=windows%2Cnet8#prerequisites)).

### For Linux

1. git (available from your package manager or the [Git Website](http://www.git-scm.com/)) on the PATH.

### For macOS

1. git (available from [Homebrew](https://brew.sh) or the [Git Website](http://www.git-scm.com/)) on the PATH.

## Building

### Windows

Run the following command from the root of the repository:

```
build.cmd
```

The build script will output a `dotnet` installation to `artifacts\bin\redist\Debug\dotnet` that will include any local changes to the .NET Core CLI.

As part of the build, some intermediate files will get generated which may run into long-path issues. If you encounter a build failure with an error message similar to `Resource file [filename].resx cannot be found.`, [enable long paths in Windows](https://docs.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation?tabs=cmd#enable-long-paths-in-windows-10-version-1607-and-later) and in Git (`git config core.longpaths true`), then try again.

#### Using Visual Studio

The simple way to launch Visual Studio after building via `build.cmd` is to double-click the `VS with sdk.slnx` Windows shortcut in the `artifacts` folder. This will load the generated environment automatically and launch Visual Studio with the `sdk.slnx` solution.

Alternatively, to open the solution in Visual Studio, be sure to build with `build.cmd` and run the generated environment for your shell. If you're using `cmd`, then run `artifacts\sdk-build-env.bat`. If you're using PowerShell, you need to 'dot source' `artifacts/sdk-build-env.ps1`. Finally, open Visual Studio with `devenv sdk.slnx`.

In addition, Visual Studio must have the following option set (this option is automatically set in preview Visual Studio builds):

![image](https://user-images.githubusercontent.com/23152278/211684116-923ed37e-6d56-42bf-befe-a5ef66758000.png)

Go to `Tools` -> `Options` to make sure "Use previews of the .NET SDK (requires restart)" is checked and restart VS.

> [!NOTE]
> If you're building main, we may be using a preview version of the SDK to build as specified in [global.json](../../global.json#L3). We only test preview SDKs with the latest Visual Studio previews so would recommend installing the latest preview build. You can see the preview versions we test with [here](https://learn.microsoft.com/en-us/dotnet/core/porting/versioning-sdk-msbuild-vs#preview-versioning)

### Linux and macOS

Run the following command from the root of the repository:

```
./build.sh
```

The build script will output a .NET Core installation to `artifacts\bin\redist\Debug\dotnet` that will include any local changes to the .NET Core CLI.

## SDK process entry points

Changes under `src/Cli` must support three process entry points of equal importance:

| Entry point | Source | Host |
| --- | --- | --- |
| Managed CLI | [`src/Cli/dotnet/Program.cs`](../../src/Cli/dotnet/Program.cs) | CoreCLR runs the full command implementation. |
| Native AOT CLI | [`src/Cli/dotnet-aot/NativeEntryPoint.cs`](../../src/Cli/dotnet-aot/NativeEntryPoint.cs) | The native `dotnet` host calls the exported `dotnet_execute`. Unsupported operations can continue in the managed CLI. See the [NativeAOT design](../../src/Cli/dotnet-aot/DESIGN.md). |
| MSBuild logger | [`src/Cli/dotnet/Commands/MSBuild/MSBuildLogger.cs`](../../src/Cli/dotnet/Commands/MSBuild/MSBuildLogger.cs) | MSBuild loads the logger type from `dotnet.dll` as an `INodeLogger`. [`MSBuildForwardingApp`](../../src/Cli/dotnet/Commands/MSBuild/MSBuildForwardingApp.cs) adds the `-distributedlogger` argument. |

### MSBuild logger lifecycle

The MSBuild logger is a separate process entry point. It is not a standalone executable.
The logger can run in the managed CLI process, a child MSBuild process, or a persistent
MSBuild server. Code called through the logger must not assume that a CLI bootstrap
initialized process-wide state.

Use `BuildStarted` and `BuildFinished` to manage state for one build. `Shutdown` completes
one logger instance. It does not necessarily end the process. A persistent server can run
multiple builds in one process. Refresh the environment and trace context for each build.

## Running tests

### Windows

Run the following command from the root of the repository to run all the .NET Core CLI tests:

```
build.cmd -test
```

### Linux and macOS

Run the following command from the root of the repository to run all the .NET Core CLI tests:

```
./build.sh --test
```

## Using the built dotnet

The `dotnet` executable in the artifacts directory can be run directly.

However, it's easier to configure a test environment to run the built `dotnet`. This test environment is managed by dogfood.
The dogfood script starts a new Powershell with the environment configured to redirect SDK resolution to your build.

From that shell your SDK will be available in:

- any Visual Studio instance launched (via `& devenv.exe`)
- `dotnet build`
- `msbuild`

### Windows

Run the following commands from the root of the repository to setup the test environment:

```
eng\dogfood.cmd
```

Ensure the `dotnet` being used is from the artifacts directory:

```
where dotnet
```

This should output `..\artifacts\bin\redist\Debug\dotnet\dotnet.exe`.

You can now run `dotnet` commands to test changes.

### Linux and macOS

Run the following commands from the root of the repository to setup the test environment:

```
source ./eng/dogfood.sh
```

NOTE: If you are running on MacOS you will need to use a `bash` shell rather than the default `zsh`. You can either change your default shell or type `bash` before executing the above command.

Ensure the `dotnet` being used is from the artifacts directory:

```
which dotnet
```

This should output `.../artifacts/bin/redist/Debug/dotnet/dotnet`.

You can now run `dotnet` commands to test changes.

### Debugging

Run "dotnet --debug <command>" which will launch dotnet and pause waiting for user input. This will give you time to attach a debugger to the running dotnet process, set the breakpoints you want to stop at in your built copy of the sdk, and then you can hit enter for the dotnet command to continue.

## Run tests from the command line

```powershell
build.cmd # to have a full build first
.\.dotnet\dotnet.exe scripts\RunTests.cs -- `
  --project test\YOURTEST.Tests\YOURTEST.Tests.csproj `
  --filter "FullyQualifiedName~TESTNAME"
```

The runner builds the selected test project incrementally and retains its TRX and MSBuild
binlog paths under `artifacts/log/test-runs/`. Pass `--repeat N` to build once and run
the selected tests repeatedly, with separate TRX output and timing for each iteration.

For process-output assertions, process exit does not imply that stdout and stderr
callbacks have finished. Complete the output channel only after both streams reach EOF
and drain queued lines before reporting missing output. Prefer deterministic tests that
hold an output callback past process exit over sleeps or retries; see
[the output-drain regression tests](../../test/dotnet-watch.Tests/TestUtilities/AwaitableProcessTests.cs).

## Run tests in Visual Studio

Use developer command prompt for Visual Studio or put devenv on you PATH

```shell
build.cmd # to have a full build first
.\artifacts\sdk-build-env.bat
devenv sdk.slnx
```

Note again that in Visual studio "Use previews of the .NET SDK (requires restart)" must be checked. See the above comment for how to enable this.

## A simple test

Using the `dotnet` built in the previous steps:

```
mkdir test
cd test
dotnet new console
dotnet run
```

This should print `Hello World!`.

## Locked files

If you see error like ` error MSB3021: Unable to copy file "sdk-tasks.dll" to "sdk-tasks.dll". The process cannot access the file 'sdk-tasks.dll' because it is being used by another process.`

You could run the following to stop all dotnet related processes

```batch
taskkill /F /IM dotnet.exe /T ||
taskkill /F /IM VSTest.Console.exe /T ||
taskkill /F /IM msbuild.exe /T
```

## CI workflow telemetry correlation

Set `DOTNET_CLI_TELEMETRY_SESSIONID` in every CI workflow and pipeline entry point.
Set the variable at the workflow or pipeline scope. You can use job scope in a
single-job workflow. The CLI uses this value to correlate telemetry from separate
`dotnet` processes in one run.

Use this value in GitHub Actions workflows under
[`.github/workflows`](../../.github/workflows):

```yaml
env:
  DOTNET_CLI_TELEMETRY_SESSIONID: gha-${{ github.repository_id }}-${{ github.run_id }}-${{ github.run_attempt }}
```

Use this value in Azure DevOps pipeline entry points:

```yaml
variables:
- name: DOTNET_CLI_TELEMETRY_SESSIONID
  value: azdo-$(System.CollectionId)-$(System.TeamProjectId)-$(Build.BuildId)
```

When you add or change a CI entry point, preserve this variable and its provider-specific
format. For CLI behavior, see the
[telemetry documentation](telemetry.md#related-environment-variables).

## Automated PR Maintenance Commands

The SDK repository includes GitHub Actions workflows that automate common maintenance tasks directly from pull requests.

### `/xlf` or `/updatexlf` - Update Translation Files

- Workflow: [Update XLF files on command](https://github.com/dotnet/sdk/actions/workflows/update-xlf-on-comment.yml)
- Source: [update-xlf-on-comment.yml](../../.github/workflows/update-xlf-on-comment.yml)

When you modify `.resx` resource files, the corresponding `.xlf` translation files need to be updated. Instead of manually running the build locally, comment `/xlf` or `/updatexlf` on the PR and the GitHub Action will:

1. Check out the PR branch
2. Run `./build.sh /t:UpdateXlf` (or full build if needed)
3. Commit any updated `.xlf` files directly to the PR branch

This is useful when you've changed localized strings and the CI build is failing due to outdated XLF files.

See also: [Localization documentation](Localization.md)

### `/completions` or `/fixcompletions` - Update CLI Completion Snapshots

- Workflow: [Fix completion snapshots on command](https://github.com/dotnet/sdk/actions/workflows/fix-completions-on-comment.yml)
- Source: [fix-completions-on-comment.yml](../../.github/workflows/fix-completions-on-comment.yml)

The CLI includes snapshot-based tests for shell completions (bash, zsh, pwsh, etc.). When you add or modify CLI commands, these snapshots need to be updated. Comment `/completions` or `/fixcompletions` on the PR and the GitHub Action will:

1. Build the repository
2. Run the completion tests
3. Update the verified snapshot files
4. Commit the changes directly to the PR branch

This is useful when you've added new commands or options and the completion snapshot tests are failing.

See also: [Snapshot-based testing documentation](snapshot-based-testing.md)

### `/backport to <branch>`

- Workflow: [Backport PR to branch](https://github.com/dotnet/sdk/actions/workflows/backport.yml)
- Source: [backport.yml](../../.github/workflows/backport.yml)

Comment `/backport to <branch>` on a merged PR to create a new pull request that cherry-picks the changes onto the target branch. The backport PR will be labeled with `backport` and will CC the original PR participants.

### `/ba-g <reason>` - Bypass Build Analysis

Comment `/ba-g <reason>` on a PR to unconditionally turn the Build Analysis check green. The reason
is captured by telemetry and should be descriptive - avoid non-specific justifications like
"unrelated issues". This is useful when CI failures are caused by known flaky tests or
infrastructure issues unrelated to the PR.

Example reasons:

- `/ba-g deadletter` - Helix work item crashed with "DeadLetter" status.
- `/ba-g insufficient info in logs` - No good unique pattern in the logs to open a known issue.
- `/ba-g recently fixed known issue #<number>` - The known issue fix was already merged, but CI ran
  before it.
- `/ba-g failures are from known issues #<number1>, #<number2>` - All failures have known issues
  filed, but Build Analysis isn't turning green.

For details on triaging CI failures and filing known issues, see the [runtime failure analysis
documentation](https://github.com/dotnet/runtime/blob/main/docs/workflow/ci/failure-analysis.md).
The [Build Analysis Known Issue Helper](https://helix.dot.net/BuildAnalysis/CreateKnownIssues) can
assist in creating known issue reports with the correct labels and JSON format.

## Adding a Command

The dotnet CLI supports several models for adding new commands:

1. In the CLI itself via `dotnet.dll`.
2. Through a [.NET Core Global Tool](https://docs.microsoft.com/en-us/dotnet/core/tools/global-tools).
3. Through MSBuild tasks & targets in a NuGet package.
4. Through executables prefixed with `dotnet-` on the `PATH`.

### Commands in dotnet.dll

Developers are generally encouraged to avoid adding commands to `dotnet.dll` or the CLI installer directly. This is appropriate for very general commands such as `restore`, `build`, `publish`, `test`, and `clean`, but is generally too broad of a distribution mechanism for new commands.

Create an issue and engage the repository maintainers if you feel there is a missing core command that you would like to add.

### .NET Core Global Tools

A [.NET Core Global Tool](https://docs.microsoft.com/en-us/dotnet/core/tools/global-tools) can be used to install a `dotnet-` prefixed tool to the `PATH`.

The CLI will then treat the remainder of the tool name as a `dotnet` command.  For example, a tool with the name `dotnet-hello` could be executed by `dotnet hello`.

### MSBuild tasks & targets

NuGet allows adding tasks and targets to a project through a NuGet package.  Extending the CLI through this model has several advantages:

1. Targets have access to the MSBuild Project Context, allowing them to reason about the files and properties being used to build a particular project.
2. Targets are not CLI-specific, making them easy to share across command-line and IDE environments

Commands added as targets can be invoked once the target project adds a reference to the containing NuGet package and restores.

Targets are invoked by calling `dotnet msbuild /t:{TargetName}`

### Commands on the PATH

The dotnet CLI considers any executable on the path named `dotnet-{commandName}` to be a command it can call out to.
