Documents Index
===============

## Overview and general information

- [Intro to .NET Core CLI](general/intro-to-cli.md)
- [Publishing a solution and its pitfalls](general/solution-publish.md)
- [CLI UX Guidelines](general/cli-ux-guidelines.md)
- [.NET Core native pre-requisities document](https://github.com/dotnet/core/blob/main/Documentation/prereqs.md)
- [Roadmap and OS support](https://github.com/dotnet/core/blob/main/roadmap.md)
- [Comprehensive CLI documentation](https://docs.microsoft.com/en-us/dotnet/articles/core/preview3/tools/)
- [ASP.NET Core Command Line Tools](general/aspnetcore-tools.md)
- [Guidelines for how to introduce a new diagnostic or breaking change](project-docs/breaking-change-guidelines.md)

## Working with the CLI repo

- [Developer Guide](project-docs/developer-guide.md)
- [How to file issues](project-docs/issue-filing-guide.md)

## Troubleshooting and issues reporting

- [CLI Known Issues](https://github.com/dotnet/core/blob/main/release-notes/2.0/2.0.0-known-issues.md)
- [Filing migration issues](migration-issues.md)

## Specifications

- [CLI installation scenarios](specs/cli-installation-scenarios.md)
- [Runtime configuration file specification](specs/runtime-configuration-file.md)

