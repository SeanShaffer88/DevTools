import {DB, UCD} from '@/js/consts';
import {chromeLocal} from '@/js/storage-util';

let GET_KEYS;

export default class ChromeStorageDB {

  constructor(dbName, mirror) {
    this._max = dbName === DB ? null : 1; // used only with DB
    this._mirror = mirror;
    this._prefix = dbName === DB ? 'style-' : `${dbName}-`;
    GET_KEYS ??= !!chromeLocal.getKeys;
  }

  delete(id) {
    return chromeLocal.remove(this._prefix + id);
  }

  async get(id) {
    return (await chromeLocal.get(id = this._prefix + id))[id];
  }

  async getAll() {
    const all = !GET_KEYS && await chromeLocal.get();
    const keys = GET_KEYS ? await chromeLocal.getKeys() : Object.keys(all);
    const res = [];
    this._max ??= await this._getDbMax(keys);
    for (const key of keys)
      if (key.startsWith(this._prefix))
        res.push(GET_KEYS ? key : all[key]);
    return GET_KEYS
      ? Object.values(await chromeLocal.get(res))
      : res;
  }

  async put(item, key) {
    key ??= item.id ??= (this._max ??= await this._getDbMax(), this._max++);
    await chromeLocal.set({
      [this._prefix + key]: this._mirror && item[UCD]
        ? {...item, sections: undefined}
        : item,
    });
    return key;
  }

  async putMany(items, keys) {
    const data = {};
    const res = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const id = keys ? keys[i] : item.id ??= (this._max ??= await this._getDbMax(), this._max++);
      data[this._prefix + id] = this._mirror && item[UCD]
        ? {...item, sections: undefined}
        : item;
      res.push(id);
    }
    await chromeLocal.set(data);
    return res;
  }

  async _getDbMax(keys) {
    let res = 1;
    let id;
    keys ??= GET_KEYS
      ? await chromeLocal.getKeys()
      : Object.keys(await chromeLocal.get());
    for (const key of keys)
      if (key.startsWith(this._prefix) && (id = +key.slice(this._prefix.length)) >= res)
        res = id + 1;
    return res;
  }
}
