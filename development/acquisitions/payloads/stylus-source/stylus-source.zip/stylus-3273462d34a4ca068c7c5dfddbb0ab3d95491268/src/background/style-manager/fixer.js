import * as URLS from '@/js/urls';
import {isEmptyObj, sleep} from '@/js/util';
import * as syncMan from '../sync-manager';
import {save} from '.';
import {updateSections} from './cache';
import {broadcastStyleUpdated, styleMap, storeInMap} from './util';

/** uuidv4 helper: converts to a 4-digit hex string and adds "-" at required positions */
const hex4 = num => (num < 0x1000 ? num + 0x10000 : num).toString(16).slice(-4);

const makeRandomUUID = crypto.randomUUID?.bind(crypto) || !__.MV3 && (() => {
  const seeds = crypto.getRandomValues(new Uint16Array(8));
  // 00001111-2222-M333-N444-555566667777
  return hex4(seeds[0]) + hex4(seeds[1]) + '-' +
    hex4(seeds[2]) + '-' +
    hex4(seeds[3] & 0x0FFF | 0x4000) + '-' + // UUID version 4, M = 4
    hex4(seeds[4] & 0x3FFF | 0x8000) + '-' + // UUID variant 1, N = 8..0xB
    hex4(seeds[5]) + hex4(seeds[6]) + hex4(seeds[7]);
});

const MISSING_PROPS = {
  name: style => `ID: ${style.id}`,
  _id: makeRandomUUID,
};

/**
 * @param {StyleObj} style
 * @param {boolean} [revive]
 * @return {?StyleObj|Promise<StyleObj>}
 */
export function fixKnownProblems(style, revive) {
  let res = 0;
  let v;
  res += fixRevision(style) || 0;
  for (const key in MISSING_PROPS) {
    if (!style[key]) {
      style[key] = MISSING_PROPS[key](style);
      res = 1;
    }
  }
  /* delete if value is null, {}, [] */
  for (const key in style) {
    v = style[key];
    if (v == null || typeof v === 'object' && isEmptyObj(v)) {
      if (res < 2 && !revive)
        style = {...style};
      delete style[key];
      res = 2;
    }
  }
  res += inferHomepage(style);
  /* Upgrade the old way of customizing local names */
  const {originalName} = style;
  if (originalName) {
    if (originalName !== style.name) {
      style.customName = style.name;
      style.name = originalName;
    }
    delete style.originalName;
    res = 1;
  }
  /* wrong homepage url in 1.5.20-1.5.21 due to commit 1e5f118d */
  for (const key of ['url', 'installationUrl']) {
    const url = style[key];
    const fixedUrl = url && url.replace(/([^:]\/)\//, '$1');
    if (fixedUrl !== url) {
      res = 1;
      style[key] = fixedUrl;
    }
  }
  /* USO bug, duplicate "update" subdomain, see #523 */
  if ((v = style.md5Url) && v.includes('update.update.userstyles')) {
    res = style.md5Url = v.replace('update.update.userstyles', 'update.userstyles');
  }
  /* Outdated USO-archive links */
  if (`${style.url}${style.installationUrl}`.includes('https://33kk.github.io/uso-archive/')) {
    delete style.url;
    delete style.installationUrl;
  }
  return res && style;
}

export function fixRevision(style) {
  const upd = style.updateDate || style.installDate;
  if (upd > (style._rev || 0)) {
    style._rev = upd;
    return true;
  }
}

/** Default homepage URL for external styles installed from a known distro */
export function inferHomepage(style) {
  let res, v;
  if (
    (!style.url || !style.installationUrl) &&
    (v = style.updateUrl) &&
    (v = URLS.makeInstallUrl(v) ||
        (v = /\d+/.exec(style.md5Url)) && `${URLS.uso}styles/${v[0]}`
    )
  ) {
    if (!style.url) res = style.url = v;
    if (!style.installationUrl) res = style.installationUrl = v;
  }
  return !!res;
}

export async function inferHomepages() {
  const toWrite = [];
  let skip, style;
  for (style of styleMap.values())
    if (inferHomepage(style))
      toWrite.push([style.id, style._rev]);
  for (const [id, rev] of toWrite) {
    if (!skip)
      await sleep(50);
    if (!(skip = !(style = styleMap.get(id)))
      && (rev === style._rev || inferHomepage(style))) {
      await save(style, false, undefined, /*alreadyFixed=*/true);
    }
  }
}

export function onBeforeSave(style) {
  if (!style.id) delete style.id;
  return fixKnownProblems(style);
}

/**
 * @param {StyleObj} style
 * @param {string|false} [reason] - false = no broadcast
 * @param {number} [id]
 * @param {{}} [msg]
 * @returns {StyleObj}
 */
export function onSaved(style, reason, id = style.id, msg) {
  const isNew = !styleMap.has(id);
  style.id ??= id;
  storeInMap(style);
  if (reason !== false) {
    broadcastStyleUpdated(style, reason, isNew, msg);
  } else {
    updateSections(id);
  }
  if (reason !== 'sync') {
    syncMan.putDoc(style);
  }
  return style;
}
