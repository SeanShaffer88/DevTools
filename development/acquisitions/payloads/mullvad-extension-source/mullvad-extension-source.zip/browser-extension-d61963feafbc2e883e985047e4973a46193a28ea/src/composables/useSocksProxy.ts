import { computed } from 'vue';

import {
  ProxyDetails,
  ProxyInfo,
  ProxyInfoType,
  ProxyOperationArgs,
} from '@/helpers/socksProxy/socksProxy.types';
import { reloadOptions } from '@/helpers/browserExtension';
import { updateCurrentTabProxyBadge } from '@/helpers/proxyBadge';

import { reloadGlobalProxiedTabs, reloadMatchingTabs } from '@/helpers/tabs';
import { checkDomain } from '@/helpers/domain';
import { getTargetHost } from '@/helpers/socksProxy/getTargetHost';
import { baseConfig, socksIp } from '@/helpers/socksProxy/constants';

import useActiveTab from '@/composables/useActiveTab';
import useConnectionStatus from '@/composables/useConnection/useConnectionStatus';
import useStore from '@/composables/useStore';

const { checkStatus } = useConnectionStatus();

const { activeTabHost } = useActiveTab();

const {
  excludedHosts,
  globalProxy,
  globalProxyDetails,
  hostProxies,
  hostProxiesDetails,
  proxyAutoReload,
} = useStore();

const activeTabDomainInfo = computed(() => checkDomain(activeTabHost.value));

const currentHostProxyDetails = computed(() => {
  const { hasSubdomain, domain } = activeTabDomainInfo.value;

  // First check for exact matches that are enabled
  if (hostProxiesDetails.value[activeTabHost.value]?.socksEnabled) {
    return hostProxiesDetails.value[activeTabHost.value];
  }

  // Then check parent domain if this is a subdomain
  if (hasSubdomain && hostProxiesDetails.value[domain]?.socksEnabled) {
    return hostProxiesDetails.value[domain];
  }

  // If no enabled proxies found, return any existing proxy config
  if (hostProxiesDetails.value[activeTabHost.value]) {
    return hostProxiesDetails.value[activeTabHost.value];
  }

  // Also check parent domain for disabled configs (subdomain fallback)
  if (hasSubdomain && hostProxiesDetails.value[domain]) {
    return hostProxiesDetails.value[domain];
  }

  return null;
});

const globalProxyEnabled = computed(() => globalProxyDetails.value.socksEnabled);

const currentHostExcluded = computed(() => {
  const { domain, hasSubdomain } = activeTabDomainInfo.value;
  return (
    excludedHosts.value.includes(activeTabHost.value) ||
    (hasSubdomain && excludedHosts.value.includes(domain))
  );
});

const currentHostProxyEnabled = computed(
  () => !currentHostExcluded.value && (currentHostProxyDetails.value?.socksEnabled ?? false),
);

const currentEffectiveProxyHost = computed(() => {
  const { hasSubdomain, domain } = activeTabDomainInfo.value;

  // If the host or its parent domain is excluded, return the excluded domain
  if (excludedHosts.value.includes(activeTabHost.value)) {
    return activeTabHost.value;
  }
  if (hasSubdomain && excludedHosts.value.includes(domain)) {
    return domain;
  }

  // Then check for exact matches that are enabled
  if (hostProxiesDetails.value[activeTabHost.value]?.socksEnabled) {
    return activeTabHost.value;
  }

  // Then check parent domain if this is a subdomain (fallback)
  if (hasSubdomain && hostProxiesDetails.value[domain]?.socksEnabled) {
    return domain;
  }

  // Any existing proxy config for the exact host
  if (hostProxiesDetails.value[activeTabHost.value]) {
    return activeTabHost.value;
  }

  // Parent domain fallback for disabled configs
  if (hasSubdomain && hostProxiesDetails.value[domain]) {
    return domain;
  }

  return activeTabHost.value;
});

const combinedHosts = computed(() => {
  // hosts that are excluded from proxying + hosts that enabled for proxying
  const enabledProxyHosts = Object.entries(hostProxiesDetails.value)
    .filter(([, details]) => details.socksEnabled)
    .map(([host]) => host);
  const allHosts = [...enabledProxyHosts, ...excludedHosts.value];
  return [...new Set(allHosts)].sort((a, b) => a.localeCompare(b));
});

const toggleGlobalProxy = () => {
  globalProxyDetails.value.socksEnabled = !globalProxyDetails.value.socksEnabled;
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadGlobalProxiedTabs(combinedHosts.value);
  }
  updateCurrentTabProxyBadge();
  checkStatus();
};

const toggleHostProxy = (host: string) => {
  hostProxiesDetails.value[host].socksEnabled = !hostProxiesDetails.value[host].socksEnabled;
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(host);
  }
  updateCurrentTabProxyBadge();
  checkStatus();
};

const toggleCustomProxy = (host: string) => {
  const targetHost = getTargetHost(host, hostProxiesDetails.value);
  hostProxiesDetails.value[targetHost].socksEnabled =
    !hostProxiesDetails.value[targetHost].socksEnabled;
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(targetHost);
  }
  updateCurrentTabProxyBadge();
  checkStatus();
};

const toggleCustomProxyDNS = (host: string) => {
  const targetHost = getTargetHost(host, hostProxiesDetails.value);
  const updatedProxyDNS = !hostProxiesDetails.value[targetHost].proxyDNS;

  hostProxiesDetails.value[targetHost].proxyDNS = updatedProxyDNS;
  hostProxies.value[targetHost].proxyDNS = updatedProxyDNS;

  updateCurrentTabProxyBadge();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(targetHost);
  }
  checkStatus();
};

const toggleGlobalProxyDNS = () => {
  const updatedGlobalProxyDNS = !globalProxyDetails.value.proxyDNS;
  globalProxyDetails.value.proxyDNS = updatedGlobalProxyDNS;
  globalProxy.value.proxyDNS = updatedGlobalProxyDNS;
  if (proxyAutoReload.value) {
    reloadGlobalProxiedTabs(combinedHosts.value);
  }
  updateCurrentTabProxyBadge();
  checkStatus();
};

const setGlobalProxy = ({
  country,
  countryCode,
  city,
  hostname,
  ipv4_address,
  port = baseConfig.port,
}: ProxyOperationArgs) => {
  const newGlobalProxy: ProxyInfo = {
    host: ipv4_address,
    port: port || 1080,
    proxyDNS: baseConfig.proxyDNS,
    type: ProxyInfoType.socks,
  };

  const newGlobalProxyDetails: ProxyDetails = {
    socksEnabled: true,
    server: hostname,
    country: country,
    countryCode: countryCode,
    city: city,
    proxyDNS: baseConfig.proxyDNS,
  };

  globalProxy.value = newGlobalProxy;
  globalProxyDetails.value = newGlobalProxyDetails;

  reloadOptions();
  if (proxyAutoReload.value) {
    reloadGlobalProxiedTabs(combinedHosts.value);
  }
  checkStatus();
};

const setCustomProxy = (
  {
    country,
    countryCode,
    city,
    hostname,
    ipv4_address,
    port = baseConfig.port,
  }: Partial<ProxyOperationArgs>,
  host: string,
) => {
  const newHostProxy: ProxyInfo = {
    host: ipv4_address || socksIp,
    port: port!,
    proxyDNS: baseConfig.proxyDNS,
    type: ProxyInfoType.socks,
  };

  const newHostProxyDetails: ProxyDetails = {
    socksEnabled: true,
    server: hostname,
    country: country,
    countryCode: countryCode,
    city: city,
    proxyDNS: baseConfig.proxyDNS,
  };

  hostProxies.value = { ...hostProxies.value, [host]: newHostProxy };
  hostProxiesDetails.value = { ...hostProxiesDetails.value, [host]: newHostProxyDetails };

  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(host);
  }
  checkStatus();
};

const removeCustomProxy = (host: string) => {
  delete hostProxies.value[host];
  delete hostProxiesDetails.value[host];
  updateCurrentTabProxyBadge();
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(host);
  }
  checkStatus();
};

const removeGlobalProxy = () => {
  globalProxy.value = {} as ProxyInfo;
  globalProxyDetails.value = {} as ProxyDetails;
  updateCurrentTabProxyBadge();
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadGlobalProxiedTabs(combinedHosts.value);
  }
  checkStatus();
};

const allowProxy = (host: string) => {
  excludedHosts.value = excludedHosts.value.filter((excluded) => excluded !== host);
  updateCurrentTabProxyBadge();
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(host);
  }
  checkStatus();
};

const neverProxyHost = (host: string) => {
  excludedHosts.value = [...excludedHosts.value, host];
  updateCurrentTabProxyBadge();
  reloadOptions();
  if (proxyAutoReload.value) {
    reloadMatchingTabs(host);
  }
  checkStatus();
};

const useSocksProxy = () => {
  return {
    allowProxy,
    currentHostProxyDetails,
    currentHostProxyEnabled,
    currentHostExcluded,
    currentEffectiveProxyHost,
    globalProxyEnabled,
    neverProxyHost,
    removeCustomProxy,
    removeGlobalProxy,
    setCustomProxy,
    setGlobalProxy,
    toggleHostProxy,
    toggleCustomProxy,
    toggleCustomProxyDNS,
    toggleGlobalProxy,
    toggleGlobalProxyDNS,
  };
};

export default useSocksProxy;
