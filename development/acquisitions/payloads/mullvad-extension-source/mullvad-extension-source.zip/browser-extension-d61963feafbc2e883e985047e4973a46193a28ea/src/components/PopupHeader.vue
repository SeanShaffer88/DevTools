<script lang="ts" setup>
import { computed, inject } from 'vue';
import { NIcon, NTag } from 'naive-ui';

import FeCog from '@/components/Icons/FeCog.vue';
import FeDrop from '@/components/Icons/FeDrop.vue';
import FeHelpCircle from '@/components/Icons/FeHelpCircle.vue';
import FeLock from '@/components/Icons/FeLock.vue';
import FeLockOff from '@/components/Icons/FeLockOff.vue';
import FePower from './Icons/FePower.vue';
import FeShuffle from '@/components/Icons//FeShuffle.vue';
import FeWarning from '@/components/Icons/FeWarning.vue';
import FeXCircle from '@/components/Icons/FeXCircle.vue';
import MuSpinner from '@/components/Icons/MuSpinner.vue';
import TitleCategory from '@/components/TitleCategory.vue';

import { openOptions } from '@/helpers/browserExtension';
import { truncateHost } from '@/helpers/domain';

import useActiveTab from '@/composables/useActiveTab';

import { ConnectionKey, defaultConnection } from '@/composables/useConnection/useConnection';
import useRandomProxy from '@/composables/useRandomProxy';

const props = defineProps<{
  isErrorDNS: boolean;
  isLeakingDNS: boolean;
  isLoadingDNS: boolean;
  isMullvadDNS: boolean;
  isMullvadDoh: boolean;
  isQuad9Doh: boolean;
  isProxyInUse: boolean;
}>();

const { activeTabHost, isAboutPage, isExtensionPage } = useActiveTab();
const { randomProxyMode } = useRandomProxy();
const { connection, isLoading, isError } = inject(ConnectionKey, defaultConnection);

const isMullvad = computed(() => connection.value.isMullvad);

const displayHost = computed(() => truncateHost(activeTabHost.value));

const dnsTagType = computed(() => {
  if (props.isQuad9Doh && isMullvad.value) return 'warning';
  if (props.isQuad9Doh && !isMullvad.value) return 'success';
  if (props.isMullvadDoh) return 'error';
  return 'info';
});

const dnsTagText = computed(() => {
  if (props.isQuad9Doh) return 'Quad9 DoH';
  return props.isMullvadDoh ? 'DOH' : 'DNS';
});
</script>

<template>
  <div class="flex justify-between mb-3">
    <div>
      <TitleCategory
        v-if="!isAboutPage && !isExtensionPage"
        :title="displayHost"
        :title-attr="activeTabHost"
        class="ml-3 my-0"
      />
    </div>

    <div class="flex flex-row self-end">
      <n-tag v-if="isProxyInUse" round type="info">
        <span> Proxy </span>
        <template #icon>
          <n-icon size="20">
            <FeShuffle v-if="randomProxyMode" class="text-success" />
            <FePower v-else class="text-success" />
          </n-icon>
        </template>
      </n-tag>

      <n-tag round type="info" class="ml-1">
        <span> VPN </span>
        <template #icon>
          <n-icon size="20">
            <MuSpinner v-if="isLoading" />
            <FeLock v-else-if="isMullvad" class="text-success" />
            <FeHelpCircle v-else-if="isError" class="text-warning" />
            <FeLockOff v-else class="text-error" />
          </n-icon>
        </template>
      </n-tag>

      <n-tag round :type="dnsTagType" class="ml-1">
        <span>{{ dnsTagText }}</span>
        <template #icon>
          <n-icon size="20">
            <MuSpinner v-if="isLoadingDNS" />
            <FeHelpCircle v-else-if="isErrorDNS" class="text-warning" />
            <FeWarning v-else-if="isMullvadDoh" class="text-error" />
            <FeWarning v-else-if="isQuad9Doh && isMullvad" class="text-warning" />
            <FeLock v-else-if="isQuad9Doh && !isMullvad" class="text-success" />
            <FeDrop v-else-if="isLeakingDNS && isMullvad" class="text-error" />
            <FeXCircle v-else-if="isLeakingDNS && !isMullvad" class="text-error" />
            <FeLock v-else-if="isMullvadDNS" class="text-success" />
          </n-icon>
        </template>
      </n-tag>

      <n-icon size="20" class="hover:text-white cursor-pointer ml-2 mt-1" @click="openOptions()">
        <FeCog />
      </n-icon>
    </div>
  </div>
</template>
