/*
 * NoScript Commons Library
 * Reusable building blocks for cross-browser security/privacy WebExtensions.
 * Copyright (C) 2020-2026 Giorgio Maone <https://maone.net>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */

"use strict";
{
  let patchesByTab = new Map();
  let debugging;

  let cleanup = tabId => {
    if (tabId === -1) return;
    let byOrigin = patchesByTab.get(tabId);
    if (!byOrigin) return;
    patchesByTab.delete(tabId);
    if (debugging) {
      debugging.dispose(tabId);
    }
    let serviceWorkers = patchesByTab.get(-1);
    if (serviceWorkers) {
      for (let origin of byOrigin.keys()) {
        serviceWorkers.delete(origin);
      }
    }
  };

  const INIT_EVENT = JSON.stringify(`workerPatch:${uuid()}`);
  const wrapPatch = patch => `(() => {
    if (globalThis.dispatchEvent) {
      if (!dispatchEvent(new CustomEvent(${INIT_EVENT}, { cancelable: true }))) {
        console.debug("Worker already patched, not at the top level?", globalThis.location?.href); // DEV_ONLY
        return;
      }
      addEventListener(${INIT_EVENT}, e => e.preventDefault(), true);
      if (globalThis.FetchEvent) {
        addEventListener("fetch", e => {
          if (e.isTrusted && navigator.onLine &&
              /work(?:er|let)$/.test(e.request.destination)) {
            e.stopImmediatePropagation();
          }
        }, true);
      }
    }
    ${patch}
  })();
  `;

  browser.tabs.onRemoved.addListener(tab => {
    cleanup(tab.id);
  });
  browser.webNavigation.onCommitted.addListener(({tabId, frameId}) => {
    if (frameId === 0) cleanup(tabId);
  });

  const updatePatch = (patch, tabId, origin, url) => {
    let byOrigin = patchesByTab.get(tabId);
    if (!byOrigin) patchesByTab.set(tabId, byOrigin = new Map());
    origin = new URL(origin).origin;
    patch = wrapPatch(patch);
    let patchInfo = byOrigin.get(origin);
    if (!patchInfo) byOrigin.set(origin, patchInfo = {
      patch,
      destinations: new Set(),
    });
    else {
      patchInfo.patch = patch;
    }
    const destination = new URL(url).origin;
    patchInfo.destinations.add(destination);
    // account for nested workers
    byOrigin.set(destination, patchInfo);
    return patchInfo;
  };

  const findStaticImportScheme = async (source) => {
    await include("/nscl/lib/acorn.js");

    let scheme = null;
    let ast;
    try {
      ast = acorn.parse(source, {
        ecmaVersion: "latest",
        sourceType: "module"
      });
    } catch (e) {
      // Don't guess if the source cannot be parsed.
      return scheme;
    }


    for (const node of ast.body) {
      switch (node.type) {
        case "ImportDeclaration":
        case "ExportNamedDeclaration":
        case "ExportAllDeclaration":
          break;
        default:
          continue;
      }

      const specifier = node.source.value;
      const match = /^(data|blob):/i.exec(specifier);

      if (!match) continue;

      scheme = match[1].toLowerCase();

      if (scheme == "data") {
        break;
      }
    }

    return scheme;
  }

  const mergePatch = async (patch, body, { tabId, origin }) => {
    if (/\b(?:im|ex)port\b/.test(body)) {
      const scheme = globalThis.PATCHWORKERS_DEBUG_SCHEME || await findStaticImportScheme(body);
      switch (scheme) {
        case "blob":
          try {
            const blobUrl = await browser.tabs.sendMessage(tabId,
              {
                __getWorkerPatch__: {
                  origin,
                  asBlobUrl: true,
                  patch
                },
              },
            );
            if (blobUrl) {
              patch = `import "${blobUrl}";`;
              break;
            }
          } catch (e) {
            console.error(e);
          }
          // fallback to data: if blobUrl can't be created for this origin
        case "data":
          patch = `import "data:text/javascript,${encodeURIComponent(patch)};";`;
        break;
      }
    }
    return patch.concat(body);
  }

  const workerCreationListener =({__patchWorkers__}, sender) => {
    if (!__patchWorkers__) return;
    const { tab, frameId, url: documentUrl } = sender;
    try {
      const {url, patch, isServiceOrShared} = __patchWorkers__;
      const tabId = isServiceOrShared && !chrome.debugger ? -1 : tab.id;

      const patchInfo = updatePatch(patch, tabId, documentUrl, url);

      return Promise.resolve(init(tab.id, frameId, url, patchInfo)).then(r => "ready");
    } catch (e) {
      console.error("Error on __patchWorkers__ message", e);
      return Promise.reject(e);
    }
  };

  browser.runtime.onMessage.addListener(workerCreationListener);

  let init = browser.webRequest.filterResponseData ? (() => {
    // Firefox

    // Filter the worker script sources from the network
    browser.webRequest.onBeforeSendHeaders.addListener(async request => {
      const { requestHeaders } = request;
      console.debug("patchesByTab", patchesByTab, request); // DEV_ONLY REMOVEME

      let type;
      for (const { name, value } of requestHeaders) {
        if (name == "Sec-Fetch-Dest") {
          if (!/work(er|let)/.test(value)) {
            return;
          }
          type = value;
          break;
        }
      }
      if (!type) {
        return;
      }

      const { tabId, frameId, url, documentUrl, originUrl, requestId } = request;
      const byOrigin = patchesByTab.get(tabId);
      const documentOrigin = new URL(documentUrl).origin;
      const initiatorOrigin = new URL(originUrl).origin;

      let patchInfo = byOrigin?.get(documentOrigin);
      if (!patchInfo) {
        // account for nested workers
        patchInfo = byOrigin?.get(initiatorOrigin);
        if (!patchInfo) {
          if (tabId == -1) {
            // we don't have any document to get the patch from
            return;
          }
          try {
            const patch = await browser.tabs.sendMessage(tabId,
              { __getWorkerPatch__: {} },
              { frameId }
            );
            if (!patch) {
              return;
            }
          } catch (e) {
            return;
          }
          patchInfo = updatePatch(patch, tabId, documentOrigin, url);
        } else {
          updatePatch(patchInfo.patch, tabId, documentOrigin, url);
        }
      }

      console.debug(`Patching ${type}`, requestId, url, documentUrl); // DEV_ONLY REMOVEME
      const filter = browser.webRequest.filterResponseData(requestId);
      const chunks = [];
      filter.ondata = ({data}) => {
        chunks.push(data);
      };
      filter.onstop = async () => {
        try {
          const size = chunks.reduce((n, chunk) => n + chunk.byteLength, 0);
          const sourceBytes = new Uint8Array(size);
          let offset = 0;

          for (const chunk of chunks) {
            sourceBytes.set(new Uint8Array(chunk), offset);
            offset += chunk.byteLength;
          }

          const origin = new URL(url).origin;
          const body = await mergePatch(patchInfo.patch, new TextDecoder().decode(sourceBytes), { tabId, origin });
          filter.write(new TextEncoder().encode(body));
        } catch (e) {
          console.error("Cannot patch worker response", e);
          filter.disconnect();
        } finally {
          filter.close();
        }
      };
    }, {
      urls: ["<all_urls>"],
      types: ["script"],
    }, ["blocking", "requestHeaders"]);

    // attach the listener above just once per session
    return () => true;
  })() : async (...args) => {
    // Chromium

    // Section 1, run once per tab

    if (!chrome.debugger) {
      throw new Error("patchWorker.js - no debugger API: missing permission?");
    }

    const dbg = chrome.debugger;

    const fetchParams = {
      patterns: [
        {
          resourceType: "Other",
          requestStage: "Response",
        },
        {
          resourceType: "Script",
          requestStage: "Response",
        }
      ]
    };


    debugging = new Map();
    debugging.dispose = async function(tabId) {
      let dbgInfo = await this.get(tabId);
      if (dbgInfo) {
        try {
          return await dbgInfo.dispose();
        } catch (e) {
          console.error(e);
        }
      }
      return false;
    }

    dbg.onEvent.addListener(async (source, method, params) => {
      let { tabId } = source;
      const dbgInfo = await debugging.get(tabId);
      if (!dbgInfo) {
        return;
      }

      switch (method) {
        case "Target.attachedToTarget":
          if (dbgInfo.notifyFrameAttached) {
            dbgInfo.notifyFrameAttached();
            delete dbgInfo.notifyFrameAttached;
          }
          const target = { tabId: source.tabId, sessionId: params.sessionId };
          await dbg.sendCommand(target, "Fetch.enable", fetchParams);
          await dbg.sendCommand(target, "Network.enable");
          await dbg.sendCommand(target, "Runtime.runIfWaitingForDebugger");
        break;
        case "Network.requestWillBeSent":
          if (params.type == "Script" || params.type == "Other") {
            dbgInfo.requests.set(params.requestId, params.initiator.url);
            break;
          }
          return;
        case "Fetch.requestPaused":
          await dbgInfo.handleRequest(source, params);
          break;
        case "Network.loadingFinished":
        case "Network.loadingFailed":
          dbgInfo.requests.delete(params.requestId);
          return;
        default:
          return;
      }
      console.debug("Debugger event", method, params, source, dbgInfo.requests); // DEV_ONLY
    });

    dbg.onDetach.addListener((source, reason) => {
      console.debug("Detached debugger from", source, reason); // DEV_ONLY
      if (source.tabId) debugging.dispose(source.tabId);
    });

    // Section 2, run from now on

    return await (init = async (tabId, frameId, url, { patch }) => {
      const target = { tabId };
      let dbgInfo = await debugging.get(tabId);
      if (!dbgInfo) {
        const startingDebugger = (async () => {
          try {
            console.debug("Attaching debugger to", tabId); // DEV_ONLY
            try {
              await dbg.attach(target, "1.3");
            } catch (e) {
              // might just be because we're already attached
              console.error(e);
            }
            await dbg.sendCommand(target, "Target.setAutoAttach", {
              autoAttach: true,
              waitForDebuggerOnStart: true,
              flatten: true,
              filter: [
                { type: "iframe", exclude: false }
              ],
            });
            await dbg.sendCommand(target, "Fetch.enable", fetchParams);
            await dbg.sendCommand(target, "Network.enable");
          } catch (e) {
            console.error(e);
            throw e;
          }

          console.debug("NoScript's patchWorker started debugger on ", tabId);
          return {
            requests: new Map(),
            patches: new Map(),

            async handleRequest(source, params) {
              const { requestId, responseHeaders } = params;
              const contentTypeHeader = responseHeaders?.find(h => h.name.toLowerCase() === "content-type");
              const isJS = /\bjavascript\b/.test(contentTypeHeader?.value);
              if (isJS) {
                try {
                  const initiatorUrl = this.requests.get(params.networkId);
                  const codeChunks = [];
                  if (initiatorUrl) {
                    const { origin } = new URL(initiatorUrl);
                    if (this.patches.has(origin)) {
                      codeChunks.push(this.patches.get(origin).code);
                    }
                  }
                  const { origin } = new URL(params.request.url);
                  if (this.patches.has(origin)) {
                    codeChunks.push(this.patches.get(origin).code);
                  } else if (codeChunks[0]) {
                    // inherit patch from document
                    this.patch(origin, codeChunks[0]);
                  }
                  const code = [...new Set(codeChunks)].join(";");
                  if (code) {
                    const response = await dbg.sendCommand(source, "Fetch.getResponseBody", { requestId });
                    let body = response.base64Encoded ? atob(response.body) : response.body;
                    body = await mergePatch(code, body, { tabId: source.tabId, origin });
                    body = btoa(unescape(encodeURIComponent(body)));
                    await dbg.sendCommand(source, "Fetch.fulfillRequest", {
                      requestId,
                      responseHeaders,
                      responsePhrase: params.responseStatusText,
                      responseCode: params.responseStatusCode,
                      body,
                    });
                    console.debug("Fetch: patched worker", params, { initiatorUrl, body }); // DEV_ONLY
                  }
                  return;
                } catch (e) {
                  console.error("Cannot patch worker via Fetch", e, params);
                }
              }
              console.debug("Fetch: continuing ", requestId);
              await dbg.sendCommand(source, "Fetch.continueRequest", { requestId });
            },

            patch(origin, code) {
              let patch = this.patches.get(origin);
              if (!patch) {
                this.patches.set(origin, patch = { origin, code, count: 1 });
              } else {
                patch.code = code;
                patch.count++;
              }
            },
            async dispose() {
              this.patches.clear();
              this.requests.clear();
              console.debug("Detaching debugger from tab", target.tabId); // DEV_ONLY
              try {
                await dbg.detach(target);
              } catch (e) {
                console.error(e);
              }
              debugging.delete(target.tabId);
            }
          }
        })();
        debugging.set(tabId, startingDebugger);
        dbgInfo = await startingDebugger;
        if (frameId > 0) {
          await new Promise(resolve => {
            dbgInfo.notifyFrameAttached = resolve;
          });
        }
      }
      dbgInfo.patch(new URL(url).origin, patch);
    })(...args);
  };
}
