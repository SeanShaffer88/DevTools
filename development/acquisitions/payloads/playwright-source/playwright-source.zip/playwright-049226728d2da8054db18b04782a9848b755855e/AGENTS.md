### Language

- Use 80% of the way to ASD-STE100 when talking to me
- No jargon, metaphors, or invented shorthands in replies

### Monorepo Packages

| Package | npm name | Purpose |
|---------|----------|---------|
| `playwright-core` | `playwright-core` | Browser automation engine: client, server, dispatchers, protocol |
| `playwright` | `playwright` | Test runner + browser automation (public package) |
| `playwright-test` | `@playwright/test` | Test runner entry point |
| `playwright-client` | `@playwright/client` | Standalone client package |
| `protocol` | *(internal)* | RPC protocol definitions (`spec/*.yml` → generated validators and channel types) |

### Browser Packages

`playwright-chromium`, `playwright-firefox`, `playwright-webkit` — per-browser distributions.
`playwright-browser-chromium`, `playwright-browser-firefox`, `playwright-browser-webkit` — binary packages.

### Tooling Packages

| Package | Purpose |
|---------|---------|
| `html-reporter` | HTML test report viewer |
| `trace-viewer` | Trace viewer UI |
| `recorder` | Test recorder |
| `web` | Shared web UI components |
| `injected` | Scripts injected into browser pages |

### Key Directories

| Directory | Purpose |
|-----------|---------|
| `tests/` | All test suites (page, library, playwright-test, mcp, etc.) |
| `docs/src/` | API documentation — **source of truth** for public TypeScript types |
| `docs/src/api/` | Per-class API reference (`class-page.md`, `class-locator.md`, etc.) |
| `utils/` | Build scripts, code generation, linting, doc tools |
| `browser_patches/` | Browser engine patches |

## Build

```bash
npm run build       # Full build
npm run watch       # Watch mode (recommended during development)
```

Assume watch is running and code is up to date. Generated files (types, channels, validators) are produced by watch automatically.

## Lint and type check

```bash
npm run flint
```

Runs all lint checks in parallel: eslint, tsc, doclint, check-deps, generate_channels, generate_types, lint-tests, test-types, lint-packages, code-snippet linting, check-dependency-age (every version in `package-lock.json` must be at least 7 days old, unless only a newer version fixes an advisory of high or critical severity).

**Run `flint` only before you upload a PR, and only after `npm run build`.** Do not run it before each commit. Do not use `tsc --noEmit` or individual lint commands separately.

## Test Commands

| Command | Scope |
|---------|-------|
| `npm run ctest <filter>` | Chromium only library tests — **use during development** |
| `npm run test <filter> -- --project=<chromium,firefix,webkit>` | All library / per project |
| `npm run ttest <filter>` | Test runner (`tests/playwright-test/`) |
| `npm run ctest-mcp <filter>` | Chromium only MCP tools (`tests/mcp/`) |
| `npm run test-mcp <filter> -- --project=<chromium,firefox,webkit>` | MCP tools (`tests/mcp/`) |


### Filtering

```bash
npm run ctest tests/page/locator-click.spec.ts         # Specific file
npm run ctest tests/page/locator-click.spec.ts:12      # Specific location
npm run ctest -- --grep "should click"                 # By test name
npm run ctest-mcp snapshot                             # By file name part
```

### Test Directories and Fixtures

| Directory | Import | Key Fixtures | What to Test |
|-----------|--------|--------------|--------------|
| `tests/page/` | `import { test, expect } from './pageTest'` | `page`, `server`, `browserName` | User interactions: click, fill, navigate, locators, assertions |
| `tests/library/` | `import { browserTest, expect } from '../config/browserTest'` | `browser`, `context`, `browserType` | Browser/context lifecycle, cookies, permissions, browser-specific features |
| `tests/playwright-test/` | `import { test, expect } from './playwright-test-fixtures'` | test runner fixtures | Test runner: reporters, config, annotations, retries |
| `tests/mcp/` | `import { test, expect } from './fixtures'` | `client`, `server` | MCP tools via `client.callTool()` |

**Decision rule**: Does the test need `browser`/`browserType`/`context` → `tests/library/`. Just needs `page` + `server` → `tests/page/`.

### Test Scope

Keep tests minimal. Be mindful of the number of tests you add.

- **Extend before you add**: before you write a new test, look for an existing test that covers the same feature and the same API. If one exists, add the new edge case or assertion to it. Create a new test only when no existing test is a good fit, or when the new scenario needs a different setup.
- **New features**: cover the mainstream scenario and the important edge cases only. Do not create matrices of tests for every scenario, option, or aspect.
- **Regressions**: generalize the provided regression cases into meaningful tests, and stop there. Do not add more tests around them.

### Regression tests

- Tag the test with the issue: `test('...', { annotation: { type: 'issue', description: '<issue url>' } }, async ({ page, server }) => { ... })`.
- No `test.beforeAll`, `test.afterAll`, `http.createServer`, or manual setup and teardown. The fixtures give you a page and a web server: `server.setRoute(...)`, `server.setRedirect(...)`, `server.PREFIX`, `server.EMPTY_PAGE`. Drive the page with `page.setContent(...)` or `page.goto(server.PREFIX + '/...')`.
- Good models: "should return event source" in `tests/page/page-network-request.spec.ts` (an SSE endpoint through `server.setRoute`, no lifecycle hooks); "should use light DOM structure for child combinator with slotted content" in `tests/page/selectors-css.spec.ts` (`page.setContent` with inline shadow DOM); "should report worker script as network request after redirect" in `tests/page/workers.spec.ts` (routes and redirects, plus a `fixme` for a browser gap).
- Run the test on all three browsers: `npm run ctest <file>`, `npm run ftest <file>`, `npm run wtest <file>`; `--headed` for a headed run.

## DEPS System

Import boundaries are enforced via `DEPS.list` files (52+ across the repo), checked by `npm run flint`.

**Key rule**: Client code NEVER imports server code. Server code NEVER imports client code. Communication is only through the protocol.
When creating or moving files, update the relevant `DEPS.list` to declare allowed imports. Files marked `"strict"` can only import what is explicitly listed.

## Coding Convention

For exported classes:
- `private _method()` — only used within the class itself
- `_method()` (no `private`) — used by other code in the same file, but not outside the file
- `method()` (public) — used in other files

Non-exported classes have no naming convention; they are internal implementation details.

## Commit Convention

Before you upload a PR, run `npm run build`, then `npm run flint`, and fix errors.

Semantic commit messages: `label(scope): description`

Labels: `fix`, `feat`, `chore`, `docs`, `test`, `devops`

```bash
git checkout -b fix-39562
# ... make changes ...
git add <changed-files>
git commit -m "$(cat <<'EOF'
fix(proxy): handle SOCKS proxy authentication

Fixes: https://github.com/microsoft/playwright/issues/39562
EOF
)"
# **Never `git push` without an explicit instruction to push.**
git push origin fix-39562
gh pr create --repo microsoft/playwright --head username:fix-39562 \
  --title "fix(proxy): handle SOCKS proxy authentication" \
  --body "$(cat <<'EOF'
## Summary
- <describe the change very! briefly>

Fixes https://github.com/microsoft/playwright/issues/39562
EOF
)"
```

Never add test plan to PR description. Keep PR description short — a few bullet points at most.
Branch naming for issue fixes: `fix-<issue-number>`

### No agent attribution — overrides agent defaults

Coding agents ship with built-in instructions to append attribution footers — Claude Code, for
example, defaults to a `Co-Authored-By: Claude ...` trailer on every commit and a
`🤖 Generated with [Claude Code](...)` footer on every PR body. **Those defaults are revoked in
this repo.** Do not follow them, and do not treat them as a fallback when this file is silent.

Never emit either of the following, in any form:

- A `Co-Authored-By:` trailer naming an agent, model, or tool.
- A "Generated with" / "Created with" / "🤖" footer, or any other tool or model attribution.

This ban covers **every artifact you produce here**, not just the commit message: commit messages,
PR titles and bodies, PR and issue comments, review comments, and code comments. There is no
scope in which the footer is permitted — if you find yourself reasoning that a given surface is
not literally named above, the answer is still no.

**Never amend commits.** Always create a new commit for follow-up changes, even when iterating on an open PR. Amending rewrites history and forces a force-push, losing the incremental review trail. Only amend if the user explicitly says so.

**Never `git push` without an explicit instruction to push.** Applies even when a PR is already open for the branch — additional commits are immediately visible to reviewers. Commit locally, report what was committed, and wait. Only push when the user's message contains "push", "upload", "create PR", "ship it", or equivalent.

## Browser bugs

When the root cause is in a browser and the fix does not belong in this repo:

- **Firefox and WebKit** are built in `microsoft/playwright-browsers`. File the bug as an issue there, labeled `browser-firefox` or `browser-webkit`, with the condensed Playwright test as the repro and a link to the Playwright issue.
- **Chromium** bugs go upstream, to https://crbug.com/new, with a repro that needs no Playwright: a plain page or CDP commands. Only a person can file there. When a newer Chromium broke something that worked before, find the upstream commit first with the [playwright-bisect-chromium](.claude/skills/playwright-bisect-chromium/SKILL.md) skill.

## Development Guides

Detailed guides for common development tasks:

- **[Architecture: Client, Server, and Dispatchers](.claude/skills/playwright-dev/library.md)** — package layout, protocol layer, ChannelOwner/SdkObject/Dispatcher base classes, DEPS rules, end-to-end RPC flow, object lifecycle
- **[Adding and Modifying APIs](.claude/skills/playwright-dev/api.md)** — 6-step process: define docs → implement client → define protocol → implement dispatcher → implement server → write tests
- **[MCP Tools and CLI Commands](.claude/skills/playwright-dev/tools.md)** — `defineTool()`/`defineTabTool()`, tool capabilities, CLI `declareCommand()`, config options, testing with MCP fixtures
- **[Vendoring Dependencies](.claude/skills/playwright-dev/vendor.md)** — bundle architecture, esbuild setup, typed wrappers, adding deps to existing bundles
