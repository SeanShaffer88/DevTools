<template>
  <div class="tab-installed" ref="scroller">
    <div v-if="store.canRenderScripts"
         v-show="!store.title /* edit::onActivated + onDeactivated */">
      <header class="flex">
        <div v-if="!showRecycle">
          <div class="btn-group">
            <Dropdown
              v-model="state.menuNew"
              :class="{active: state.menuNew}"
              :closeAfterClick="true">
              <Tooltip :content="i18n('buttonNew')" placement="bottom" align="start" :disabled="state.menuNew">
                <a class="btn-ghost" tabindex="0" ref="$menuNew">
                  <Icon name="plus" />
                </a>
              </Tooltip>
              <template #content>
                <a class="dropdown-menu-item"
                  v-for="([text, props], i) in NEW_LINKS" :key="i" v-text="text" v-bind="props"/>
                <a class="dropdown-menu-item" v-if="isEmpty"
                  v-text="`${i18n('buttonImportData')} / ${i18n('labelSync')}...`"
                  @click="store.isEmpty = 1; setLocationHash(TAB_SETTINGS)"/>
              </template>
            </Dropdown>
            <Tooltip :content="i18n('updateScriptsAll')" placement="bottom" align="start">
              <a class="btn-ghost" tabindex="0" @click="handleActionUpdate(null, $event.target)">
                <Icon name="refresh" />
              </a>
            </Tooltip>
          </div>
          <div v-if="filteredScripts.length" class="btn-group filtered">
            <Tooltip
              v-for="({ icon, num, tooltip }, key) in batchActions" :key
              :content="tooltip[state.batchAction.action === key ? 1 : 0]"
              placement="bottom"
              align="start"
            >
              <a
                class="btn-ghost"
                :class="{
                  'has-error': state.batchAction.action === key,
                  disabled: store.batch,
                }"
                :data-batch-action="key"
                tabindex="0"
                @click.prevent="handleBatchAction"
              >
                <Icon :name="icon" />
                <sub v-text="num" v-if="num" />
                <span class="ml-1" v-if="state.batchAction.action === key">❗</span>
              </a>
            </Tooltip>
            <Tooltip :content="state.sizes" placement="bottom">
              <div class="btn-hint subtle"
                   v-text="i18n('hintForBatchAction', `${filteredScripts.length}`)"
                   :data-size="state.size"/>
            </Tooltip>
            <Tooltip :content="i18n('buttonUndo')" placement="bottom" align="start">
              <a v-if="state.batchAction.undo" class="btn-ghost" tabindex="0" @click.prevent="state.batchAction.undo">
                <Icon name="undo" />
              </a>
            </Tooltip>
          </div>
        </div>
        <Tooltip v-else :content="state.sizes" :disabled="!state.sizes" placement="bottom">
          <div class="ml-2" v-text="i18n('headerRecycleBin')" :data-size="state.size" />
        </Tooltip>
        <div>
          <!-- form and id are required for the built-in autocomplete using entered values -->
          <form class="filter-search hidden-xs" @submit.prevent>
            <label>
              <input
                type="search"
                :class="{'has-error': state.search.error}"
                :title="state.search.error"
                :placeholder="i18n('labelSearchScript')"
                v-model="state.search.value"
                ref="refSearch"
                id="installed-search">
              <Icon name="search" />
            </label>
          </form>
          <Dropdown align="right">
            <a class="btn-ghost" tabindex="0" :class="{'has-error': state.search.error}">
              <Icon name="question"></Icon>
            </a>
            <template #content>
              <div class="filter-search-tooltip">
                <div class="has-error" v-if="state.search.error" v-text="state.search.error" />
                <div v-html="i18n('titleSearchHintV2')" />
              </div>
            </template>
          </Dropdown>
          <div class="sorter flex center-items mx-1"
               :class="{ 'btn-ghost': collapseSorter }">
            <Tooltip align="end"
                     :content="i18n('sortOrder').trim() + (collapseSorter ? ' ' + (currentSort.text || '') : '')">
              <component :is="currentSort.icon || IconSort"/>
            </Tooltip>
            <select :value="filters.sort" @change="handleOrderChange" class="h-100">
              <option
                v-for="({text, title}, name) in sortModes"
                v-text="text"
                :title
                :key="name"
                :value="name">
              </option>
            </select>
          </div>
          <Dropdown align="right" class="settings">
            <Tooltip :content="i18n('labelSettings')" placement="bottom" align="end">
              <a class="btn-ghost" tabindex="0">
                <Icon name="cog" />
              </a>
            </Tooltip>
            <template #content>
              <div v-show="currentSort">
                <SettingCheck name="filters.showEnabledFirst"
                  :label="i18n('optionShowEnabledFirst')" />
              </div>
              <div>
                <SettingCheck name="filters.showOrder" :label="i18n('labelShowOrder')" />
              </div>
              <div>
                <SettingCheck name="filters.showVisit" :label="i18n('labelShowVisited')" />
              </div>
              <div class="mr-2c">
                <SettingCheck name="filters.viewTable" :label="i18n('labelViewTable')" />
                <SettingCheck name="filters.viewSingleColumn" :label="i18n('labelViewSingleColumn')" />
              </div>
            </template>
          </Dropdown>
        </div>
      </header>
      <div v-if="showRecycle" class="hint mx-1 my-1 flex flex-col">
        <span v-text="i18n('hintRecycleBin')"/>
        <a v-if="store.removedScripts.length" v-text="i18n('buttonEmptyRecycleBin')" tabindex="0"
           @click="handleEmptyRecycleBin"/>
      </div>
      <div v-else-if="message" class="hint mx-1 my-1 flex flex-col" v-text="message"></div>
      <div class="scripts"
        v-focus="!state.script"
        ref="refList"
        :style="`--num-columns:${state.numColumns}`"
        :data-columns="state.numColumns"
        :data-show-order="filters.showOrder || null"
        :data-table="filters.viewTable || null">
        <ScriptItem
          v-for="(script, index) in sortedScripts"
          v-show="script.$cache.show !== 0"
          :key="script.props.id"
          :focused="selectedScript === script"
          :showHotkeys="state.showHotkeys"
          :showVisit="filters.showVisit || filters.sort.startsWith('visit')"
          :script
          :draggable
          :visible="index < state.batchRender.limit"
          :viewTable="filters.viewTable"
          :hotkeys="scriptHotkeys"
          :activeTags
          @remove="handleActionRemove"
          @restore="handleActionRestore"
          @toggle="handleActionToggle"
          @update="handleActionUpdate"
          @scrollDelta="handleSmoothScroll"
          @clickTag="handleClickTag"
        />
      </div>
    </div>
    <teleport to="body">
      <!-- KeepAlive must be a direct parent of the component, not of teleport -->
      <KeepAlive :key="store.route.hash" :max="5">
      <edit
        v-if="state.script"
        :dirty="state.dirty"
        :initial="state.script"
        :initial-code="state.code"
        :read-only="!!state.script.config.removed"
        @close="handleEditScript()"
      />
      </KeepAlive>
    </teleport>
  </div>
</template>

<script setup>
import { computed, reactive, nextTick, onMounted, watch, ref, onBeforeUnmount } from 'vue';
import Dropdown from 'vueleton/lib/dropdown';
import Tooltip from 'vueleton/lib/tooltip';
import { i18n, sendCmdDirectly, debounce, ensureArray, trueJoin, formatByteLength, readBlob } from '@/common';
import { INFERRED } from '@/common/consts';
import handlers from '@/common/handlers';
import options from '@/common/options';
import hookSetting from '@/common/hook-setting';
import { forEachKey } from '@/common/object';
import { setRoute, lastRoute } from '@/common/router';
import { keyboardService, handleTabNavigation, kbdTypable, kbdNavigatable } from '@/common/keyboard';
import { loadData } from '@/options';
import { TAB_SETTINGS } from '@/common/safe-globals'; // added as a banner but Vue needs an import
import { EXTERNAL_LINK_PROPS, getActiveElement, isTouch, showConfirmation, showMessage, vFocus } from '@/common/ui';
import Icon from '@/common/ui/icon';
import IconAlpha from '~icons/mdi/sort-alphabetical-ascending';
import IconAlphaDown from '~icons/mdi/sort-alphabetical-descending';
import IconCalendar from '~icons/mdi/sort-calendar-ascending';
import IconCalendarDown from '~icons/mdi/sort-calendar-descending';
import IconClock from '~icons/mdi/sort-clock-ascending-outline';
import IconClockDown from '~icons/mdi/sort-clock-descending-outline';
import IconSmallBig from '~icons/tabler/sort-ascending-small-big';
import IconBigSmall from '~icons/tabler/sort-descending-small-big';
import IconSort from '~icons/mdi/sort-ascending';
import IconSortDown from '~icons/mdi/sort-descending';
import IconUser from '~icons/tdesign/user-arrow-up';
import IconUserDown from '~icons/tdesign/user-arrow-down';
import SettingCheck from '@/common/ui/setting-check';
import { customCssElem, onMediaWidth, NARROW_WIDTH } from '@/common/ui/style';
import { getSortCollator } from '@/common/ui/util';
import {
  createSearchRules, filteredScripts, formatSizesStr, markRemove, performSearch, runInBatch, setLocationHash,
  SIZE_TITLES, sortedScripts, store, TOGGLE_OFF, TOGGLE_ON,
} from '../utils';
import toggleDragging from '../utils/dragging';
import ScriptItem from './script-item';
import Edit from './edit';

const handleNewScript = () => handleEditScript('_new');
const NEW_LINKS = [
  [i18n('buttonNew'),
    { tabIndex: 0, onclick: handleNewScript }],
  [i18n('buttonNewFromFile'),
    { tabIndex: 0, onclick: handleNewScriptFromFile }],
  [i18n('installFrom', 'OpenUserJS'),
    { href: 'https://openuserjs.org/', ...EXTERNAL_LINK_PROPS }],
  [i18n('installFrom', 'GreasyFork'),
    { href: `https://greasyfork.org/scripts`, ...EXTERNAL_LINK_PROPS }],
  [i18n('buttonInstallFromURL'),
    { tabIndex: 0, onclick: handleInstallFromURL }],
];
const EDIT = 'edit';
const REMOVE = 'remove';
const RESTORE = 'restore';
const TOGGLE = 'toggle';
const UNDO = 'undo';
const UPDATE = 'update';
const collator = getSortCollator();
const cmpName = (a, b) => collator.compare(a.$cache.lowerName, b.$cache.lowerName);
/** @type {{ [key:string]: SortMode }} */
const sortModes = [
  ['exec', i18n('filterExecutionOrder'), IconSort, IconSortDown],
  ['alpha', i18n('filterAlphabeticalOrder'), IconAlpha, IconAlphaDown, cmpName],
  ['author',
    i18n('labelAuthor').replace(/[\s:\u{A789}\u{FE13}\u{FE55}\u{FF1A}]+/u, '').toLowerCase(),
    IconUser, IconUserDown,
    (a, b) => collator.compare(a.meta.author || '', b.meta.author || '') || cmpName(a, b)],
  [UPDATE, i18n('filterLastUpdateOrder'), IconClock, IconClockDown,
    (a, b) => (+b.props.lastUpdated || 0) - (+a.props.lastUpdated || 0)],
  ['visit', i18n('filterLastVisitOrder'), IconCalendar, IconCalendarDown,
    (a, b) => (b[INFERRED].visit || 0) - (a[INFERRED].visit || 0),
    i18n('filterLastVisitOrderTooltip')],
  ['size', i18n('filterSize'), IconSmallBig, IconBigSmall,
    (a, b) => a.$cache.sizeNum - b.$cache.sizeNum],
].reduce((res, [key, text, icon, iconRev, compare, title]) => {
  res[key] = {
    text,
    title,
    icon,
    compare,
  };
  res[key + '-'] = /**@namespace SortMode*/{
    text: text + ' \u25BC', // ▼
    title: title,
    icon: iconRev,
    reversed: true,
    compare: compare || ((a, b) => a.props.position - b.props.position),
  };
  return res;
}, {});
const filters = reactive({
  /** @type {Boolean} */ showEnabledFirst: null,
  /** @type {Boolean} */ showOrder: null,
  /** @type {Boolean} */ showVisit: null,
  /** @type {Boolean} */ viewSingleColumn: null,
  /** @type {Boolean} */ viewTable: null,
  sort: '',
});
filters::forEachKey(key => {
  hookSetting(`filters.${key}`, (val) => {
    filters[key] = key === 'sort' && !sortModes[val]
      ? Object.keys(sortModes)[0]
      : val;
  });
});

const conditionAll = 'tabScripts';
const conditionSearch = `${conditionAll} && ${kbdTypable}`;
const conditionNotSearch = `${conditionAll} && !${kbdTypable}`;
const conditionNotNavigatable = `${conditionAll} && !${kbdNavigatable}`;
const conditionScriptFocused = `${conditionNotSearch} && selectedScript && !showRecycle`;
const conditionScriptFocusedRecycle = `${conditionNotSearch} && selectedScript && showRecycle`;
const conditionScriptFocusedWithoutButton = `${conditionNotSearch} && !buttonFocus`;
const conditionHotkeys = `${conditionNotSearch} && selectedScript && showHotkeys`;
const scriptHotkeys = {
  [EDIT]: 'e',
  [TOGGLE]: 'space',
  [UPDATE]: 'r',
  [RESTORE]: 'r',
  [REMOVE]: 'x',
};
const registerHotkey = (callback, items) => items.map(([key, condition, caseSensitive]) => (
  keyboardService.register(key, callback, { condition, caseSensitive })
));

const MAX_BATCH_DURATION = 100;
const RENDER_ALL = 1e9;
let step = 0;

let columnsForTableMode = [];
let columnsForCardsMode = [];
let scrollTop1, scrollTop2;

let newScriptCode;

const $menuNew = ref();
const isEmpty = ref();
const collapseSorter = ref();
const refSearch = ref();
const refList = ref();
const scroller = ref();
const kScrollTop = 'scrollTop';

const state = reactive({
  focusedIndex: -1,
  menuNew: false,
  showHotkeys: false,
  search: store.search = {
    value: '',
    error: null,
    ...createSearchRules(''),
  },
  script: null,
  code: '',
  numColumns: 1,
  batchRender: {
    limit: step,
  },
  batchAction: {
    action: null,
    [UNDO]: null,
  },
  size: '',
  sizes: '',
});

const showRecycle = computed(() => store.route.paths[0] === TAB_RECYCLE);
const draggableRaw = computed(() => !showRecycle.value && filters.sort.startsWith('exec'));
const draggable = computed(() => isTouch && draggableRaw.value);
const currentSort = computed(() => sortModes[filters.sort] || false/* to avoid ?. for invalid mode */);
const selectedScript = computed(() => filteredScripts.value[state.focusedIndex]);
const message = computed(() => {
  if (!store.loaded) {
    return null;
  }
  if (state.search.rules.length
    ? !sortedScripts.value.find(s => s.$cache.show !== 0)
    : !sortedScripts.value.length
  ) {
    return i18n('labelNoSearchScripts');
  }
  return null;
});
const searchNeedsCodeIds = computed(() => state.search.rules.some(rule => !rule.scope || rule.scope === 'code')
        && store.scripts.filter(s => s.$cache.code == null).map(s => s.props.id));
const activeTags = computed(() => state.search.tokens.filter(token => token.prefix === '#' && !token.negative).map(token => token.parsed));
const getCurrentList = () => showRecycle.value ? store.removedScripts : store.scripts;
const getDataBatchAction = evt => evt.target.closest('[data-batch-action]');
const ALL_BATCH_ACTIONS = {
  [TOGGLE]: {
    icon: TOGGLE_ON,
    tooltip: [],
    tooltipOn: [i18n('batchActionEnable'), i18n('batchActionEnableConfirm')],
    tooltipOff: [i18n('batchActionDisable'), i18n('batchActionDisableConfirm')],
    arg(scripts) {
      const enabled = this.icon === TOGGLE_ON ? 1 : 0;
      return scripts.filter(s => +s.config.enabled !== enabled);
    },
    fn: scripts => Promise.all(scripts.map(handleActionToggle)),
  },
  [UPDATE]: {
    icon: 'refresh',
    tooltip: [i18n('batchActionUpdate'), i18n('batchActionUpdateConfirm')],
    fn: handleActionUpdate,
    [UNDO]: false,
  },
  [REMOVE]: {
    icon: 'trash',
    tooltip: [i18n('batchActionRemove'), i18n('batchActionRemoveConfirm')],
    async fn(scripts, el, undo) {
      await Promise.all(scripts.map(s => markRemove(s, !undo)));
      // nuking the ghosts because the user's intent was already confirmed
      if (!undo) store.scripts = [];
    },
  },
};
const batchActions = computed(() => {
  const scripts = filteredScripts.value;
  const num = scripts.length;
  const allShown = num === sortedScripts.value.length;
  let res = ALL_BATCH_ACTIONS;
  let toEnable = 0;
  let toUpdate = 0;
  for (const s of scripts) {
    toEnable += !s.config.enabled;
    if (!allShown) toUpdate += s.$canUpdate > 0;
  }
  res[TOGGLE].icon = toEnable ? TOGGLE_ON : TOGGLE_OFF;
  res[TOGGLE].tooltip = toEnable ? res[TOGGLE].tooltipOn : res[TOGGLE].tooltipOff;
  res[TOGGLE].num = toEnable < num ? toEnable : '';
  if (!toUpdate) ({ [UPDATE]: toUpdate, ...res } = res);
  else res[UPDATE].num = toUpdate < num ? toUpdate : '';
  return res;
});

const disposables = [];
const debouncedSearch = debounce(scheduleSearch, 100);
const lazyOrderUpdate = debounce(onUpdate, 50);

function resetList() {
  if (!showRecycle.value && store.needRefresh) {
    // Filter removed scripts when reload installed list
    store.scripts = store.scripts.filter(script => !script.config.removed);
    store.needRefresh = false;
  }
  state.focusedIndex = -1;
  onUpdate();
}
async function refreshUI() {
  const ids = searchNeedsCodeIds.value;
  if (ids?.length) await getCodeFromStorage(ids);
  onUpdate();
  onHashChange();
}
function sortScripts(scripts) {
  const { compare, reversed } = currentSort.value;
  const searching = state.search.rules.length;
  const enabledFirst = filters.showEnabledFirst;
  if (compare || enabledFirst || searching) {
    scripts.sort(!enabledFirst && !searching && !reversed
      ? compare
      : (a, b) => enabledFirst && (b.config.enabled - a.config.enabled)
        || searching && (b.$cache.show - a.$cache.show)
        || compare && (reversed ? compare(b, a) : compare(a, b)),
    );
  }
  sortedScripts.value = scripts;
}
/** @param onlyReorder - only set when invoked from watch() for options that reorder the list */
function onUpdate(onlyReorder) {
  const scripts = [...getCurrentList()];
  if (!onlyReorder) performSearch(scripts);
  sortScripts(scripts);
  filteredScripts.value = !onlyReorder && state.search.rules.length
    ? scripts.filter(s => s.$cache.show)
    : scripts;
  selectScript(state.focusedIndex);
  renderScripts();
}
async function handleInstallFromURL() {
  try {
    let url = await showConfirmation(i18n('hintInputURL'), {
      input: '',
      ok: { type: 'submit' },
    });
    url = url?.trim();
    if (url) {
      if (!url.includes('://')) url = `https://${url}`;
      // test if URL is valid
      new URL(url);
      await sendCmdDirectly('ConfirmInstall', { url });
    }
  } catch (err) {
    showErrorMessage(err);
  }
}
function handleNewScriptFromFile() {
  /** @type {HTMLInputElement} */
  const el = document.createElement('input');
  el.type = 'file';
  el.accept = 'application/javascript,text/javascript,text/plain,.js';
  el.style = 'display:none !important';
  document.body.appendChild(el);
  el.onchange = async () => {
    if (el.value) {
      try {
        newScriptCode = await readBlob(el.files[0], 'text');
        handleNewScript();
      } catch (err) {
        showErrorMessage(err);
      }
    }
    el.remove();
  };
  el.click();
}
function showErrorMessage(err) {
  showMessage({ text: err.message || err });
}
async function moveScript(from, to) {
  if (from === to) return;
  const scripts = filteredScripts.value;
  const allScripts = store.scripts;
  const script = scripts[from];
  const aFrom = allScripts.indexOf(script);
  const aTo = allScripts.indexOf(scripts[to]);
  const { id } = script.props;
  if (await sendCmdDirectly('Move', { id, offset: aTo - aFrom })) {
    allScripts.splice(aFrom, 1);
    allScripts.splice(aTo, 0, script);
    allScripts.forEach((scr, i) => { scr.props.position = i + 1; });
    onUpdate();
  }
}
function handleOrderChange(e) {
  options.set('filters.sort',
    // Not waiting for debounced options hook to ensure UI always matches <select>
    filters.sort = e.target.value);
}
function handleEditScript(id) {
  const pathname = [showRecycle.value ? TAB_RECYCLE : SCRIPTS, id]::trueJoin('/');
  if (!id && pathname === lastRoute().pathname) {
    window.history.back();
  } else {
    setRoute(pathname);
  }
}
async function onHashChange() {
  const [tab, id, tabId] = store.route.paths;
  if (__.MV3 && id) store.busyId = id;
  const _new = id === '_new' && await sendCmdDirectly('NewScript', {
    code: newScriptCode,
    .../^\d+$/.test(tabId) && { tabId: +tabId },
  });
  const script = _new || +id && getCurrentList().find(s => s.props.id === +id);
  const scrollElem1 = scroller.value;
  const scrollElem2 = document.scrollingElement; // for compact layout
  if (script && !state.script) { // going into editor
    scrollTop1 = scrollElem1[kScrollTop];
    scrollTop2 = scrollElem2[kScrollTop];
  }
  if (script) {
    state.code = newScriptCode || _new.code || await sendCmdDirectly('GetScriptCode', id);
    state.dirty = !!newScriptCode;
    if (_new) delete script.code;
    state.script = script;
  }
  newScriptCode = '';
  if (__.MV3 && id) store.busyId = 0;
  if (script) return;
  // Strip the invalid id from the URL so |App| can render the aside,
  // which was hidden to avoid flicker on initial page load directly into the editor.
  if (id) setRoute(tab, true);
  // First time showing the list we need to tell v-if to keep it forever
  if (!store.canRenderScripts) {
    store.canRenderScripts = true;
    loadData();
  }
  renderScripts();
  if (state.script) {
    state.script = null;
    nextTick(() => { // scroll position has to be restored explicitly in Chrome and Firefox Android
      scrollElem1[kScrollTop] = scrollTop1;
      scrollElem2[kScrollTop] = scrollTop2;
    });
  }
}
async function renderScripts() {
  if (!store.canRenderScripts
  || state.batchRender.limit === RENDER_ALL
  /* Skip rendering as the editor is being closed right now and we only have 1 script,
     we'll render in the next call after all scripts data is requested. */
  || store.title) return;
  const scripts = sortedScripts.value;
  const { length } = scripts;
  let limit = 9;
  const batchRender = reactive({ limit });
  state.batchRender = batchRender;
  const startTime = performance.now();
  // If we entered a new loop of rendering, state.batchRender will no longer be batchRender
  while (limit < length && batchRender === state.batchRender) {
    if (step && state.search.rules.length) {
      // Only visible items contribute to the batch size
      for (let vis = 0; vis < step && limit < length; limit += 1) {
        vis += scripts[limit].$cache.show ? 1 : 0;
      }
    } else {
      limit += step || 1;
    }
    batchRender.limit = limit;
    // Let the browser calculate the layout so we know the real duration of the batch
    const now = await new Promise(requestAnimationFrame);
    if (!step && now - startTime >= MAX_BATCH_DURATION) {
      step = limit * 2; // the first batch is slow to render because it has more work to do
    }
  }
  // Completed the potentially slow initial creation, subsequent redraws will be fast
  if (length && limit >= length) batchRender.limit = RENDER_ALL;
}
function scheduleSearch() {
  try {
    state.search = store.search = {
      ...state.search,
      ...createSearchRules(state.search.value),
    };
    state.search.error = null;
  } catch (err) {
    state.search.error = err.message;
  }
  const ids = searchNeedsCodeIds.value;
  if (ids?.length) getCodeFromStorage(ids);
  if (!state.search.rules.length) {
    for (const { $cache } of /**@type{UIScript[]}*/store.scripts) {
      $cache.mark = $cache.show = null;
    }
  }
  onUpdate();
}
async function getCodeFromStorage(ids) {
  const data = await sendCmdDirectly('GetScriptCode', ids);
  store.scripts.forEach(({ $cache, props: { id } }) => {
    if (id in data) $cache.code = data[id];
  });
  onUpdate();
}
async function handleEmptyRecycleBin() {
  if (await showConfirmation(i18n('buttonEmptyRecycleBin'))) {
    sendCmdDirectly('CheckRemove', { force: true });
    store.removedScripts = [];
  }
}
function adjustNarrowWidth(isTable) {
  adjustScriptWidth();
  onMediaWidth(NARROW_WIDTH + (isTable ? 90 / devicePixelRatio : 0), true);
}
function adjustScriptWidth() {
  const widths = filters.viewTable ? columnsForTableMode : columnsForCardsMode;
  state.numColumns = filters.viewSingleColumn ? 1
    : widths.findIndex(w => window.innerWidth < w) + 1 || widths.length + 1;
}
function selectScript(index) {
  index = Math.min(index, filteredScripts.value.length - 1);
  index = Math.max(index, -1);
  if (index !== state.focusedIndex) {
    state.focusedIndex = index;
  }
}
function handleActionRemove(script) {
  if (!script.config.removed) {
    markRemove(script, 1);
  } else {
    sendCmdDirectly('RemoveScripts', [script.props.id]);
  }
}
async function handleActionRestore(script) {
  try {
    await markRemove(script, 0);
  } catch (err) {
    showConfirmation(`\
${err.message || err}

@namespace ${script.meta.namespace}
@name ${script.meta.name}`, {
      cancel: false,
    });
  }
}
function handleActionToggle(script) {
  return sendCmdDirectly('UpdateScriptInfo', {
    id: script.props.id,
    config: {
      enabled: script.config.enabled ? 0 : 1,
    },
  });
}
/**
 * @param {VMScript|VMScript[]} [what]
 * @param {Element} [el]
 */
async function handleActionUpdate(what, el) {
  if (el) (el = (el.querySelector('svg') || el.closest('svg') || el).classList).add('rotate');
  await sendCmdDirectly('CheckUpdate', !!what && {
    ids: ensureArray(what).map(s => s.props.id),
    force: what.force,
  });
  el?.remove('rotate');
}
function handleClickTag(tag) {
  if (activeTags.value.includes(tag)) {
    // remove tag
    const tokens = state.search.tokens.filter(token => !(token.prefix === '#' && token.parsed === tag));
    state.search.value = tokens.map(token => `${token.prefix}${token.raw}`).join(' ');
  } else {
    // add tag
    state.search.value = [
      state.search.value.trim(),
      /\s/.test(tag) ? `#"${tag}" ` : `#${tag} `,
    ]::trueJoin(' ');
  }
}
function handleSmoothScroll(delta) {
  if (!delta) return;
  const el = refList.value;
  el.scroll({
    top: el.scrollTop + delta,
    behavior: 'smooth',
  });
}
function handleBatchAction(e) {
  if (store.batch) return;
  const button = getDataBatchAction(e);
  const stateBA = state.batchAction;
  let action = button?.dataset.batchAction;
  if (stateBA.action === action) {
    // Confirmed
    const baVal = batchActions.value[action] || {};
    const scripts = filteredScripts.value;
    const arg = baVal.arg?.(scripts) || scripts;
    const fn = baVal.fn;
    const batchArgs = [fn, arg, button];
    if (fn) runInBatch(...batchArgs);
    stateBA[UNDO] = fn && baVal[UNDO] !== false && (() => {
      runInBatch(...batchArgs, UNDO);
      stateBA[UNDO] = null;
    });
    action = '';
    button.blur();
  }
  stateBA.action = action;
}
function bindKeys() {
  const handleFocus = () => {
    keyboardService.setContext('buttonFocus', getActiveElement()?.tabIndex >= 0);
  };
  addEventListener('focus', handleFocus, true);
  disposables.push(
    () => removeEventListener('focus', handleFocus, true),
    ...IS_FIREFOX ? [
      keyboardService.register('tab', () => {
        handleTabNavigation(1);
      }),
      keyboardService.register('s-tab', () => {
        handleTabNavigation(-1);
      }),
    ] : [],
    ...registerHotkey(() => {
      refSearch.value?.focus();
    }, [
        ['ctrlcmd-f', conditionAll],
        ['/', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      refSearch.value?.blur();
    }, [
        ['enter', `${conditionSearch} && !${kbdNavigatable}`],
      ]),
    ...registerHotkey(() => {
      state.showHotkeys = false;
    }, [
        ['escape', conditionHotkeys],
        ['q', conditionHotkeys, true],
      ]),
    ...registerHotkey(() => {
      let index = state.focusedIndex;
      if (index < 0) index = 0;
      else index += state.numColumns;
      if (index < filteredScripts.value.length) {
        selectScript(index);
      }
    }, [
        ['ctrlcmd-down', conditionAll],
        ['down', conditionNotNavigatable],
        ['j', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      const index = state.focusedIndex - state.numColumns;
      if (index >= 0) {
        selectScript(index);
      }
    }, [
        ['ctrlcmd-up', conditionAll],
        ['up', conditionNotNavigatable],
        ['k', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      selectScript(state.focusedIndex - 1);
    }, [
        ['ctrlcmd-left', conditionAll],
        ['left', conditionNotSearch],
        ['h', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      selectScript(state.focusedIndex + 1);
    }, [
        ['ctrlcmd-right', conditionAll],
        ['right', conditionNotSearch],
        ['l', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      selectScript(0);
    }, [
        ['ctrlcmd-home', conditionAll],
        ['g g', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      selectScript(filteredScripts.value.length - 1);
    }, [
        ['ctrlcmd-end', conditionAll],
        ['G', conditionNotSearch, true],
      ]),
    ...registerHotkey(() => {
      handleEditScript(selectedScript.value.props.id);
    }, [
        [scriptHotkeys[EDIT], conditionScriptFocused, true],
        // Enter should only work when no button is focused
        ['enter', conditionScriptFocusedWithoutButton],
      ]),
    ...registerHotkey(() => {
      handleActionRemove(selectedScript.value);
    }, [
        ['delete', conditionScriptFocused],
        [scriptHotkeys[REMOVE], conditionScriptFocused, true],
      ]),
    ...registerHotkey(() => {
      handleActionUpdate(selectedScript.value);
    }, [
        [scriptHotkeys[UPDATE], conditionScriptFocused, true],
      ]),
    ...registerHotkey(() => {
      handleActionToggle(selectedScript.value);
    }, [
        [scriptHotkeys[TOGGLE], conditionScriptFocused, true],
      ]),
    ...registerHotkey(() => {
      handleActionRestore(selectedScript.value);
    }, [
        [scriptHotkeys[RESTORE], conditionScriptFocusedRecycle, true],
      ]),
    ...registerHotkey(() => {
      state.showHotkeys = !state.showHotkeys;
    }, [
        ['?', conditionNotSearch, true],
      ]),
  );
}

function handleCancelBatchAction(e) {
  if (!getDataBatchAction(e)) {
    state.batchAction.action = null;
  }
}

resetList();
watch(showRecycle, resetList);
watch(() => store.canRenderScripts && refList.value && draggableRaw.value,
  dr => toggleDragging(refList.value, moveScript, dr));
watch(() => state.search.value, debouncedSearch);
watch(() => [filters.sort, filters.showEnabledFirst], lazyOrderUpdate);
disposables.push(
  watch(() => filters.viewSingleColumn, adjustScriptWidth),
  watch(() => filters.viewTable, adjustNarrowWidth, { immediate: true }),
);
onMediaWidth(700, false, val => {
  collapseSorter.value = val;
});
watch(getCurrentList, refreshUI);
watch(() => store.route.paths[1], onHashChange);
watch(() => store.scripts, val => {
  if ((isEmpty.value = !val.length) && (val = $menuNew.value)) {
    val.focus(); // for Tab navigation and focus highlight
    val.click();
  }
});
watch(selectedScript, script => {
  keyboardService.setContext('selectedScript', script);
});
watch(() => state.showHotkeys, value => {
  keyboardService.setContext('showHotkeys', value);
});
watch(filteredScripts, value => {
  const totals = Array(SIZE_TITLES.length).fill(0);
  for (const script of value) {
    for (let i = 0; i < totals.length; i++) {
      totals[i] += script.$cache.sizesNum[i];
    }
  }
  let sum = 0;
  let str = '';
  totals.forEach((val, i) => {
    sum += val;
    if (val) str += `${SIZE_TITLES[i]}: ${formatByteLength(val)}\n`;
  });
  // `null` removes the attribute to disable the ::after CSS rule
  state.size = sum ? formatByteLength(sum).replace(' ', '') : null;
  state.sizes = sum ? formatSizesStr(str) : '';
});

Object.assign(handlers, {
  Visited(data) {
    let dirty;
    for (const list of [store.scripts, store.removedScripts]) {
      for (const /** @type {VMScript} */ scr of list) {
        const val = data[scr.props.id];
        if (val) dirty = scr[INFERRED].visit = val;
      }
    }
    if (dirty && filters.sort.startsWith('visit')) {
      sortScripts([...getCurrentList()]);
    }
  },
});

onMounted(() => {
  // Ensure the correct UI is shown when mounted:
  // * on subsequent navigation via history back/forward;
  // * on first initialization in some weird case the scripts got loaded early.
  if (store.loaded) refreshUI();
  // Extract --columns-cards and --columns-table from `:root` or `html` selector. CustomCSS may override it.
  if (!columnsForCardsMode.length) {
    const style = customCssElem?.textContent.match(/--columns-(cards|table)\b/)
      && getComputedStyle(document.documentElement);
    if (style) {
      for (const [type, arr] of [
        ['cards', columnsForCardsMode],
        ['table', columnsForTableMode],
      ]) {
        const val = style.getPropertyValue(`--columns-${type}`);
        if (val) arr.push(...val.split(',').map(Number).filter(Boolean));
      }
    } else {
      columnsForCardsMode.push(1300, 1900, 2500); // 1366x768, 1920x1080, 2560x1440
      columnsForTableMode.push(1600, 2500, 3400); // 1680x1050, 2560x1440, 3440x1440
    }
    addEventListener('resize', adjustScriptWidth);
  }
  adjustScriptWidth();
  bindKeys();

  document.addEventListener('mousedown', handleCancelBatchAction);
  disposables.push(() => document.removeEventListener('mousedown', handleCancelBatchAction));
});

onBeforeUnmount(() => {
  disposables.forEach(dispose => dispose());
});
</script>

<style>
$iconSize: 2rem; // from .icon in ui/style.css
$headerH: 4rem;
$headerBorder: 1px solid var(--fill-5);
.tab.tab-installed {
  height: 100vh;
  padding: 0;
  overflow: auto;
  header {
    position: sticky;
    top: 0;
    z-index: 1000;
    background: var(--fill-0-5);
    border-bottom: $headerBorder;
    justify-content: space-between;
    .btn-ghost, select {
      height: $iconSize;
    }
    > * {
      height: $headerH;
      align-items: center;
      display: inline-flex;
    }
    .vl-dropdown-toggle .icon {
      width: 1.25rem;
    }
    .vl-dropdown-menu {
      white-space: nowrap;
    }
  }
  @media (max-width: 640px) {
    header {
      flex-wrap: wrap;
      border-bottom: none;
      > * {
        flex: 1;
        border-bottom: $headerBorder;
      }
    }
    .filtered {
      border-right: none;
    }
  }
  .sorter {
    padding: 0; /* undo the dynamically assigned btn-ghost class in narrow mode */
    svg {
      width: $iconSize;
      height: $iconSize;
      padding: 2px;
      pointer-events: none;
    }
    &.btn-ghost {
      position: relative;
      > select {
        width: $iconSize;
        opacity: 0;
      }
      svg {
        z-index: 2;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
      }
    }
  }
  .narrow & {
    height: auto;
    overflow: visible;
    header {
      .hidden-sm {
        display: none;
      }
      > :last-child,
      .filter-search {
        flex: 1;
      }
    }
  }
  html:not(.narrow) & {
    header {
      .sorter {
        border: 1px solid transparent; /* to match btn-ghost class in narrow mode */
      }
    }
  }
}
.backdrop {
  text-align: center;
  color: var(--fill-8);
}
.backdrop > *,
.backdrop::after {
  display: inline-block;
  vertical-align: middle;
  font-size: 2rem;
}
.backdrop::after {
  content: ' ';
  width: 0;
  height: 100%;
}
.mask {
  background: rgba(0,0,0,.08);
  /*transition: opacity 1s;*/
}
.dropdown-menu-item {
  display: block;
  width: 100%;
  padding: .5rem;
  text-decoration: none;
  color: var(--fill-9);
  cursor: pointer;
  &:focus,
  &:hover {
    color: inherit;
    background: var(--fill-0-5);
  }
}
.filter-search {
  min-width: 5em;
  flex-basis: 10em;
  label {
    position: relative;
  }
  .icon {
    position: absolute;
    height: 100%;
    top: 0;
    right: .5rem;
  }
  input {
    width: 100%;
    height: $iconSize;
    padding-left: .5rem;
    padding-right: $iconSize;
  }
  &-tooltip {
    width: 24rem;
    max-width: 100vw;
    font-size: 14px;
    line-height: 1.5;
    white-space: pre-wrap;
  }
}
.settings {
  .vl-dropdown-menu {
    padding: 1rem;
    > :nth-last-child(n + 2) {
      margin-bottom: .5rem;
    }
  }
}

.btn-group {
  display: flex;
  height: 100%;
  align-items: center;
  border-right: 1px solid var(--fill-5);
  padding: 0 0.5rem;
  sub {
    position: absolute;
    color: var(--fill-7);
    margin-top: 1.5rem;
    font-size: x-small;
    text-align: center;
    width: 1rem;
  }
}
.btn-hint {
  margin: 0 0.5rem;
  cursor: default;
  min-width: 7em;
}

.hint {
  line-height: 1.5;
  color: var(--fill-6);
  place-items: center;
  & + .scripts {
    border-top: 1px solid var(--fill-5);
  }
}
[data-size]::after {
  content: ' (' attr(data-size) ')';
}
.rotate {
  animation: 4s linear infinite rotate;
}

@keyframes rotate {
  to {
    transform: rotate(1turn);
  }
}
</style>
