// SAFETY WARNING! Exports used by `injected` must make ::safe() calls and use __proto__:null

export const CHARSET_UTF8 = 'charset=UTF-8';
export const FORM_URLENCODED = 'application/x-www-form-urlencoded';
export const INFERRED = 'inferred';
export const HOMEPAGE_URL = 'homepageURL';
export const SUPPORT_URL = 'supportURL';

/** A relaxed check, see METABLOCK_RE description */
export const USERSCRIPT_META_INTRO = '==UserScript==';
/** A strictly valid metablock should start at the beginning of the line:
 * "// ==UserScript==" with exactly one \x20 space inside.
 * To match Tampermonkey's relaxed parsing, we allow any preceding text at line start
 * (i.e. not just spaces for indented metablock comments, but literally anything)
 * and inside, but we'll warn about this later in the installer/editor. */
export const METABLOCK_RE = regex({ disable: { n: true } })`
# 1          2           3
  ((?:^|\n)(.*?)\/\/([\x20\t]*)==UserScript==)
# 4
  ([\s\S]*?\n)
# 5  6          7
  ((.*?)\/\/([\x20\t]*)==\/UserScript==)
`;
export const META_STR = 'metaStr';
export const ESC_GLOB_RE = /[\\.?+[\]{}()|^$]/g;
export const ESC_STR_RE = /[*\\.?+[\]{}()|^$]/g;
export const NEWLINE_END_RE = /\n((?!\n)\s)*$/;
export const WATCH_STORAGE = 'watchStorage';

// setTimeout truncates the delay to a 32-bit signed integer so the max delay is ~24 days
export const TIMEOUT_MAX = 0x7FFF_FFFF;
export const TIMEOUT_HOUR = 60 * 60 * 1000;
export const TIMEOUT_24HOURS = 24 * 60 * 60 * 1000;
export const TIMEOUT_WEEK = 7 * 24 * 60 * 60 * 1000;

export const BLACKLIST = 'blacklist';
export const BLACKLIST_NET = BLACKLIST + 'Net';
export const BLOB_LIFE = 60e3;
export const ERRORS = 'Errors';
export const RUN_AT_RE = /^document-(start|body|end|idle)$/;
export const KNOWN_INJECT_INTO = {
  // Using the default injection order: auto, page, content
  [AUTO]: 1,
  [PAGE]: 1,
  [CONTENT]: 1,
};
export const NO_CACHE = { cache: 'no-cache' };
export const __CODE = /*@__PURE__*/Symbol('code'); // not enumerable and stripped when serializing
export const UA_PROPS = ['userAgent', 'brands', 'mobile', 'platform'];
export const TL_AWAIT = 'topLevelAwait';
export const UNWRAP = 'unwrap';
export const FETCH_OPTS = 'fetchOpts';
export const ERR_BAD_PATTERN = 'Bad pattern';
export const VM_HOME = 'https://violentmonkey.github.io/';
export const VM_DOCS_INJECT_INTO = VM_HOME + 'posts/inject-into-context/';
export const VM_DOCS_MATCHING = VM_HOME + 'api/matching/';
export const GLOB_ALL = '*://*/*';
export const FILE_GLOB_ALL = 'file://*/*';
export const XHR_COOKIE_RE = /:\W+([-\w]+)/; // extracts ://id in Chrome, ://{id} in Firefox
/** @type {(str: string, opts?: {}) => Uint8Array} */
export const U8_fromBase64 = __.INJECTED !== 'injected-web' && Uint8Array.fromBase64;
export const UPLOAD = 'upload';
export const GM_API_NAMES = [
  'GM',
  'GM_addElement',
  'GM_addStyle',
  'GM_addValueChangeListener',
  'GM_cookie',
  'GM_deleteValue',
  'GM_deleteValues',
  'GM_download',
  'GM_getResourceText',
  'GM_getResourceURL',
  'GM_getValue',
  'GM_getValues',
  'GM_info',
  'GM_listValues',
  'GM_log',
  'GM_notification',
  'GM_openInTab',
  'GM_registerMenuCommand',
  'GM_removeValueChangeListener',
  'GM_setClipboard',
  'GM_setValue',
  'GM_setValues',
  'GM_unregisterMenuCommand',
  'GM_xmlhttpRequest',
  'unsafeWindow',
];
export const GM4_ALIAS = {
  __proto__: null,
  getResourceURL: 'getResourceUrl',
  xmlhttpRequest: 'xmlHttpRequest',
};
export const kDownloadMode = 'downloadMode';
export const kDownloads = 'downloads';
export const kOrigTag = 'origTag';
export const kTag = 'tag';
export const kMainFrame = 'main_frame';
export const kSubFrame = 'sub_frame';
export const kContentType = 'content-type';
export const CACHE_KEYS = 'cacheKeys';
export const REQ_KEYS = 'reqKeys';
export const VALUE_IDS = 'valueIds';
export const PROMISE = 'promise';
export const TLDJS = '/public/lib/tld.js';
