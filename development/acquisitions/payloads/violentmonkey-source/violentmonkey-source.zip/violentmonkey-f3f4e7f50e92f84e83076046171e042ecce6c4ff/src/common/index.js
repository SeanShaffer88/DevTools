// SAFETY WARNING! Exports used by `injected` must make ::safe() calls and use __proto__:null

import browser from './browser';
import { noop } from './util';

export { normalizeKeys } from './object';
export * from './messaging';
export * from './script';
export * from './string';
export * from './util';

export const ignoreChromeErrors = () => chrome.runtime.lastError;
export const browserWindows = !__.INJECTED && browser.windows;
export const defaultImage = !__.INJECTED && `${ICON_PREFIX}128.png`;

export function initHooks() {
  const hooks = new Set();
  return {
    hook(cb) {
      hooks.add(cb);
      return () => hooks.delete(cb);
    },
    fire(...data) {
      // Set#forEach correctly iterates the remainder even if current callback unhooks itself
      hooks.forEach(cb => cb(...data));
    },
  };
}

/** @return {chrome.tabs.Tab | void} */
export async function getTab(tabId) {
  try {
    return await browser.tabs.get(tabId);
  } catch {
    // Also throws synchronously if tabId is not a valid integer.
  }
}

/** `tabs.create` may resolve without a tab in some mobile browsers,
 * so the result may be empty
 * @return {Promise<chrome.tabs.Tab | void>} */
export const createTab = (props) => browser.tabs.create(props);

/** @return {Promise<chrome.tabs.Tab | void>} */
export async function getActiveTab(windowId) {
  let res = { active: true };
  if (windowId != null) res[kWindowId] = windowId; // not supported in Kiwi
  else res.currentWindow = true;
  [res] = await browser.tabs.query(res);
  // Chrome bug workaround when an undocked devtools window is focused
  if (!res && browserWindows && (res = await browserWindows.getCurrent().catch(noop))) {
    [res] = await browser.tabs.query({ active: true, [kWindowId]: res.id });
  }
  return res;
}
