import { ensureArray, ignoreChromeErrors, isEmpty, keepAlive } from '@/common';
import initCache from '@/common/cache';
import { INFERRED, WATCH_STORAGE } from '@/common/consts';
import { deepCopy, deepCopyDiff, deepSize, forEachEntry } from '@/common/object';
import { S_MSG_IN, S_MSG_OUT } from './broadcast';
import { dbKeys, initializeDatabase, sizesPrefixRe } from './db';
import { incognitoAllowed, init } from './init';
import { scriptSiteVisited, updateScriptMap } from './script';
import { flushSession, kScriptSizes, scriptSizes } from './session-data';
import storage, {
  fireStorageChanged, S_MOD_PRE, S_SCRIPT_PRE, S_VALUE, S_VALUE_PRE,
} from './storage';
import { clearValueOpener } from './values';

/** Throttling browser API for `storage.value`, processing requests sequentially,
 so that we can supersede an earlier chained request if it's obsolete now,
 e.g. in a chain like [GET:foo, SET:foo=bar] `bar` will be used in GET. */
let valuesToFlush = {};
/** @type {Object<string,function[]>} */
let valuesToWatch = {};
let flushTimer = 0;
let undoing;
const watchers = {};
/** Reading the entire db in init/vacuum/sizing shouldn't be cached for long. */
const TTL_SKIM = 5e3;
/** Keeping data for long time since chrome.storage.local is insanely slow in Chrome,
 * so reading just a few megabytes would inject all scripts after document-end. */
const TTL_MAIN = 3600e3;
/** Keeping tiny info for extended period of time as it's inexpensive. */
const TTL_TINY = 24 * 3600e3;
const cache = initCache({ lifetime: TTL_MAIN });
const api = /** @type {browser.storage.StorageArea} */ storage.api;
/** Using a simple delay with setTimeout to avoid infinite debouncing due to periodic activity */
const FLUSH_DELAY = 100;
const FLUSH_SIZE_STEP = 1e6; // each step increases delay by FLUSH_DELAY
const FLUSH_MAX_DELAY = 1000; // e.g. when writing more than 10MB for step=1MB and delay=100ms
export const clearStorageCache = () => {
  cache.destroy();
  dbKeys.clear();
};
export const storageCacheHas = cache.has;

export const cachedStorageApi = storage.api = {

  async get(keys) {
    const res = {};
    cache.batch(true);
    keys = keys?.filter(key => {
      const cached = cache.get(key);
      const ok = cached !== undefined;
      if (ok) res[key] = deepCopy(cached);
      return !ok && dbKeys.get(key) !== 0;
    });
    if (!keys || keys.length) {
      let lifetime, id;
      if (!keys) lifetime = TTL_SKIM; // DANGER! Must be `undefined` otherwise.
      (await api.get(keys))::forEachEntry(([key, val]) => {
        res[key] = val;
        dbKeys.set(key, 1);
        cache.put(key, deepCopy(val), lifetime);
        if (key.startsWith(S_SCRIPT_PRE)) {
          updateScriptMap(key, val);
        } else if (key.startsWith(S_MOD_PRE) && (id = +key.slice(S_MOD_PRE.length))) {
          scriptSiteVisited[id] = val;
        }
      });
      keys?.forEach(key => !hasOwnProperty(res, key) && dbKeys.set(key, 0));
    }
    cache.batch(false);
    return res;
  },

  async set(data, flushNow) {
    const toWrite = {};
    const keys = [];
    cache.batch(true);
    data::forEachEntry(([key, val]) => {
      const copy = deepCopyDiff(val, cache.get(key));
      if (copy !== undefined) {
        cache.put(key, copy);
        dbKeys.set(key, 1);
        keys.push(key);
        if (undoing) {
          toWrite[key] = val;
          return;
        }
        if (!flushNow && key.startsWith(S_VALUE_PRE)) {
          valuesToFlush[key] = copy;
        } else {
          toWrite[key] = val;
          if (key.startsWith(S_SCRIPT_PRE) && updateScriptMap(key, val) && val[INFERRED]) {
            delete (toWrite[key] = { ...val })[INFERRED];
          }
          updateScriptSizeContributor(key, val);
        }
      }
    });
    cache.batch(false);
    if (!isEmpty(toWrite)) await api.set(toWrite);
    if (undoing) return;
    if (keys.length && (!__.MV3 || !incognitoAllowed)) fireStorageChanged(keys, data);
    flushLater();
  },

  async remove(keys) {
    const toDelete = keys.filter(key => {
      let ok = dbKeys.get(key) !== 0;
      if (ok) {
        cache.del(key);
        dbKeys.set(key, 0);
        if (undoing) return ok;
        if (storage[S_VALUE].toId(key)) {
          valuesToFlush[key] = null;
          ok = false;
        } else {
          if (key.startsWith(S_SCRIPT_PRE)) updateScriptMap(key);
          updateScriptSizeContributor(key);
        }
      }
      return ok;
    });
    if (toDelete.length) await api.remove(toDelete);
    if (undoing) return;
    if (keys.length && (!__.MV3 || !incognitoAllowed)) fireStorageChanged(keys);
    flushLater();
  },
};

setInterval(() => {
  dbKeys.forEach((val, key) => !val && dbKeys.delete(key));
}, TTL_TINY);
if (!__.MV3) global[WATCH_STORAGE] = fn => {
  const id = performance.now();
  watchers[id] = fn;
  return id;
}; else init.then(() => incognitoAllowed &&
  api.onChanged.addListener(changes => {
    const keys = Object.keys(changes);
    for (const key of keys) {
      const val = changes[key] = changes[key].newValue;
      const exists = val !== undefined ? 1 : 0;
      if (key !== S_MSG_IN && key !== S_MSG_OUT) {
        if (exists) cache.put(key, val); else cache.del(key);
        dbKeys.set(key, exists);
      }
    }
    fireStorageChanged(keys, changes);
  })
);
browser.runtime.onConnect.addListener(port => {
  if (port.name === 'undoImport') return undoImport(port);
  if (!port.name.startsWith(WATCH_STORAGE)) return;
  const { id, cfg, tabId } = JSON.parse(port.name.slice(WATCH_STORAGE.length));
  const fn = id ? watchers[id] : port.postMessage.bind(port);
  const resolve = __.MV3 && keepAlive();
  watchStorage(fn, cfg);
  port.onDisconnect.addListener(() => {
    clearValueOpener(tabId);
    watchStorage(fn, cfg, false);
    delete watchers[id];
    if (__.MV3) resolve();
  });
});

function watchStorage(fn, cfg, state = true) {
  if (state && !valuesToWatch) {
    valuesToWatch = {};
  }
  cfg::forEachEntry(([area, ids]) => {
    const { prefix } = storage[area];
    for (const id of ensureArray(ids)) {
      const key = prefix + id;
      const list = valuesToWatch[key] || state && (valuesToWatch[key] = []);
      const i = list ? list.indexOf(fn) : -1;
      if (i >= 0 && !state) {
        list.splice(i, 1);
        if (!list.length) delete valuesToWatch[key];
      } else if (i < 0 && state) {
        list.push(fn);
      }
    }
  });
  if (isEmpty(valuesToWatch)) {
    valuesToWatch = null;
  }
}

async function updateScriptSizeContributor(key, val) {
  const area = sizesPrefixRe.exec(key);
  if (area && area[0] !== S_SCRIPT_PRE) {
    const size = scriptSizes[key] = deepSize(val);
    if (size === 2 && area[0] === S_VALUE_PRE) {
      scriptSizes[key] = 0; // don't count an empty {}
    }
    if (__.MV3) flushSession(kScriptSizes, scriptSizes);
  }
}

async function flush() {
  const keys = Object.keys(valuesToFlush);
  const toRemove = [];
  const toFlush = valuesToFlush;
  valuesToFlush = {};
  flushTimer = 0;
  keys.forEach(key => {
    const val = toFlush[key];
    if (!val) {
      delete toFlush[key];
      toRemove.push(key);
    }
    updateScriptSizeContributor(key, val);
  });
  if (!isEmpty(toFlush)) await api.set(toFlush);
  if (toRemove.length) await api.remove(toRemove);
  if (valuesToWatch) setTimeout(notifyWatchers, 0, toFlush, toRemove);
}

function flushLater() {
  if (!flushTimer && !isEmpty(valuesToFlush)) {
    flushTimer = setTimeout(flush,
      Math.min(FLUSH_MAX_DELAY, FLUSH_DELAY * Math.max(1, deepSize(valuesToFlush) / FLUSH_SIZE_STEP)));
  }
}

function notifyWatchers(toFlush, toRemove) {
  const byFn = new Map();
  let newValue;
  let changes;
  for (const key in valuesToWatch) {
    if ((newValue = toFlush[key]) || toRemove.includes(key)) {
      for (const fn of valuesToWatch[key]) {
        if (!(changes = byFn.get(fn))) byFn.set(fn, changes = {});
        changes[key] = { newValue };
      }
    }
  }
  byFn.forEach((val, fn) => fn(val));
}

async function undoImport(port) {
  let drop;
  let old;
  const resolve = __.MV3 && keepAlive();
  port.onDisconnect.addListener(() => {
    ignoreChromeErrors();
    drop = true;
    if (__.MV3) resolve();
  });
  port.onMessage.addListener(async () => {
    valuesToFlush = {};
    const cur = await cachedStorageApi.get();
    const toRemove = Object.keys(cur).filter(k => !(k in old));
    undoing = true;
    if (toRemove.length) await cachedStorageApi.remove(toRemove);
    await cachedStorageApi.set(old);
    port.postMessage(true);
    clearStorageCache();
    await initializeDatabase(true);
    undoing = false;
  });
  old = await api.get();
  if (!drop) port.postMessage(true);
}
