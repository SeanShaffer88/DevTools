import { buffer2string, isEmpty, noop } from '@/common';
import { forEachEntry } from '@/common/object';
import { CHROME } from './ua';

let encoder;

/** @type {Object<string,GMReq.BG>} */
export const requests = { __proto__: null };
export const verify = { __proto__: null };
export const FORBIDDEN_HEADER_RE = regex('i')`
^(
  # prefix matches
  proxy-|
  sec-
)|^(
  # whole name matches
  # https://developer.mozilla.org/en-US/docs/Glossary/Forbidden_header_name
  # https://cs.chromium.org/?q=file:cc+symbol:IsForbiddenHeader%5Cb
  accept-(charset|encoding)|
  access-control-request-(headers|method)|
  connection|
  content-length|
  cookie2?|
  date|
  dnt|
  expect|
  host|
  keep-alive|
  origin|
  referer|
  te|
  trailer|
  transfer-encoding|
  upgrade|
  via
)$`;
/** @type {chrome.webRequest.RequestFilter} */
const API_FILTER = {
  urls: ['<all_urls>'],
  types: ['xmlhttprequest'],
};
const EXTRA_HEADERS = [
  !__.MV3 && 'blocking',
  browser.webRequest.OnBeforeSendHeadersOptions.EXTRA_HEADERS,
].filter(Boolean);
const headersToInject = {};
export const kCookie = 'cookie';
export const kSetCookie = 'set-cookie';
const SET_COOKIE_VALUE_RE = regex({ disable: { n: true } })`
  ^\s*  (?:__(Secure|Host)-)?  ([^=\s]+)  \s*=\s*  (")?  ([!#-+\--:\<-\[\]-~]*)  \3(.*)`;
const SET_COOKIE_ATTR_RE = regex({ disable: { n: true }, flags: 'y' })`
  \s*  ;?\s*  (\w+)  (?:= (")?  ([!#-+\--:\<-\[\]-~]*)  \2)?`;
const SAME_SITE_MAP = {
  strict: 'strict',
  lax: 'lax',
  none: 'no_restriction',
};
export const kRequestHeaders = 'requestHeaders';
const API_EVENTS = {
  onBeforeSendHeaders: [onBeforeSendHeaders, kRequestHeaders, ...EXTRA_HEADERS],
  onHeadersReceived: [onHeadersReceived, kResponseHeaders, ...EXTRA_HEADERS],
};
/** Chrome leaks empty dynamic registrations, https://crbug.com/526929792 */
const CHROME_REG_LEAK_BUG = __.MV3 && CHROME >= 146;

/** @param {chrome.webRequest.WebRequestDetails} details */
function onHeadersReceived({ [kResponseHeaders]: headers, requestId, tabId, url }) {
  if (CHROME_REG_LEAK_BUG && tabId !== -1) return;
  const req = requests[verify[requestId]];
  if (req) {
    // Populate responseHeaders for GM_xhr's `response`
    req[kResponseHeaders] = headers.map(encodeWebRequestHeader).join('');
    if (__.MV3) return;
    const { storeId } = req;
    // Drop Set-Cookie headers if anonymous or using a custom storeId
    if (!req[kSetCookie] || storeId) {
      headers = headers.filter(h => {
        if (h.name.toLowerCase() !== kSetCookie) return true;
        if (storeId) setCookieInStore(h.value, storeId, url);
      });
      return { [kResponseHeaders]: headers };
    }
  }
}

/** @param {chrome.webRequest.WebRequestDetails} details */
function onBeforeSendHeaders({ [kRequestHeaders]: headers, requestId, tabId, url }) {
  if (CHROME_REG_LEAK_BUG && tabId !== -1) return;
  let req;
  let reqId = verify[requestId];
  if (reqId) {
    req = requests[reqId];
  } else {
    reqId = url.split('#')[1];
    req = requests[reqId];
    if (req) {
      verify[requestId] = reqId;
      req.coreId = requestId;
    }
  }
  if (req) {
    // remember redirected URL with #hash as it's stripped in XHR.responseURL
    // browsers re-append our #reqId to redirected URL if the server didn't redirect to a new #hash
    if (url !== req.xhrUrl) req.url = url.replace('#' + reqId, '');
    if (__.MV3) return;
    const headersMap = {};
    const headers2 = headersToInject[reqId];
    const combinedHeaders = headers2 && {};
    let h2 = !headers2;
    for (const h of headers) {
      let name = h.name.toLowerCase();
      if (name === 'origin' && h.value === extensionOrigin
      || name === kCookie && !req[kCookie]) {
        continue;
      }
      if (!h2 && name === kCookie && (h2 = headers2[name])) {
        combinedHeaders[name] = { name, value: h.value + '; ' + h2.value };
      } else {
        headersMap[name] = h;
      }
    }
    return {
      [kRequestHeaders]: Object.values(Object.assign(headersMap, headers2, combinedHeaders))
    };
  }
}

export function toggleHeaderInjector(reqId, headers) {
  if (headers) {
    if (isEmpty(headersToInject)) {
      API_EVENTS::forEachEntry(([name, [listener, ...options]]) => {
        browser.webRequest[name].addListener(listener, API_FILTER, options);
      });
    }
    // Adding even if empty so that the toggle-off `if` runs just once even when called many times
    headersToInject[reqId] = headers;
  } else if (reqId in headersToInject) {
    delete headersToInject[reqId];
    if (!CHROME_REG_LEAK_BUG && isEmpty(headersToInject)) {
      API_EVENTS::forEachEntry(([name, [listener]]) => {
        browser.webRequest[name].removeListener(listener);
      });
    }
  }
}

/**
 * Imitating https://developer.mozilla.org/docs/Web/API/XMLHttpRequest/getAllResponseHeaders
 * Per the specification https://tools.ietf.org/html/rfc7230 the header name is within ASCII,
 * but we'll try encoding it, if necessary, to handle invalid server responses.
 */
function encodeWebRequestHeader({ name, value, binaryValue }) {
  return `${string2byteString(name)}: ${
    binaryValue
      ? buffer2string(binaryValue)
      : string2byteString(value)
  }\r\n`;
}

/**
 * @param {string} headerValue
 * @param {string} storeId
 * @param {string} url
 */
function setCookieInStore(headerValue, storeId, url) {
  let m = SET_COOKIE_VALUE_RE.exec(headerValue);
  if (m) {
    const [, prefix, name, , value, optStr] = m;
    const opt = {};
    const isHost = prefix === 'Host';
    SET_COOKIE_ATTR_RE.lastIndex = 0;
    while ((m = SET_COOKIE_ATTR_RE.exec(optStr))) {
      opt[m[1].toLowerCase()] = m[3];
    }
    const sameSite = opt.sameSite?.toLowerCase();
    browser.cookies.set({
      url,
      name,
      value,
      domain: isHost ? undefined : opt.domain,
      expirationDate: Math.max(0, +new Date(opt['max-age'] * 1000 || opt.expires)) || undefined,
      httpOnly: 'httponly' in opt,
      path: isHost ? '/' : opt.path,
      sameSite: SAME_SITE_MAP[sameSite],
      secure: url.startsWith('https:') && (!!prefix || sameSite === 'none' || 'secure' in opt),
      storeId,
    });
  }
}

/**
 * Returns a UTF8-encoded binary string i.e. one byte per character.
 * Returns the original string in case it was already within ASCII.
 */
function string2byteString(str) {
  if (!/[\u0080-\uFFFF]/.test(str)) return str;
  if (!encoder) encoder = new TextEncoder();
  return buffer2string(encoder.encode(str));
}

// Chrome 74-91 needs an extraHeaders listener at tab load start, https://crbug.com/1074282
// We're attaching a no-op in non-blocking mode so it's very lightweight and fast.
if (!__.MV3 && CHROME >= 74 && CHROME <= 91) {
  browser.webRequest.onBeforeSendHeaders.addListener(noop, API_FILTER, EXTRA_HEADERS);
}
// Attaching globally will see all XHRs in all tabs because tabId:-1 in addListener is ignored
if (CHROME_REG_LEAK_BUG) toggleHeaderInjector('', []);
