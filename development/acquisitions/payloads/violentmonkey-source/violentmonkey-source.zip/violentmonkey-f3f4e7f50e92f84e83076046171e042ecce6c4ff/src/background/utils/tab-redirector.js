import { browserWindows, getTab, getUniqId, i18n, isRemote, noop, sendTabCmd } from '@/common';
import browser from '@/common/browser';
import { executeScript } from '@/common/browser-scripts-api';
import { FILE_GLOB_ALL, kMainFrame, NO_CACHE } from '@/common/consts';
import cache from './cache';
import { addPublicCommands, commands } from './init';
import { getOption } from './options';
import { MCP_CONNECT_URL, openMcpAuthorization, requestMcpConnection } from './mcp';
import { matchUserScript, parseMeta } from './script';
import { fileSchemeRequestable, getTabUrl, NEWTAB_URL_RE, tabsOnUpdated } from './tabs';
import { FIREFOX } from './ua';
import { request } from './url';

addPublicCommands({
  async CheckInstallerTab(tabId, src) {
    const tab = IS_FIREFOX && (src.url || '').startsWith('file:') && await getTab(tabId);
    return tab && getTabUrl(tab).startsWith(CONFIRM_URL_BASE);
  },
  ConfirmInstall: confirmInstall,
});

async function confirmInstall({ code, from, url, fs, parsed }, { tab = {} }) {
  if (!fs) {
    code ??= parsed
      ? request(url, NO_CACHE).then(r => r.data) // cache the Promise and start fetching now
      : (await request(url, NO_CACHE)).data;
    // TODO: display the error in UI
    if (!parsed && !matchUserScript(code)) {
      throw `${i18n('msgInvalidScript')}\n\n${
        code.trim().split(/[\r\n]+\s*/, 9/*max lines*/).join('\n')
          .slice(0, 500/*max overall length*/)
      }...`;
    }
    cache.put(url, code, 3000);
  }
  const confirmKey = getUniqId('', true);
  const { active, id: tabId, incognito } = tab;
  // Not testing tab.pendingUrl because it will be always equal to `url`
  const canReplaceCurTab = __.MV3 || (!incognito || IS_FIREFOX) && (
    url === from
    || cache.has(`autoclose:${tabId}`)
    || NEWTAB_URL_RE.test(from));
  /** @namespace VM.ConfirmCache */
  cache.put(`confirm-${confirmKey}`, { incognito, url, from, tabId, fs, ff: FIREFOX });
  const confirmUrl = CONFIRM_URL_BASE + confirmKey;
  const { [kWindowId]: windowId } = canReplaceCurTab
  // The tab may have been closed already, in which case we'll open a new tab
  && await browser.tabs.update(tabId, { url: confirmUrl }).catch(noop)
  || await commands.TabOpen({ url: confirmUrl, active: !!active }, { tab });
  if (active && windowId !== tab[kWindowId]) {
    await browserWindows?.update(windowId, { focused: true });
  }
}

const whitelistRe = regex('i')`^https://(
  (greas|sleaz)yfork\.(org|cc)/scripts/[^\/]*/code|
  update\.(greas|sleaz)yfork\.(org|cc)/scripts(/\d+)?| # old version part is optional
  openuserjs\.org/install/[^\/]*|
  github\.com/[^\/]*/[^\/]*/(
    raw/[^\/]*|
    releases/(
      download/[^\/]* |
      latest/download
    )
  )|
  raw\.githubusercontent\.com(/[^\/]*){3}|
  gist\.github\.com/.*?
)/[^\/]*?\.user\.js  ([?#]|$)`;
const blacklistRe = regex('i')`^https?://(
  (gist\.)?github\.com|
  ((greas|sleaz)yfork|openuserjs)\.(org|cc)
)/`;
export const resolveVirtualUrl = url => (
  `${extensionOptionsPage}${ROUTE_SCRIPTS}/${+url.split('#')[1]}`
);
// FF can't intercept virtual .user.js URL via webRequest, so we redirect it explicitly
const virtualUrlRe = IS_FIREFOX && new RegExp((
  `^(view-source:)?(${extensionRoot.replace('://', '$&)?')}[^/]*\\.user\\.js#\\d+`
));
async function maybeInstallUserJs(tabId, url, isWhitelisted) {
  if (__.MV3 && isWhitelisted) sendTabCmd(tabId, 'Stop');
  // Getting the tab now before it navigated
  const tab = tabId >= 0 && await getTab(tabId) || {};
  const { data: code } = !isWhitelisted && await request(url, NO_CACHE).catch(noop) || {};
  if (isWhitelisted || code && parseMeta(code).name) {
    confirmInstall({ code, url, from: tab.url, parsed: true }, { tab });
  } else {
    cache.put(`bypass:${url}`, true, 10e3);
    const error = `${VIOLENTMONKEY} installer skipped ${url}.
Either not a userscript or the metablock comment is malformed:
${code?.length > 1e6 ? code.slice(0, 1e6) + '...' : code}`;
    if (tabId < 0) {
      console.warn(error);
    } else {
      executeScript(tabId, `console.warn(${JSON.stringify(error)})`, 'document_start').catch(noop);
      browser.tabs.update(tabId, { url });
    }
  }
}

tabsOnUpdated.addListener(async (tabId, { url }, tab) => {
  if (!url) return;
  const { id, title } = tab;
  const isFile = url.startsWith('file:');
  const isUserJS = /\.user\.js([?#]|$)/.test(url);
  /* Determining if this tab can be auto-closed (replaced, actually).
     FF>=68 allows reading file: URL only in the tab's content script so the tab must stay open. */
  if (isUserJS && !isFile) {
    cache.put(`autoclose:${id}`, true, 10e3);
  }
  if (url === 'about:blank' && virtualUrlRe && virtualUrlRe.test(title)) {
    browser.tabs.update(id, { url: resolveVirtualUrl(title) });
  } else if (isUserJS && isFile && getOption('helpForLocalFile') && (
    IS_FIREFOX
      // FF153 requires user explicitly enabling file: access (without reloading the extension)
      ? IDBIndex.prototype.getAllRecords &&
        !await browser.extension.isAllowedFileSchemeAccess()
      : !fileSchemeRequestable
  )) {
    confirmInstall({ url, fs: true }, { tab });
  }
}, !__.MV3 && FIREFOX && { properties: [FIREFOX >= 88 ? 'url' : 'status'] });

browser.webRequest.onBeforeRequest.addListener((req) => {
  const { method, tabId, url } = req;
  if (method !== 'GET') {
    return;
  }
  // open a real URL for simplified userscript URL listed in devtools of the web page
  if (!__.MV3 && url.startsWith(extensionRoot)) {
    return { redirectUrl: resolveVirtualUrl(url) };
  }
  let isWhitelisted;
  if (!cache.has(`bypass:${url}`) && (
    (isWhitelisted = whitelistRe.test(url))
    || !blacklistRe.test(url)
    || !isRemote(url)
  )) {
    maybeInstallUserJs(tabId, url, isWhitelisted);
    return IS_FIREFOX
      ? { cancel: true } // for sites with strict CSP in FF
      : { redirectUrl: 'javascript:void 0' }; // eslint-disable-line no-script-url
  }
}, {
  urls: [
    // 1. *:// comprises only http/https
    // 2. the API ignores #hash part
    // 3. Firefox: onBeforeRequest does not work with file:// or moz-extension://
    '*://*/*.user.js',
    '*://*/*.user.js?*',
    `${FILE_GLOB_ALL}.user.js`,
    `${FILE_GLOB_ALL}.user.js?*`,
    !__.MV3 && `${extensionRoot}*.user.js`,
  ].filter(Boolean),
  types: [kMainFrame],
}, __.MV3 ? [] : ['blocking']);

browser.webRequest.onBeforeRequest.addListener(({ tabId, url }) => {
  if (tabId >= 0 && requestMcpConnection(url)) {
    openMcpAuthorization(tabId);
    return IS_FIREFOX ? { cancel: true } : { redirectUrl: 'javascript:void 0' }; // eslint-disable-line no-script-url
  }
}, {
  // `/mcp_connect/` and the legacy `/mcp_connect.html`, with any query string
  urls: [`${MCP_CONNECT_URL}*`],
  types: [kMainFrame],
}, __.MV3 ? [] : ['blocking']);
