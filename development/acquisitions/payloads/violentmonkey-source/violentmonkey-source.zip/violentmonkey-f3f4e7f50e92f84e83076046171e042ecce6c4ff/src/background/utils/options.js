import { compareVersion, debounce, initHooks, normalizeKeys } from '@/common';
import { deepCopy, deepEqual, objectGet, objectSet } from '@/common/object';
import defaults, { kScriptTemplate, kUpdateCron } from '@/common/options-defaults';
import { migrateAutoUpdate, normalizeUpdateCron } from '@/common/cron';
import broadcast from './broadcast';
import { addOwnCommands, init, initDependency } from './init';
import storage from './storage';

let changes;

export const getAllOptions = () => [
  __.VM_VER,
  { ...defaults, ...options },
];
const options = {};
export const kOptions = 'options';
export const kVersion = 'version';
const TPL_OLD_VAL = `\
// ==UserScript==
// @name New Script
// @namespace Violentmonkey Scripts
// @match {{url}}
// @grant none
// ==/UserScript==
`;
const DELAY = 100;
const hooks = initHooks();
const callHooksLater = debounce(callHooks, DELAY);
const writeOptionsLater = debounce(writeOptions, DELAY);
const optProxy = new Proxy(defaults, { get: (_, key) => getOption(key) });
export const hookOptions = hooks.hook;
hookOptions(data => broadcast('UpdateOptions', data));

addOwnCommands({
  GetAllOptions: getAllOptions,
  /**
   * @param {{ [key:string]: PlainJSONValue }} data
   * @return {void}
   * @throws {?} hooks can throw after the option was set */
  SetOptions(data) {
    if (data[kUpdateCron] == null && data.autoUpdate != null) {
      data = { ...data, [kUpdateCron]: migrateAutoUpdate(data.autoUpdate) };
    }
    for (const key in data) setOption(key, data[key], true);
    callHooks(); // exceptions will be sent to the caller
  },
});

export function initOptions(data, lastVersion, versionChanged) {
  for (const key in options) delete options[key];
  data = data[kOptions] || {};
  Object.assign(options, data);
  if (options[kUpdateCron] == null && options.autoUpdate != null) {
    options[kUpdateCron] = migrateAutoUpdate(options.autoUpdate);
    writeOptionsLater();
  }
  if (__.DEBUG) console.info('options:', options);
  if (!options[kVersion]) {
    setOption(kVersion, 1);
  }
  if (options[kScriptTemplate] === TPL_OLD_VAL) {
    options[kScriptTemplate] = defaults[kScriptTemplate]; // will be detected by omitDefaultValue below
  }
  if (Object.keys(options).map(omitDefaultValue).some(Boolean)) {
    delete options[`${kScriptTemplate}Edited`]; // TODO: remove this in 2023
    writeOptionsLater();
  }
  if (versionChanged) {
    let key, val;
    if (IS_FIREFOX && options[key = 'defaultInjectInto'] === PAGE
    && compareVersion(lastVersion, '2.12.7') <= 0) {
      options[key] = AUTO;
    }
    if (__.MV3 && options[key = 'ffInject']
    && compareVersion(lastVersion, '2.45.4') <= 0) {
      options[key] = false; // In older VM it was enabled by default but used only in Firefox
    }
    if ((val = options.filters) && val[key = 'sort'] === 'exec'
    && compareVersion(lastVersion, '2.31.2') <= 0) {
      val[key] += '-'; // Until reverse sort was implemented, 'size' was reversed by design
    }
  }
}

/**
 * @param {!string} key - must be "a.b.c" to allow clients easily set inside existing object trees
 * @param {PlainJSONValue} [value]
 * @param {boolean} [silent] - in case you callHooks() directly yourself afterwards
 */
function addChange(key, value, silent) {
  if (!changes) changes = {};
  else delete changes[key]; // Deleting first to place the new value at the end
  changes[key] = value;
  if (!silent) callHooksLater();
}

/** @throws in option handlers */
function callHooks() {
  if (!changes) return; // may happen in callHooksLater if callHooks was called earlier
  const tmp = changes;
  changes = null;
  hooks.fire(tmp);
}

/** Hooks and calls the callback with a copy of all options when init is resolved */
export function hookOptionsInit(cb) {
  if (init) initDependency(() => cb(optProxy, true));
  else cb(optProxy, true);
  return hookOptions(cb);
}

export function getOption(key) {
  let res = options[key];
  if (res != null) return res;
  const keys = normalizeKeys(key);
  const mainKey = keys[0];
  const value = options[mainKey] ?? defaults[mainKey];
  return deepCopy(keys.length > 1 ? objectGet(value, keys.slice(1)) : value);
}

export function setOption(key, value, silent) {
  if (init) return init.then(setOption.bind(null, ...arguments));
  const keys = normalizeKeys(key);
  const mainKey = keys[0];
  key = keys.join('.'); // must be a string for addChange()
  if (key === kUpdateCron) value = normalizeUpdateCron(value);
  if (!hasOwnProperty(defaults, mainKey)) {
    if (__.DEBUG) console.info('Unknown option:', key, value, options);
    return;
  }
  const subKey = keys.length > 1 && keys.slice(1);
  const mainVal = getOption([mainKey]);
  if (deepEqual(value, subKey ? objectGet(mainVal, subKey) : mainVal)) {
    if (__.DEBUG) console.info('Option unchanged:', key, value, options);
    return;
  }
  options[mainKey] = subKey ? objectSet(mainVal, subKey, value) : value;
  omitDefaultValue(mainKey);
  writeOptionsLater();
  addChange(key, value, silent);
  if (__.DEBUG) console.info('Options updated:', key, value, options);
}

function writeOptions() {
  return storage.base.setOne(kOptions, options);
}

function omitDefaultValue(key) {
  return deepEqual(options[key], defaults[key])
    && delete options[key];
}
