import { initHooks } from '@/common';
import { mapEntry } from '@/common/object';
import { ensureArray } from '@/common/util';
import { addOwnCommands } from './init';

let api = browser.storage.local;

/** @prop {VMStorageFetch} [fetch] */
class VMStorageArea {
  constructor(name, prefix) {
    storageByPrefix[prefix] = this; // eslint-disable-line no-use-before-define
    this.name = name;
    this.prefix = prefix;
  }

  /** @return {string} */
  toKey(id) {
    return this.prefix + id;
  }

  /** @return {string} */
  toId(key) {
    return key.startsWith(this.prefix)
      ? key.slice(this.prefix.length)
      : '';
  }

  /**
   * @param {string|number} id
   * @return {Promise<?>}
   */
  async getOne(id) {
    const key = this.toKey(id);
    return (await api.get([key]))[key];
  }

  /**
   * @param {?string[]} [ids] - if null/absent, the entire storage is returned
   * @param {function(val:?,key:string):?} [transform]
   * @return {Promise<?>} - single value or object of id:value
   */
  async getMulti(ids, transform) {
    const keys = ids?.map(this.toKey, this);
    const data = await api.get(keys);
    return transform || this.prefix
      ? data::mapEntry(transform, this.toId, this)
      : data;
  }

  /**
   * @param {string|number|Array<string|number>} id
   * @return {Promise<void>}
   */
  async remove(id) {
    const keys = ensureArray(id).filter(Boolean).map(this.toKey, this);
    if (keys.length) await api.remove(keys);
  }

  async setOne(id, value) {
    if (id) return this.set({ [id]: value });
  }

  /**
   * @param {Object} data
   * @return {Promise<Object>} same object
   */
  async set(data) {
    if (__.DEV && !isObject(data)) {
      throw 'VMStorageArea.set: data is not an object';
    }
    await api.set(this.prefix
      ? data::mapEntry(null, this.toKey, this)
      : data);
    return data;
  }
}

// TODO: add Firefox version to the comment when https://bugzil.la/1910669 is fixed
/** @type {() => Promise<string[]>} Chromium 130+ */
export const getStorageKeys = api.getKeys?.bind(api);
export const S_CACHE = 'cache';
export const S_CACHE_PRE = 'cac:';
export const S_CODE = 'code';
export const S_CODE_PRE = 'code:';
export const S_MOD = 'mod';
export const S_MOD_PRE = 'mod:';
export const S_REQUIRE = 'require';
export const S_REQUIRE_PRE = 'req:';
export const S_SCRIPT = 'script';
export const S_SCRIPT_PRE = 'scr:';
export const S_VALUE = 'value';
export const S_VALUE_PRE = 'val:';
/** @type {{ [prefix: string]: VMStorageArea }} */
export const storageByPrefix = {};
/**
 * @prop {VMStorageArea} cache
 * @prop {VMStorageArea} code
 * @prop {VMStorageArea} mod
 * @prop {VMStorageArea} require
 * @prop {VMStorageArea} script
 * @prop {VMStorageArea} value
 */
const storage = {
  get api() { return api; },
  set api(val) { api = val; },
  /** @return {?VMStorageArea} */// eslint-disable-next-line no-use-before-define
  forKey: key => storageByPrefix[/^\w+:|$/.exec(key)[0]],
  base: new VMStorageArea('base', ''),
  [S_CACHE]: new VMStorageArea(S_CACHE, S_CACHE_PRE),
  [S_CODE]: new VMStorageArea(S_CODE, S_CODE_PRE),
  /** last-modified HTTP header value per URL */
  [S_MOD]: new VMStorageArea(S_MOD, S_MOD_PRE),
  [S_REQUIRE]: new VMStorageArea(S_REQUIRE, S_REQUIRE_PRE),
  [S_SCRIPT]: new VMStorageArea(S_SCRIPT, S_SCRIPT_PRE),
  [S_VALUE]: new VMStorageArea(S_VALUE, S_VALUE_PRE),
};
const { hook, fire } = initHooks();
/**
 * Not using browser.storage.onChanged to improve performance, as it sends data across processes.
 * WARNING: when editing the db directly in devtools, restart the background page via Ctrl-R.
*/
export { hook as onStorageChanged, fire as fireStorageChanged };
export default storage;

addOwnCommands({
  Storage([area, method, ...args]) {
    return storage[area][method](...args);
  },
});
