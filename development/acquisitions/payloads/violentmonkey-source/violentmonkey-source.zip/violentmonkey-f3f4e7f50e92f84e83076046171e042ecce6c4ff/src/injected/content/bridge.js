import browser from '@/common/browser'; // eslint-disable-line no-restricted-imports
import { sendCmd } from './util';

const handlers = createNullObj();
const bgHandlers = createNullObj();
export const ids = createNullObj();
export const grantless = createNullObj();
/**
 * Without `force` handlers will be added only when userscripts are about to be injected.
 * { CommandName: true } will relay the request via sendCmd as is.
 * { CommandName: REIFY } same as `true` but waits until reified when pre-rendered.
 * @callback AddHandlers
 * @param {Object.<string, MessageFromGuestHandler>} obj
 * @param {boolean} [force]
 */
/** @type {AddHandlers} */
export const addHandlers = assign.bind(null, handlers);
/** @type {AddHandlers} */
export const addBackgroundHandlers = (src, force) => {
  if (force || !onScripts) {
    assign(bgHandlers, src);
  } else {
    onScripts.push(() => assign(bgHandlers, src));
  }
};
// realm is provided when called directly via invokeHost
export const onHandle = async ({ cmd, data, node }, realm) => {
  let res, err;
  let handle = handlers[cmd];
  let callbackId = data && getOwnProp(data, CALLBACK_ID);
  if (callbackId) {
    data = data.data;
  }
  const nodeRet = [null]; // elem must be present to skip a poisoned prototype on arr[0]=val
  try {
    if (!handle) throw data;
    if (handle === REIFY) {
      handle = true;
      if (reify) await reify;
    }
    res = handle === true
      ? sendCmd(cmd, data)
      : node::handle(data, realm || PAGE, nodeRet);
    if (isPromise(res)) {
      res = await res;
    }
  } catch (e) {
    res = null; // prevent the rejected Promise from being sent to Callback
    err = e;
  }
  if (callbackId || err) {
    post('Callback', { res, err, id: callbackId || '' }, realm, nodeRet[0]);
  }
};
export const init = data => {
  assign(ids, data[IDS]);
  injectInto = data[INJECT_INTO];
  useMenu = data[kUseMenu];
};
export const end = () => {
  onScripts = null;
};
export const setCache = val => (cache = val);
export const setPathMaps = val => (pathMaps = val);
export const setPost = fn => (post = fn);
export const setReify = val => (reify = val);
export const setUseMenu = val => (useMenu = val);

export let cache;
export let injectInto;
export let pathMaps;
export let reify;
export let useMenu;
/** @type {VMBridgePostFunc} */
export let post;
/** @type {function(VMInjection)[]} */
export let onScripts = [];

browser.runtime.onMessage.addListener(({ cmd, data }, src) => {
  if ((cmd = bgHandlers[cmd])) {
    data = cmd(data, src);
    if (data && isPromise(data)) data::then(null, logging.error);
    return data;
  }
});

/**
 * @callback MessageFromGuestHandler
 * @param {Object} [data]
 * @param {CONTENT | PAGE} realm -
 *   CONTENT when the message is from the content script context,
 *   PAGE otherwise. Make sure to specify the same realm when messaging
 *   the results back otherwise it won't reach the target script.
 */
