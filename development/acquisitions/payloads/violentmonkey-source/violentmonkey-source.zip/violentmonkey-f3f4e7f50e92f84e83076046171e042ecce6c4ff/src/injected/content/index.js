import * as bridge from './bridge';
import { onClipboardCopy } from './clipboard';
import { injectPageSandbox, injectScripts } from './inject';
import { setLogCapture } from './logs';
import './notifications';
import './requests';
import './tabs';
import { sendCmd } from './util';
import { isEmpty, XHR_COOKIE_RE } from '../util';
import { Run, finish } from './cmd-run';

// Make sure to call obj::method() in code that may run after CONTENT userscripts
async function init() {
  const isXml = document instanceof XMLDocument;
  const canReg = __.MV3 || IS_FIREFOX && Event[PROTO].composedPath;
  /** Could be a DOM element with an `id` attribute equal to ours */
  const regRaw = canReg && global[VIOLENTMONKEY];
  const regData = regRaw?.[kSessionId] && delete global[VIOLENTMONKEY] && regRaw;
  const xhrData = getXhrInjection(regData);
  const dataPromise = sendCmd('GetInjected', {
    /* In FF93 sender.url is wrong: https://bugzil.la/1734984,
     * in Chrome sender.url is ok, but location.href is wrong for text selection URLs #:~:text= */
    url: IS_FIREFOX && location.href,
    // XML document's appearance breaks when script elements are added
    [FORCE_CONTENT]: isXml,
    done: !!(regData || xhrData),
  }, {
    retry: true,
  });
  // detecting if browser.contentScripts is usable, it was added in FF59 as well as composedPath
  /** @type {VMInjection} */
  const data = regData || xhrData || await (canReg ? getRegistration(dataPromise) : dataPromise);
  const info = data.info;
  const injectInto = data[INJECT_INTO];
  // Decided by the host when it replies, so it travels with the injection below
  setLogCapture(data[kLogCapture]);
  bridge.init(data);
  if (IS_FIREFOX && !data.clipFF) {
    off('copy', onClipboardCopy, true);
  }
  if (IS_FIREFOX && info) { // must redefine now as it's used by injectPageSandbox
    // In MV2 build `IS_FIREFOX` is compiled to `IS_FIREFOX_MV2`
    IS_FIREFOX_MV2 = parseFloat(info.ua.browserVersion); // eslint-disable-line no-global-assign
  }
  if (data[EXPOSE] != null && !isXml && injectPageSandbox(data)) {
    bridge.addHandlers({ GetScriptVer: true });
    bridge.post('Expose', data[EXPOSE]);
  }
  if (objectKeys(bridge.ids).length) {
    bridge.onScripts.forEach(fn => fn(data));
    await injectScripts(data, info, isXml);
  }
  bridge.end();
  finish(injectInto);
}

bridge.addBackgroundHandlers({
  [VIOLENTMONKEY]: () => true,
  Stop: stop,
}, true);

bridge.addBackgroundHandlers({
  Command: data => bridge.post('Command', data, bridge.ids[data.id]),
  Run: id => Run(id, CONTENT),
  UpdatedValues(data) {
    const dataPage = createNullObj();
    const dataContent = createNullObj();
    objectKeys(data)::forEach((id) => {
      (bridge.ids[id] === CONTENT ? dataContent : dataPage)[id] = data[id];
    });
    if (!isEmpty(dataPage)) bridge.post('UpdatedValues', dataPage);
    if (!isEmpty(dataContent)) bridge.post('UpdatedValues', dataContent, CONTENT);
  },
});

bridge.addHandlers({
  CookieDelete: REIFY,
  CookieList: REIFY,
  CookieSet: REIFY,
  Log: data => safeApply(logging[data[0]], logging, data[1]),
  TabFocus: REIFY,
  UpdateValue: REIFY,
});

init().catch(IS_FIREFOX && logging.error);
// Firefox can't show exceptions in content scripts

async function getRegistration(viaMessaging) {
  if (__.DEBUG) viaMessaging.then(console.info.bind(null, 'GetInjected'));
  const data = await SafePromise.race([
    // global !== window in FF content scripts
    new SafePromise(resolve => { global[VIOLENTMONKEY] = resolve; }),
    viaMessaging,
  ]);
  delete global[VIOLENTMONKEY];
  return data;
}

function getXhrInjection(regData) {
  try {
    const key = VM_UUID.match(XHR_COOKIE_RE)[1];
    // Accessing document.cookie may throw due to CSP sandbox
    const cookieValue = document.cookie.split(`${key}=`)[1];
    const blobId = cookieValue && cookieValue.split(';', 1)[0];
    if (blobId) {
      document.cookie = `${key}=0; max-age=0; SameSite=Lax`; // this removes our cookie
      if (regData) return;
      const xhr = new XMLHttpRequest();
      const url = `blob:${VM_UUID}${blobId}`;
      xhr.open('get', url, false); // `false` = synchronous
      xhr.send();
      URL.revokeObjectURL(url);
      return JSON.parse(xhr[kResponse]);
    }
  } catch { /* NOP */ }
}
