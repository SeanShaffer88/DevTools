import * as bridge from './bridge';

let lastId = 0;
const tabs = createNullObj();

bridge.addHandlers({
  TabClosed(key) {
    const item = tabs[key];
    if (item) {
      delete tabs[key];
      item.closed = true;
      item.onclose?.();
    }
  },
});

export function onTabCreate(data) {
  lastId += 1;
  const key = lastId;
  const item = {
    __proto__: null,
    onclose: null,
    closed: false,
    close() {
      bridge.post('TabClose', key);
    },
  };
  tabs[key] = item;
  bridge.post('TabOpen', { key, data });
  return item;
}
