/*
 * NoScript - a Firefox extension for whitelist driven safe JavaScript execution
 *
 * Copyright (C) 2005-2026 Giorgio Maone <https://maone.net>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */

"use strict";

const fs = require('fs');
const path = require('path');
const args = process.argv.slice(2);
const MANIFEST_VER = /^m?v?[2-3]/i.test(args[0]) ? args.shift() : "mv3edge";
const MANIFEST_SRC = args[0] || "src/manifest.json";
const MANIFEST_DEST = args[1] || args[0] || "build/manifest.json";


console.log(`${MANIFEST_SRC} --[${MANIFEST_VER}]--> ${MANIFEST_DEST}`);

const srcContent = fs.readFileSync(MANIFEST_SRC, 'utf8');
const json = JSON.parse(srcContent);
const permissions = new Set(json.permissions);

let extVer = json.version;
const FIREFOX_UPDATE_URL = "https://secure.informaction.com/update/?v=" + extVer;
const EDGE_UPDATE_URL = "https://edge.microsoft.com/extensionwebstorebase/v1/crx";

const isFirefox = MANIFEST_VER.includes("firefox");
const isTor = MANIFEST_VER.includes(":tor");
const isDebug = MANIFEST_VER.includes(":dbg");

const pre = /[a-zA-Z-]|\.9\d{2}$/.test(extVer);
if (!(isFirefox && pre && !isTor)) {
  permissions.delete("contextualIdentities");
}
if (isFirefox) {
  if (isTor) {
    // add version suffix to separate Tor Browser builds
    const suffix = "1984";
    const parts = extVer.split(".");
    while (parts.length < 3) parts.push("0");
    parts[3] = parts[3] ? `${parts[3]}0${suffix}` : suffix;
    json.version = extVer = parts.join(".");
  }
  const url = isTor
    ? `https://dist.torproject.org/torbrowser/noscript/update-${pre ? "pre" : "stable"}.json`
    : pre ? FIREFOX_UPDATE_URL : "";
  if (url && !isDebug) {
    json.browser_specific_settings.gecko.update_url = url;
  }
  json.icons = {};
  for (const size of [16, 32, 48, 64, 128, 256]) {
    json.icons[size] = "img/logo.svg";
  }
  for (const s of [json.background.scripts, json.content_scripts[0].js]) {
    s.splice(s.indexOf("/nscl/lib/browser-polyfill.js"), 1);
  }
}

if (MANIFEST_VER.includes(3)) {
  // MV3
  json.manifest_version = 3;

  const excludedScriptsRx = /\bcontent\/(?:embeddingDocument|dirindex)\.js$/;
  const scriptsFilter = src => !excludedScriptsRx.test(src);
  json.background.scripts = json.background.scripts.filter(scriptsFilter);
  for (const cs of json.content_scripts) {
    cs.js = cs.js.filter(scriptsFilter);
  }

  if (isFirefox) {
    delete json.content_security_policy;
  } else {
    // convert ${ver}(a|b|rc)xx into ${ver--}.9xx
    json.version = extVer.split("+")[0].replace(/(\d+)(?:\.0)*[a-z]+(\d+)$/,
        (all, maj, min) => `${parseInt(maj) - 1}.${900 + parseInt(min)}`);
    delete json.browser_specific_settings;
    delete json.content_security_policy;
    const {scripts} = json.background;
    delete json.background.scripts;
    const requiredPath = path.join(path.dirname(MANIFEST_DEST), "REQUIRED.js");
    scripts && fs.writeFileSync(requiredPath,
      `include.REQUIRED = ${JSON.stringify(scripts, null, 2)};`);
    for (const p of [
      "webRequestBlocking",
      "webRequestBlocking",
      "webRequestFilterResponse",
      "webRequestFilterResponse.serviceWorkerScript",
    ]) {
      permissions.delete(p);
    }
  }

  permissions.delete("<all_urls>");

  if (MANIFEST_VER.includes("edge")) {
    json.update_url = EDGE_UPDATE_URL;
  } else if (json.update_url === EDGE_UPDATE_URL) {
    delete json.update_url;
  }

  delete json.background.persistent;
  delete json.browser_action;
  delete json.commands._execute_browser_action;
} else {
  // MV2
  json.manifest_version = 2;
  delete json.background.service_worker;
  delete json.web_accessible_resources;
  delete json.host_permissions;
  delete json.action;
}

if (isFirefox || json.manifest_version == 2) {
  // Append MAIN world "*.main.js" scripts to their isolated counterparts
  // (on Gecko we will patch windows through xray)
  const isolatedWorldJS = json.content_scripts.find(
    cs => cs.world != "MAIN" && cs.js?.some(src => src.endsWith("/Worlds.js"))).js;

  json.content_scripts.find(cs => cs.world == "MAIN" && cs.js?.some(src => src.endsWith("/Worlds.main.js")))
    ?.js.filter(src => src.endsWith(".main.js"))
    .forEach(src => {
      const isolatedSrc = src.replace(/.*(\/[\w+.]+)\.main(?=\.js$)/, "$1");
      const idx = isolatedWorldJS.findIndex(src => src.endsWith(isolatedSrc));
      if (idx > -1) {
        isolatedWorldJS.splice(idx + 1, 0, src)
      } else {
        isolatedWorldJS.push(src);
      }
    });

  // remove all the MAIN world content script
  json.content_scripts = json.content_scripts.filter(cs => cs.world != "MAIN");

  for (const p of [
    "debugger",
    "declarativeNetRequest",
    "declarativeNetRequestFeedback",
  ]) {
    permissions.delete(p);
  }

}

// remove developer-only stuff
permissions.delete("declarativeNetRequestFeedback");

json.permissions = [...permissions];

const destContent = JSON.stringify(json, null, 2);
fs.writeFileSync(MANIFEST_DEST, destContent);
console.log(`Written ${MANIFEST_DEST}`);
