/*
 * NoScript - a Firefox extension for whitelist driven safe JavaScript execution
 *
 * Copyright (C) 2005-2024 Giorgio Maone <https://maone.net>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */

// depends on /nscl/service/NavCache.js

// This module is meant to replace the granular content blocking performed by RequestGuard.js
// on Manifest V2/2.5 (based on Firefox's blocking async webRequest API)
// with a declarativeNetRequest implementation on Manifest V3.
// One IMPORTANT difference is that this implementation won't try to inject Content-Security-Policy
// headers in documents for content blocking (the only one being injected is for reporting only):
// in MV3 all the CSP heavy lifting is done by staticNS.js via nscl's DocumentCSP, so it's vital
// that content-side the correct policy is always fetched timely (synchronously, if needed).

'use strict';
{
  const DEFAULT_PRIORITY = 1;
  const CASCADE_PERMISSIONS_PRIORITY = 5;
  const SITE_PRIORITY = 10;
  const CASCADE_RESTRICTIONS_PRIORITY = 20;
  const CTX_PRIORITY = 30;
  const TAB_PRIORITY = 40;
  const REPORT_PRIORITY = 50;
  const MAX_PRIORITY = 100;

  const SESSION_BASE = 100;
  const TAB_BASE = 10000;
  const DYNAMIC_BASE = 20000;

  let _lastPolicy;

  const dnrTypes = Object.values(browser.declarativeNetRequest.ResourceType);
  const resourceTypesMap = {};
  for(const [key, value] of Object.entries(RequestGuard.policyTypesMap)) {
    if (!(value && dnrTypes.includes(key))) continue;
    const mapping = resourceTypesMap[value] ||= [];
    mapping.push(key);
  }

  const ResourceTypesFor = {
    block(caps) {
      return ResourceTypesFor.allow(Permissions.ALL.filter(cap => !caps.has(cap)));
    },
    allow(caps) {
      const resourceTypes = [];
      for (let c of [...caps]) {
        if (c in resourceTypesMap) {
          resourceTypes.push(...resourceTypesMap[c]);
        }
      }
      return resourceTypes;
    }
  }

  function forBlockAllow(capabilities, callback) {
   for (const actionType of ["block", "allow"]) {
      const resourceTypes = ResourceTypesFor[actionType](capabilities);
      if (resourceTypes?.length) {
        callback(actionType, resourceTypes);
      }
   }
  }

  function toUrlFilter(siteKey) {
    // Note: using '^' instead of '/' as a terminator
    // takes explicit port numbers in account
    if (Sites.isSecureDomainKey(siteKey)) {
      return `||${Sites.toggleSecureDomainKey(siteKey, false)}^`
    }
    const schemeLess = siteKey.replace(/^[\w-]+:\/*/, "");
    let urlFilter = `${siteKey == schemeLess ? "||" : "|"}${siteKey}`;
    if (schemeLess && !schemeLess.includes('/')) {
      urlFilter += '^';
    }
    return urlFilter;
  }

  const reportedCaps = ['script', 'object', 'media', 'frame', 'font'];
  const reportingCSP = `${reportedCaps
      .map(cap => `${cap}-src 'none'`)
      .join(';')
    }; script-src-elem 'none'; report-to noscript-reports-dnr`; // see /content/content.js securitypolicyviolation handler

  browser.runtime.onStartup.addListener(async () => {
    const updatedTabs = autoAllow(await browser.tabs.query({}), true);
    debug("DNRPolicy startup updated tabs", updatedTabs);
    if (updatedTabs.length) {
      await Promise.allSettled([
        ns.saveSession(),
        RequestGuard.DNRPolicy.update(),
      ]);
    } else  {
      await RequestGuard.DNRPolicy.update();
    }

    const tabIds = new Set();
    for (const r of (await getTabRules())) {
      for (const tabId of r.condition.tabIds) {
        if (tabId >= 0) tabIds.add(tabId);
      }
    }
    const tabs = await Promise.all([...tabIds].map(tabId => browser.tabs.get(tabId)));
    debug("DNRPolicy startup, reload tab candidates", tabs, tabIds);
    for (const tab of tabs) {
      if (tab.status != "unloaded") {
        browser.tabs.reload(tab.id)
      }
    }
  });

  async function update() {
    const {policy} = ns;
    if (!policy || policy == _lastPolicy || _lastPolicy?.equals(policy)) {
      return await updateTabs();
    }
    _lastPolicy = policy;

    const Rules = {
      // Using capitalized keys to allow DRY tricks with get/update methods
      Session: [],
      Dynamic: [{
        id: 1,
        priority: REPORT_PRIORITY,
        action: {
          type: "modifyHeaders",
          responseHeaders: [{
            header: "content-security-policy-report-only",
            operation: "set",
            value: reportingCSP,
          }],
        },
        condition: {
          resourceTypes: ["main_frame", "sub_frame"],
        },
      }, {
        id: 2,
        priority: MAX_PRIORITY,
        action: {
          type: "allow"
        },
        condition: {
          resourceTypes: ["xmlhttprequest"],
          urlFilter: browser.runtime.onSyncMessage.DNR_URL_FILTER,
        },
      }],
      lastId: 2,
      add({capabilities, temp}, priority = SITE_PRIORITY, siteKey) {
        const urlFilter = siteKey ? toUrlFilter(siteKey) : undefined;
        forBlockAllow(capabilities, (type, resourceTypes) => {
          const rules = temp ? this.Session : this.Dynamic;
          const id = (temp ? SESSION_BASE : DYNAMIC_BASE) + rules.length;
          rules.push({
            id,
            priority,
            action: {
              type,
            },
            condition: {
              urlFilter,
              resourceTypes,
            }
          });
        });
      }
    };

    if (policy?.enforced) {
      Rules.add(policy.DEFAULT, DEFAULT_PRIORITY);
      for (const [siteKey, perms] of [...policy.sites]) {
        Rules.add(perms, SITE_PRIORITY, siteKey);
      }
    }

    await addTabRules(Rules.Session);

    const ts = Date.now(); // DEV_ONLY
    await Promise.allSettled(["Dynamic", "Session"].map((async (ruleType) => {
      const ts = Date.now(); // DEV_ONLY
      const removeRuleIds = (
        await browser.declarativeNetRequest[`get${ruleType}Rules`]()
      ).filter(r => r.priority <= MAX_PRIORITY).map(r => r.id);
      try {
        await browser.declarativeNetRequest[`update${ruleType}Rules`]({
          addRules: Rules[ruleType],
          removeRuleIds,
        });
        const newRules = (await browser.declarativeNetRequest[`get${ruleType}Rules`]()).filter(r => r.priority <= MAX_PRIORITY); // DEV_ONLY
        debug(`DNRPolicy ${Rules[ruleType].length} ${ruleType} rules updated in ${Date.now() - ts}ms`, newRules); // DEV_ONLY
      } catch (e) {
        error(e, `Failed to update DNRPolicy ${ruleType}rules %o - remove %o, add %o`, Rules[ruleType], addRules, removeRuleIds);
      }
    })));
    debug(`All DNRPolicy rules updated in ${Date.now() - ts}ms`); // DEV_ONLY
  }

  async function addTabRules(rules = []) {
    if (!ns.policy?.enforced) {
      return;
    }
    if (ns.unrestrictedTabs.size) {
      const tabIds = [...ns.unrestrictedTabs];
      tabIds.push(browser.tabs.TAB_ID_NONE); // for service workers
      rules.push({
        id: TAB_BASE,
        priority: TAB_PRIORITY,
        action: {
          type: "allowAllRequests",
        },
        condition: {
          tabIds,
          resourceTypes: ["main_frame", "sub_frame"],
        }
      });
      rules.push({
        id: TAB_BASE + 1,
        priority: TAB_PRIORITY,
        action: {
          type: "allow",
        },
        condition: {
          tabIds,
          resourceTypes: dnrTypes,
        }
      });
    }
    await addCtxRules(rules);
    return rules;
  }

  // Handle contextual policies and permissions/restrictions cascading,
  // both depending on the top-level (tab's) URL.
  async function addCtxRules(rules) {
    const {policy} = ns;
    const {cascadePermissions, cascadeRestrictions} = ns.sync;
    const ctxSettings = [...policy.sites].filter(([siteKey, perms]) => perms.contextual?.size);

    await TabCache.wakening;
    const tabs = (ctxSettings.length || cascadePermissions || cascadeRestrictions) &&
      TabCache.getAll().filter(tab => tab.url && !ns.unrestrictedTabs.has(tab.id));
    if (!tabs?.length) {
      return rules;
    }

    await NavCache.awakening;
    for (const tab of tabs) {
      tab.topUrls = NavCache.getTab(tab.id)?.topUrls || [tab.url];
    }
    for (const [siteKey,] of ctxSettings) {
      const ctxTabs = [];
      for (const tab of tabs) {
        for (const url of tab.topUrls) {
          const settings = policy.get(siteKey, url);
          if (!settings.contextMatch) continue;
          ctxTabs.push({
            id: tab.id,
            settings,
            domain: url != tab.url && tld.getDomain(new URL(url).hostname),
          });
        }
      }
      const caps2Tabs = new Map();
      for(const {id, settings, domain} of ctxTabs) {
        const capsKey = JSON.stringify({
          initiatorDomains: domain ? [domain] : undefined,
          capabilities: [...settings.perms.capabilities]
        });
        caps2Tabs.get(capsKey)?.push(id) || caps2Tabs.set(capsKey, [id]);
      }
      const urlFilter = toUrlFilter(siteKey);
      for (const [capsKey, tabIds] of [...caps2Tabs]) {
        const { initiatorDomains, capabilities } = JSON.parse(capsKey);
        forBlockAllow(new Set(capabilities), (type, resourceTypes) => {
          if (type == "allow" && resourceTypes.includes("script")) {
            tabIds.push(browser.tabs.TAB_ID_NONE); // for service workers
          }
          rules.push({
            id: TAB_BASE + rules.length,
            priority: CTX_PRIORITY,
            action: {
              type,
            },
            condition: {
              tabIds,
              urlFilter,
              resourceTypes,
              initiatorDomains,
            }
          });
        });
      }
    }
    if (cascadePermissions) {
      addCascadeRules("allow", CASCADE_PERMISSIONS_PRIORITY);
    }
    if (cascadeRestrictions) {
      addCascadeRules("block", CASCADE_RESTRICTIONS_PRIORITY);
    }

    function addCascadeRules(type /* either "block" or "allow" */, priority) {
      const tabPresets = new Map();
      const getResourceTypes = ResourceTypesFor[type];
      const lockToTopDomains = chrome.declarativeNetRequest.RuleConditionKeys?.TOP_DOMAINS;
      for (const { url, id } of tabs) {
        if (!url.startsWith("http")) {
          continue;
        }
        let domain;
        try {
          domain = new URL(url).hostname;
        } catch (e) {
        }
        if (!domain) {
          continue;
        }
        const resourceTypes = getResourceTypes(policy.get(url, url).perms.capabilities);
        if (!resourceTypes.length) continue;
        const key = JSON.stringify(resourceTypes);
        let preset;
        if (tabPresets.has(key)) {
          (preset = tabPresets.get(key)).tabIds.push(id);
        } else {
          tabPresets.set(key,
            preset = {
              resourceTypes,
              tabIds: [id],
          });
        }
        if (lockToTopDomains) {
          (preset[lockToTopDomains] ||= []).push(domain);
        }
      }
      for (const condition of tabPresets.values()) {
        rules.push({
          id: TAB_BASE + rules.length,
          priority,
          action: {
            type,
          },
          condition,
        });
      }
    }
  }

  async function getTabRules() {
    return (
      await browser.declarativeNetRequest.getSessionRules()
    ).filter(r => r.id >= TAB_BASE && r.id < DYNAMIC_BASE &&
      r.priority <= MAX_PRIORITY && r.condition.tabIds);
  }

  async function updateTabs() {
    const ts = Date.now();
    const removeRuleIds = (await getTabRules())
      .map(r => r.id);
    const addRules = await addTabRules();
    try {
      await browser.declarativeNetRequest.updateSessionRules({
        addRules,
        removeRuleIds,
      });
      debug(`DNRPolicy tab-bound rules updated in ${Date.now() - ts}ms`, addRules, removeRuleIds);
    } catch (e) {
      error(e, "Failed to update DNRPolicy tab-bound rules", addRules, removeRuleIds);
    }
  }

  function autoAllow(tabs, isStartup = false) {
    const {policy} = ns;
    const updated = [];
    if (policy.autoAllowTop) {
      for(const tab of tabs) {
        const { url } = tab;
        if (!url) {
          continue;
        }
        if (Sites.isInternal(url)) {
          updated.push(tab);
          continue;
        }
        const { perms } = policy.get(url, url);
        debug("DNRPolicy autoAllow check", tab, perms, perms === policy.DEFAULT);
        if (policy.autoAllow(url, perms, (isStartup && perms.temp))) {
          updated.push(tab);
        }
      }
      updated.length && debug("DNRPolicy.autoAllow", updated); // DEV_ONLY
    }
    return updated;
  }

  let updatingSemaphore;

  RequestGuard.DNRPolicy = {
    async update() {
      await updatingSemaphore;
      return await (updatingSemaphore = update());
    },
    async updateTabs() {
      await updatingSemaphore;
      return await (updatingSemaphore = updateTabs());
    }
  };

  browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
      // TODO: see if the update can be made more granular
      autoAllow([tab]).length
        ? Promise.allSettled([RequestGuard.DNRPolicy.update(), ns.saveSession()])
        : RequestGuard.DNRPolicy.updateTabs()
      ;
    }
  });

  NavCache.onUrlChanged.addListener((frame) => {
    if (frame.parentFrameId != -1) {
      return;
    }
   if (autoAllow([{ url: frame.url }]).length) {
      Promise.allSettled([RequestGuard.DNRPolicy.update(), ns.saveSession()]);
      return;
    }
    RequestGuard.DNRPolicy.updateTabs();
  });

  let delay;
  browser.tabs.onRemoved.addListener((tabId, removeInfo) => {
    // let's coalesce tabs updates on close
    delay ??= setTimeout(() => {
      delay = undefined;
      RequestGuard.DNRPolicy.updateTabs();
    }, 500);
  });
};
