// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:io';

import 'package:file/file.dart';
import 'package:file/memory.dart';
import 'package:path/path.dart' as path;

import '../check_examples_cross_imports.dart';
import '../cross_imports_checker_utils.dart';
import 'common.dart';
import 'cross_imports_checker_test_utils.dart';

// A pattern that matches `packages/flutter/examples/api/lib/**` and
// `packages/flutter/examples/api/test/**`, for use in tests.
final _kExamplesSlashApiLibraryPattern = RegExp(
  r'^packages/flutter/examples/api/(lib|test)/[a-z_]+',
);

void main() {
  late ExamplesCrossImportChecker checker;
  late _CrossImportsExamplesDirectories checkerDirectories;

  void buildKnownCrossImportExamplesFiles({Set<String> excludes = const <String>{}}) {
    final Map<Directory, Set<String>> knownFiles = checkerDirectories.getKnownFiles(
      checker.examplesDirectory,
    );

    for (final Set<String> files in knownFiles.values) {
      for (final filePath in files) {
        if (excludes.contains(filePath)) {
          continue;
        }

        final File file = checker.filesystem.file(
          path.join(
            checker.flutterRoot.absolute.path,
            filePath.replaceAll('/', Platform.pathSeparator),
          ),
        );

        final LibraryCrossImportStatementType importStatement =
            getCrossImportStatementForExamplesLibraryFile(filePath);

        writeImport(file, importStatement.importString);
      }
    }
  }

  setUp(() {
    final fs = MemoryFileSystem(
      style: Platform.isWindows ? FileSystemStyle.windows : FileSystemStyle.posix,
    );
    // Get the root prefix of the current directory so that on Windows we get a
    // correct root prefix.
    final Directory flutterRoot = fs.directory(
      path.join(path.rootPrefix(fs.currentDirectory.absolute.path), 'flutter sdk'),
    )..createSync(recursive: true);
    fs.currentDirectory = flutterRoot;

    final Directory examplesDirectory = flutterRoot.childDirectory('examples')..createSync();
    final Directory apiDocDirectory =
        flutterRoot
            .childDirectory('packages')
            .childDirectory('flutter')
            .childDirectory('examples')
            .childDirectory('api')
          ..createSync(recursive: true);

    checker = ExamplesCrossImportChecker(
      examplesDirectory: examplesDirectory,
      apiDocDirectory: apiDocDirectory,
      flutterRoot: flutterRoot,
      filesystem: fs,
    );
    checkerDirectories = _CrossImportsExamplesDirectories(examplesDirectory)
      ..createExamplesDirectories(examplesDirectory);
  });

  test('when only all knowns have cross imports', () async {
    buildKnownCrossImportExamplesFiles();
    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    });
    expect(result, equals(''));
    expect(success, isTrue);
  });

  test('non-Dart files are ignored', () async {
    buildKnownCrossImportExamplesFiles();

    checker.examplesDirectory.childFile('README.md')
      ..createSync()
      ..writeAsStringSync("import 'package:flutter/material.dart';");

    expect(checker.check(), isTrue);
  });

  test('non-Dart files are ignored in nested directories', () async {
    buildKnownCrossImportExamplesFiles();

    checker.examplesDirectory
        .childDirectory('layers')
        .childDirectory('rendering')
        .childFile('README.md')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/material.dart';");

    expect(checker.check(), isTrue);
  });

  test('non-Dart files with .dart in the filename are ignored', () async {
    buildKnownCrossImportExamplesFiles();

    checker.examplesDirectory.childFile('foo.dart.md')
      ..createSync()
      ..writeAsStringSync("import 'package:flutter/material.dart';");

    expect(checker.check(), isTrue);
  });

  test('non-Dart files with .dart in the filename are ignored in nested directories', () async {
    buildKnownCrossImportExamplesFiles();

    checker.examplesDirectory
        .childDirectory('layers')
        .childDirectory('rendering')
        .childFile('foo.dart.md')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/material.dart';");

    expect(checker.check(), isTrue);
  });

  test('examples/api/lib/sample_templates templates produce no violations when valid', () async {
    final Directory sampleTemplatesDirectory = checker.apiDocDirectory
        .childDirectory('lib')
        .childDirectory('sample_templates');

    for (final i in [0, 1, 2]) {
      sampleTemplatesDirectory.childFile('cupertino.$i.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/cupertino.dart';");
      sampleTemplatesDirectory.childFile('material.$i.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/material.dart';");
      sampleTemplatesDirectory.childFile('widgets.$i.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/widgets.dart';");
    }

    buildKnownCrossImportExamplesFiles();
    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    });
    expect(result, equals(''));
    expect(success, isTrue);
  });

  test('examples/api/lib/sample_templates templates produce violations when invalid', () async {
    final Directory sampleTemplatesDirectory = checker.apiDocDirectory
        .childDirectory('lib')
        .childDirectory('sample_templates');

    sampleTemplatesDirectory.childFile('cupertino.0.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/material.dart';");
    sampleTemplatesDirectory.childFile('material.0.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/cupertino.dart';");
    sampleTemplatesDirectory.childFile('widgets.0.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/cupertino.dart';");

    buildKnownCrossImportExamplesFiles();
    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    }, shouldHaveErrors: true);

    final String lines = <String>[
      '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/lib/sample_templates has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
      '║   packages/flutter/examples/api/lib/sample_templates/cupertino.0.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
      '╔═╡ERROR #2╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/lib/sample_templates has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
      '║   packages/flutter/examples/api/lib/sample_templates/material.0.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
      '╔═╡ERROR #3╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/lib/sample_templates has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
      '║   packages/flutter/examples/api/lib/sample_templates/widgets.0.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
    ].join('\n');
    expect(result, equals('$lines\n'));
    expect(success, isFalse);
  });

  test('examples/api/test/sample_templates templates produce no violations when valid', () async {
    final Directory sampleTemplatesDirectory = checker.apiDocDirectory
        .childDirectory('test')
        .childDirectory('sample_templates');

    for (final i in [0, 1, 2]) {
      sampleTemplatesDirectory.childFile('cupertino.${i}_test.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/cupertino.dart';");
      sampleTemplatesDirectory.childFile('material.${i}_test.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/material.dart';");
      sampleTemplatesDirectory.childFile('widgets.${i}_test.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/widgets.dart';");
    }

    buildKnownCrossImportExamplesFiles();
    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    });
    expect(result, equals(''));
    expect(success, isTrue);
  });

  test('examples/api/test/sample_templates templates produce violations when invalid', () async {
    final Directory sampleTemplatesDirectory = checker.apiDocDirectory
        .childDirectory('test')
        .childDirectory('sample_templates');

    sampleTemplatesDirectory.childFile('cupertino.0_test.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/material.dart';");
    sampleTemplatesDirectory.childFile('material.0_test.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/cupertino.dart';");
    sampleTemplatesDirectory.childFile('widgets.0_test.dart')
      ..createSync(recursive: true)
      ..writeAsStringSync("import 'package:flutter/cupertino.dart';");

    buildKnownCrossImportExamplesFiles();
    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    }, shouldHaveErrors: true);

    final String lines = <String>[
      '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/test/sample_templates has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
      '║   packages/flutter/examples/api/test/sample_templates/cupertino.0_test.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
      '╔═╡ERROR #2╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/test/sample_templates has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
      '║   packages/flutter/examples/api/test/sample_templates/material.0_test.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
      '╔═╡ERROR #3╞════════════════════════════════════════════════════════════════════',
      '║ The following file in packages/flutter/examples/api/test/sample_templates has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
      '║   packages/flutter/examples/api/test/sample_templates/widgets.0_test.dart',
      '╚═══════════════════════════════════════════════════════════════════════════════',
    ].join('\n');
    expect(result, equals('$lines\n'));
    expect(success, isFalse);
  });

  for (final String libraryName in crossImportsGenericExamplesTestCases) {
    // The examples root (examples/) is expected to not contain examples.
    final bool hasNoCrossImports =
        isExamplesRoot(libraryName) || hasNoKnownCrossImports(libraryName);

    test(
      'when not all $libraryName knowns have cross imports',
      () async {
        final String excludedSample = getFirstCrossImportForLibrary(libraryName);

        buildKnownCrossImportExamplesFiles(excludes: <String>{excludedSample});

        bool? success;
        final String result = await capture(() async {
          success = checker.check();
        }, shouldHaveErrors: true);
        final String lines = <String>[
          '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
          '║ Huzzah! The following files in $libraryName no longer contain cross imports!',
          '║   $excludedSample',
          '║ However, they now need to be removed from the',
          '║ knownExamplesCrossImports list in the script /dev/bots/check_examples_cross_imports.dart.',
          '╚═══════════════════════════════════════════════════════════════════════════════',
        ].join('\n');
        expect(result, equals('$lines\n'));
        expect(success, isFalse);
      },
      skip: hasNoCrossImports, // [intended]: Nothing to log if there are no known imports
    );

    test('unknown $libraryName cross import of Material', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles({dartFile}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('multiple unknown $libraryName cross imports of Material', () async {
      final dartFileOne = '$libraryName/foo.dart';
      final dartFileTwo = '$libraryName/bar.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles({dartFileOne, dartFileTwo}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following 2 files in $libraryName have a disallowed import of Material. Refactor them or move them to the material_ui examples.',
        '║   $dartFileOne',
        '║   $dartFileTwo',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of Material in test file', () async {
      final testDartFile = '$libraryName/foo_test.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(<String>{testDartFile}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $testDartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of material_ui', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:material_ui/material_ui.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of material_ui. Refactor it or move it to the material_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of both Material and material_ui', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFile},
        inDirectory: examplesFilesDirectory,
        importString:
            "import 'package:flutter/material.dart';\n"
            "import 'package:material_ui/material_ui.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
        '╔═╡ERROR #2╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of material_ui. Refactor it or move it to the material_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of cupertino_ui', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:cupertino_ui/cupertino_ui.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of cupertino_ui. Refactor it or move it to the cupertino_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of Cupertino', () async {
      final dartFile = '$libraryName/foo.dart';
      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        <String>{dartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of both Cupertino and cupertino_ui', () async {
      final dartFile = '$libraryName/foo.dart';
      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        <String>{dartFile},
        inDirectory: examplesFilesDirectory,
        importString:
            "import 'package:flutter/cupertino.dart';\n"
            "import 'package:cupertino_ui/cupertino_ui.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
        '╔═╡ERROR #2╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of cupertino_ui. Refactor it or move it to the cupertino_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('multiple unknown $libraryName cross imports of Cupertino', () async {
      final dartFileOne = '$libraryName/foo.dart';
      final dartFileTwo = '$libraryName/bar.dart';

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFileOne, dartFileTwo},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following 2 files in $libraryName have a disallowed import of Cupertino. Refactor them or move them to the cupertino_ui examples.',
        '║   $dartFileOne',
        '║   $dartFileTwo',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('unknown $libraryName cross import of Cupertino in test file', () async {
      final testDartFile = '$libraryName/foo_test.dart';
      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        <String>{testDartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
        '║   $testDartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });

    test('files under $libraryName/build are ignored', () async {
      buildKnownCrossImportExamplesFiles();

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      final Directory buildDirectory = examplesFilesDirectory.childDirectory('build')..createSync();
      buildDirectory.childFile('foo.dart')
        ..createSync()
        ..writeAsStringSync("import 'package:flutter/material.dart';");

      expect(checker.check(), isTrue);
    });

    test('files under $libraryName/.dart_tool are ignored', () async {
      buildKnownCrossImportExamplesFiles();

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      final Directory dartToolDirectory = examplesFilesDirectory.childDirectory('.dart_tool')
        ..createSync();
      dartToolDirectory.childFile('foo.dart')
        ..createSync()
        ..writeAsStringSync("import 'package:flutter/material.dart';");

      expect(checker.check(), isTrue);
    });

    test('files in $libraryName subdirectories are checked', () async {
      buildKnownCrossImportExamplesFiles();

      final Directory examplesFilesDirectory = checkerDirectories.examplesFilesDirectoryFor(
        libraryName,
        checker.examplesDirectory,
      );

      examplesFilesDirectory.childDirectory('baz').childDirectory('bar').childFile('foo.dart')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/material.dart';");

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);

      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $libraryName/baz/bar/foo.dart',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isExamplesRoot(libraryName)); // [intended]: The root directory should not have examples
  }

  for (final String libraryName in crossImportsExamplesApiTestCases) {
    // This flag is defined here, instead of near the `skip:` below,
    // due to a formatter bug with comments and named arguments,
    // which causes `dev/bots/analyze.dart` to fail, since the skip test comment gets put on the next line.
    // TODO(navaronbracke): Remove this when https://github.com/dart-lang/dart_style/pull/1848 rolls into Flutter
    final bool noCrossImports = hasNoKnownCrossImports(libraryName);

    test('non-Dart files are ignored in $libraryName', () async {
      buildKnownCrossImportExamplesFiles();

      final Directory directory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      directory.childFile('README.md')
        ..createSync()
        ..writeAsStringSync("import 'package:flutter/material.dart';");

      expect(checker.check(), isTrue);
    });

    test('non-Dart files are ignored in $libraryName subdirectories', () async {
      buildKnownCrossImportExamplesFiles();

      final Directory directory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      directory.childDirectory('layers').childDirectory('rendering').childFile('README.md')
        ..createSync(recursive: true)
        ..writeAsStringSync("import 'package:flutter/material.dart';");

      expect(checker.check(), isTrue);
    });

    test(
      'non-Dart files with .dart in the filename are ignored $libraryName subdirectories',
      () async {
        buildKnownCrossImportExamplesFiles();

        final Directory directory = getDirectoryForExamplesSlashApiLibrary(
          libraryName,
          flutterRoot: checker.flutterRoot,
        );

        directory.childDirectory('layers').childDirectory('rendering').childFile('foo.dart.md')
          ..createSync(recursive: true)
          ..writeAsStringSync("import 'package:flutter/material.dart';");

        expect(checker.check(), isTrue);
      },
    );

    test(
      'when not all $libraryName knowns have cross imports',
      () async {
        final String excludedSample = getFirstCrossImportForLibrary(libraryName);

        buildKnownCrossImportExamplesFiles(excludes: <String>{excludedSample});

        bool? success;
        final String result = await capture(() async {
          success = checker.check();
        }, shouldHaveErrors: true);
        final String lines = <String>[
          '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
          '║ Huzzah! The following files in $libraryName no longer contain cross imports!',
          '║   $excludedSample',
          '║ However, they now need to be removed from the',
          '║ knownExamplesCrossImports list in the script /dev/bots/check_examples_cross_imports.dart.',
          '╚═══════════════════════════════════════════════════════════════════════════════',
        ].join('\n');
        expect(result, equals('$lines\n'));
        expect(success, isFalse);
      },
      skip: noCrossImports, // [intended]: Nothing to log if there are no known imports.
    );

    test('unknown $libraryName cross import of Material', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles({dartFile}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isMaterialExample(libraryName)); // [intended]: Material examples can import Material

    test('multiple unknown $libraryName cross imports of Material', () async {
      final dartFileOne = '$libraryName/foo.dart';
      final dartFileTwo = '$libraryName/bar.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles({dartFileOne, dartFileTwo}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following 2 files in $libraryName have a disallowed import of Material. Refactor them or move them to the material_ui examples.',
        '║   $dartFileOne',
        '║   $dartFileTwo',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isMaterialExample(libraryName)); // [intended]: Material examples can import Material

    test('unknown $libraryName cross import of Material in test file', () async {
      final testDartFile = '$libraryName/foo_test.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(<String>{testDartFile}, inDirectory: examplesFilesDirectory);

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Material. Refactor it or move it to the material_ui examples.',
        '║   $testDartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isMaterialExample(libraryName)); // [intended]: Material examples can import Material

    test('unknown $libraryName cross import of Cupertino', () async {
      final dartFile = '$libraryName/foo.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isCupertinoExample(libraryName)); // [intended]: Cupertino examples can import Cupertino

    test('multiple unknown $libraryName cross imports of Cupertino', () async {
      final dartFileOne = '$libraryName/foo.dart';
      final dartFileTwo = '$libraryName/bar.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFileOne, dartFileTwo},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following 2 files in $libraryName have a disallowed import of Cupertino. Refactor them or move them to the cupertino_ui examples.',
        '║   $dartFileOne',
        '║   $dartFileTwo',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isCupertinoExample(libraryName)); // [intended]: Cupertino examples can import Cupertino

    test('unknown $libraryName cross import of Cupertino in test file', () async {
      final testDartFile = '$libraryName/foo_test.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        <String>{testDartFile},
        inDirectory: examplesFilesDirectory,
        importString: "import 'package:flutter/cupertino.dart';",
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);
      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of Cupertino. Refactor it or move it to the cupertino_ui examples.',
        '║   $testDartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    }, skip: isCupertinoExample(libraryName)); // [intended]: Cupertino examples can import Cupertino

    test('files in $libraryName subdirectories are checked', () async {
      final dartFile = '$libraryName/baz/bar/foo.dart';

      final Directory examplesFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
        libraryName,
        flutterRoot: checker.flutterRoot,
      );

      final LibraryCrossImportStatementType importStatement =
          getCrossImportStatementForExamplesLibraryFile(dartFile);
      final String disallowedImportName = importStatement.readableName;
      final String destination = switch (importStatement) {
        LibraryCrossImportStatementType.material => 'material_ui',
        LibraryCrossImportStatementType.cupertino => 'cupertino_ui',
        _ => disallowedImportName,
      };

      buildKnownCrossImportExamplesFiles();
      writeImportInFiles(
        {dartFile},
        inDirectory: examplesFilesDirectory,
        importString: importStatement.importString,
      );

      bool? success;
      final String result = await capture(() async {
        success = checker.check();
      }, shouldHaveErrors: true);

      final String lines = <String>[
        '╔═╡ERROR #1╞════════════════════════════════════════════════════════════════════',
        '║ The following file in $libraryName has a disallowed import of $disallowedImportName. Refactor it or move it to the $destination examples.',
        '║   $dartFile',
        '╚═══════════════════════════════════════════════════════════════════════════════',
      ].join('\n');
      expect(result, equals('$lines\n'));
      expect(success, isFalse);
    });
  }

  test('Material API examples in examples/api are ignored explicitly', () async {
    // The Material examples in examples/api have been moved to packages/material_ui.
    // The original code is still present in examples/api until it can be finally deleted from there.
    // For this reason the checker should ignore the Material examples in examples/api,
    // even if they contain cross imports.

    buildKnownCrossImportExamplesFiles();

    const examplesApiMaterialLibraryName = 'packages/flutter/examples/api/lib/material';
    const examplesApiMaterialTestLibraryName = 'packages/flutter/examples/api/test/material';
    const LibraryCrossImportStatementType importStatement = .cupertino;

    final Directory examplesMaterialLibFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
      examplesApiMaterialLibraryName,
      flutterRoot: checker.flutterRoot,
    );

    final Directory examplesMaterialTestFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
      examplesApiMaterialTestLibraryName,
      flutterRoot: checker.flutterRoot,
    );

    writeImportInFiles(
      {
        'packages/flutter/examples/api/lib/material/qux.dart',
        'packages/flutter/examples/api/lib/material/baz/foo.dart',
      },
      inDirectory: examplesMaterialLibFilesDirectory,
      importString: importStatement.importString,
    );

    writeImportInFiles(
      {
        'packages/flutter/examples/api/test/material/qux_test.dart',
        'packages/flutter/examples/api/test/material/baz/foo_test.dart',
      },
      inDirectory: examplesMaterialTestFilesDirectory,
      importString: importStatement.importString,
    );

    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    });
    expect(result, equals(''));
    expect(success, isTrue);
  });

  test('Cupertino API examples in examples/api are ignored explicitly', () async {
    // The Cupertino examples in examples/api have been moved to packages/cupertino_ui.
    // The original code is still present in examples/api until it can be finally deleted from there.
    // For this reason the checker should ignore the Cupertino examples in examples/api,
    // even if they contain cross imports.

    buildKnownCrossImportExamplesFiles();

    const examplesApiCupertinoLibraryName = 'packages/flutter/examples/api/lib/cupertino';
    const examplesApiCupertinoTestLibraryName = 'packages/flutter/examples/api/test/cupertino';
    const LibraryCrossImportStatementType importStatement = .material;

    final Directory examplesCupertinoLibFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
      examplesApiCupertinoLibraryName,
      flutterRoot: checker.flutterRoot,
    );

    final Directory examplesCupertinoTestFilesDirectory = getDirectoryForExamplesSlashApiLibrary(
      examplesApiCupertinoTestLibraryName,
      flutterRoot: checker.flutterRoot,
    );

    writeImportInFiles(
      {
        'packages/flutter/examples/api/lib/cupertino/qux.dart',
        'packages/flutter/examples/api/lib/cupertino/baz/foo.dart',
      },
      inDirectory: examplesCupertinoLibFilesDirectory,
      importString: importStatement.importString,
    );

    writeImportInFiles(
      {
        'packages/flutter/examples/api/test/cupertino/qux_test.dart',
        'packages/flutter/examples/api/test/cupertino/baz/foo_test.dart',
      },
      inDirectory: examplesCupertinoTestFilesDirectory,
      importString: importStatement.importString,
    );

    bool? success;
    final String result = await capture(() async {
      success = checker.check();
    });
    expect(result, equals(''));
    expect(success, isTrue);
  });
}

/// Get a [LibraryCrossImportStatementType], for the file at the given [filePath],
/// that will result in the [ExamplesCrossImportChecker] flagging the file as having disallowed cross imports.
///
/// Returns [LibraryCrossImportStatementType.cupertino] if the file is in the Material examples,
/// and [LibraryCrossImportStatementType.material] if the file is in the Cupertino examples.
///
/// Returns [LibraryCrossImportStatementType.material] for any other library,
/// such as `examples/layers/rendering/spinning_square.dart`.
LibraryCrossImportStatementType getCrossImportStatementForExamplesLibraryFile(String filePath) {
  if (filePath.startsWith('packages/flutter/examples/api/lib/material/') ||
      filePath.startsWith('packages/flutter/examples/api/test/material/')) {
    return LibraryCrossImportStatementType.cupertino;
  }

  if (filePath.startsWith('packages/flutter/examples/api/lib/cupertino/') ||
      filePath.startsWith('packages/flutter/examples/api/test/cupertino/')) {
    return LibraryCrossImportStatementType.material;
  }

  return LibraryCrossImportStatementType.material;
}

/// Get the directory for the given `examples/api` [libraryName].
///
/// The library name can only contain lowercase a-z and underscores
/// and must start with either `examples/api/lib` or `examples/api/test`.
Directory getDirectoryForExamplesSlashApiLibrary(
  String libraryName, {
  required Directory flutterRoot,
}) {
  if (!_kExamplesSlashApiLibraryPattern.hasMatch(libraryName)) {
    throw ArgumentError('Invalid library name: $libraryName', 'libraryName');
  }

  final String fullPath = path.joinAll([flutterRoot.path, ...libraryName.split('/')]);

  return flutterRoot.fileSystem.directory(fullPath);
}

/// Get the first known cross import for the given [libraryName].
///
/// Throws a [StateError] if there are no known cross imports for the given library.
String getFirstCrossImportForLibrary(String libraryName) {
  // Use the first entry that belongs to this library, since known imports sets
  // are shared between lib/ and test/ directories and may contain paths for both.
  return ExamplesCrossImportChecker.knownExamplesCrossImports.firstWhere(
    (String p) => p.startsWith('$libraryName/'),
  );
}

/// Returns whether there are no known cross imports for the given [libraryName].
bool hasNoKnownCrossImports(String libraryName) {
  return !ExamplesCrossImportChecker.knownExamplesCrossImports.any(
    (String entry) => entry.startsWith('$libraryName/'),
  );
}

/// Returns whether the given [libraryName] matches the Material examples under `examples/api`.
bool isMaterialExample(String libraryName) {
  return libraryName == 'packages/flutter/examples/api/lib/material' ||
      libraryName == 'packages/flutter/examples/api/test/material';
}

/// Returns whether the given [libraryName] matches the Cupertino examples under `examples/api`.
bool isCupertinoExample(String libraryName) {
  return libraryName == 'packages/flutter/examples/api/lib/cupertino' ||
      libraryName == 'packages/flutter/examples/api/test/cupertino';
}

/// Returns whether the given [libraryName] matches the root `examples` or `examples/api` directories,
/// which contain subdirectories with examples, but should themselves be void of examples.
bool isExamplesRoot(String libraryName) {
  return libraryName == 'examples' || libraryName == 'packages/flutter/examples/api';
}

// A utility that keeps track of the directories under test,
// to avoid having to late initialize them individually in `setUp()`.
class _CrossImportsExamplesDirectories {
  factory _CrossImportsExamplesDirectories(Directory examplesDirectory) {
    return _CrossImportsExamplesDirectories._(
      examplesSlashApiDirectory: examplesDirectory.parent
          .childDirectory('packages')
          .childDirectory('flutter')
          .childDirectory('examples')
          .childDirectory('api'),
      examplesFlutterViewDirectory: examplesDirectory.childDirectory('flutter_view'),
      examplesHelloWorldDirectory: examplesDirectory.childDirectory('hello_world'),
      examplesImageListDirectory: examplesDirectory.childDirectory('image_list'),
      examplesLayersDirectory: examplesDirectory.childDirectory('layers'),
      examplesMultipleWindowsDirectory: examplesDirectory.childDirectory('multiple_windows'),
      examplesPlatformChannelDirectory: examplesDirectory.childDirectory('platform_channel'),
      examplesPlatformChannelSwiftDirectory: examplesDirectory.childDirectory(
        'platform_channel_swift',
      ),
      examplesPlatformViewDirectory: examplesDirectory.childDirectory('platform_view'),
      examplesSplashDirectory: examplesDirectory.childDirectory('splash'),
      examplesTextureDirectory: examplesDirectory.childDirectory('texture'),
    );
  }

  const _CrossImportsExamplesDirectories._({
    required this.examplesSlashApiDirectory,
    required this.examplesFlutterViewDirectory,
    required this.examplesHelloWorldDirectory,
    required this.examplesImageListDirectory,
    required this.examplesLayersDirectory,
    required this.examplesMultipleWindowsDirectory,
    required this.examplesPlatformChannelDirectory,
    required this.examplesPlatformChannelSwiftDirectory,
    required this.examplesPlatformViewDirectory,
    required this.examplesSplashDirectory,
    required this.examplesTextureDirectory,
  });

  final Directory examplesSlashApiDirectory;
  final Directory examplesFlutterViewDirectory;
  final Directory examplesHelloWorldDirectory;
  final Directory examplesImageListDirectory;
  final Directory examplesLayersDirectory;
  final Directory examplesMultipleWindowsDirectory;
  final Directory examplesPlatformChannelDirectory;
  final Directory examplesPlatformChannelSwiftDirectory;
  final Directory examplesPlatformViewDirectory;
  final Directory examplesSplashDirectory;
  final Directory examplesTextureDirectory;

  /// A mapping of `examples/xyz` directories
  /// to their corresponding known imports list in `check_examples_cross_imports.dart`
  Map<Directory, Set<String>> getKnownFiles(Directory examplesDirectory) {
    final Directory libDirectory = examplesSlashApiDirectory.childDirectory('lib');
    final Directory testDirectory = examplesSlashApiDirectory.childDirectory('test');
    final Map<Directory, Set<String>> exampleSlashApiSubdirectoryMapping = {};

    for (final directory in <Directory>[libDirectory, testDirectory]) {
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('animation')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('foundation')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('gestures')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('painting')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('rendering')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('sample_templates')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('services')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('ui')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
      exampleSlashApiSubdirectoryMapping[directory.childDirectory('widgets')] =
          ExamplesCrossImportChecker.knownExamplesCrossImports;
    }

    return <Directory, Set<String>>{
      examplesDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesSlashApiDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      ...exampleSlashApiSubdirectoryMapping,
      examplesFlutterViewDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesHelloWorldDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesImageListDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesLayersDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesMultipleWindowsDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesPlatformChannelDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesPlatformChannelSwiftDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesPlatformViewDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesSplashDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
      examplesTextureDirectory: ExamplesCrossImportChecker.knownExamplesCrossImports,
    };
  }

  /// Create the `examples/xyz` directories for the test cases, excluding `examples/api` subdirectories.
  void createExamplesDirectories(Directory examplesDirectory) {
    final Map<Directory, Set<String>> knownFiles = getKnownFiles(examplesDirectory);

    for (final Directory directory in knownFiles.keys) {
      // The `examples` directory is created in `setUp()`.
      if (directory == examplesDirectory) {
        continue;
      }

      directory.createSync(recursive: true);
    }
  }

  /// Get the examples directory for the given [libraryName].
  Directory examplesFilesDirectoryFor(String libraryName, Directory examplesDirectory) {
    const unsupportedPrefix = 'packages/flutter/examples/api';

    if (libraryName.startsWith(unsupportedPrefix) &&
        libraryName.length > unsupportedPrefix.length) {
      throw ArgumentError(
        'For $libraryName, use getDirectoryForExamplesSlashApiLibrary(libraryName) instead, '
        'which supports getting directories for examples/api lib and test subdirectories.',
      );
    }

    return switch (libraryName) {
      'examples' => examplesDirectory,
      'packages/flutter/examples/api' => examplesSlashApiDirectory,
      'examples/flutter_view' => examplesFlutterViewDirectory,
      'examples/hello_world' => examplesHelloWorldDirectory,
      'examples/image_list' => examplesImageListDirectory,
      'examples/layers' => examplesLayersDirectory,
      'examples/multiple_windows' => examplesMultipleWindowsDirectory,
      'examples/platform_channel' => examplesPlatformChannelDirectory,
      'examples/platform_channel_swift' => examplesPlatformChannelSwiftDirectory,
      'examples/platform_view' => examplesPlatformViewDirectory,
      'examples/splash' => examplesSplashDirectory,
      'examples/texture' => examplesTextureDirectory,
      _ => throw ArgumentError('Unknown library name: $libraryName'),
    };
  }
}

// A mapping of `examples/**` test cases for the cross imports checker, excluding `examples/api/**`.
const crossImportsGenericExamplesTestCases = <String>[
  'examples',
  'packages/flutter/examples/api',
  'examples/flutter_view',
  'examples/hello_world',
  'examples/image_list',
  'examples/layers',
  'examples/multiple_windows',
  'examples/platform_channel',
  'examples/platform_channel_swift',
  'examples/platform_view',
  'examples/splash',
  'examples/texture',
];

// A mapping of `examples/api/lib/**` and `examples/api/test/**` test cases for the cross imports checker,
// excluding `examples/api/lib/sample_templates` and `examples/api/test/sample_templates`.
const crossImportsExamplesApiTestCases = <String>[
  'packages/flutter/examples/api/lib/animation',
  'packages/flutter/examples/api/lib/foundation',
  'packages/flutter/examples/api/lib/gestures',
  'packages/flutter/examples/api/lib/painting',
  'packages/flutter/examples/api/lib/rendering',
  'packages/flutter/examples/api/lib/services',
  'packages/flutter/examples/api/lib/ui',
  'packages/flutter/examples/api/lib/widgets',
  'packages/flutter/examples/api/test/animation',
  'packages/flutter/examples/api/test/foundation',
  'packages/flutter/examples/api/test/gestures',
  'packages/flutter/examples/api/test/painting',
  'packages/flutter/examples/api/test/rendering',
  'packages/flutter/examples/api/test/services',
  'packages/flutter/examples/api/test/ui',
  'packages/flutter/examples/api/test/widgets',
];
