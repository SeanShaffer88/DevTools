<script setup lang="ts">
import { computed } from 'vue';
import createLucideIcon from '@lucide/vue/src/createLucideIcon';
import { useMediaQuery } from '@vueuse/core';
import { useRouter } from 'vitepress';
import { toast } from 'vue-sonner';
import getSVGIcon from '../../utils/getSVGIcon';
import useConfetti from '../../composables/useConfetti';
import Tooltip from '../base/Tooltip.vue';
import { diamond } from '../../../data/iconNodes';
import { setLibraryParams } from '../../composables/useExternalLibs';

const downloadText = 'Download!';
const copiedText = 'Copied!';

export type IconNode = [elementName: string, attrs: Record<string, string>][];

const props = defineProps<{
  name: string;
  iconNode: IconNode;
  active: boolean;
  externalLibrary?: string;
  customizable?: boolean;
  overlayMode?: boolean;
  hideIcon?: boolean;
}>();

const emit = defineEmits(['setActiveIcon']);

const { go } = useRouter();
const showOverlay = useMediaQuery('(min-width: 860px)');
const { animate, confetti, confettiText } = useConfetti();

const icon = computed(() => {
  if (!props.name || !props.iconNode) return null;
  return createLucideIcon(props.name, props.iconNode);
});

const href = computed(() =>
  props.externalLibrary ? `/icons/${props.externalLibrary}/${props.name}` : `/icons/${props.name}`,
);

// The toast says what was copied, since the name and the SVG are copied the same way
async function copyToClipboard(text: string, confettiMessage: string, toastMessage: string) {
  await navigator.clipboard.writeText(text);

  confettiText.value = confettiMessage;
  confetti();
  toast.success(toastMessage);
}

function copyName() {
  return copyToClipboard(props.name, `Copied name!`, `Copied the name of ${props.name}`);
}

function copySVG(iconButton: HTMLElement) {
  const svgString = getSVGIcon(iconButton.querySelector('svg'), {
    class: `lucide lucide-${props.name}`,
  });

  return copyToClipboard(svgString, `Copied SVG!`, `Copied the SVG of ${props.name}`);
}

async function navigateToIcon(event) {
  if (event.shiftKey) {
    event.preventDefault();
    await copySVG(event.currentTarget);
    return;
  }

  if (event.ctrlKey || event.metaKey) {
    event.preventDefault();
    await copyName();
    return;
  }

  if (props.overlayMode && showOverlay.value) {
    event.preventDefault();

    // Keep ?library= so the selection survives opening and closing the drawer.
    const url = setLibraryParams(
      new URL(
        props.externalLibrary
          ? `/icons/${props.externalLibrary}/${props.name}`
          : `/icons/${props.name}`,
        window.location.origin,
      ),
    );

    window.history.pushState({}, '', url);
    emit(
      'setActiveIcon',
      props.externalLibrary ? `${props.externalLibrary}:${props.name}` : props.name,
    );
  } else {
    event.preventDefault();
    go(
      props.externalLibrary
        ? `/icons/${props.externalLibrary}/${props.name}`
        : `/icons/${props.name}`,
    );
  }
}

// On a selected (focused) icon: Enter opens it, Ctrl/Cmd + C copies its name, Shift + C its SVG.
// (Ctrl/Cmd + Shift + C is the browser's inspect shortcut, so it can't be used for the SVG.)
async function handleKeydown(event: KeyboardEvent) {
  if (
    event.key === 'Enter' &&
    !(event.shiftKey || event.ctrlKey || event.metaKey || event.altKey)
  ) {
    await navigateToIcon(event);
    return;
  }

  if (event.key.toLowerCase() !== 'c' || event.altKey) return;

  if (event.shiftKey && !(event.ctrlKey || event.metaKey)) {
    event.preventDefault();
    await copySVG(event.currentTarget as HTMLElement);
    return;
  }

  if (!(event.ctrlKey || event.metaKey) || event.shiftKey) return;

  // Leave a normal copy alone when some text on the page is selected
  if (window.getSelection()?.toString()) return;

  event.preventDefault();
  await copyName();
}

const DiamondIcon = createLucideIcon('Diamond', diamond);
</script>

<template>
  <Tooltip :title="name">
    <a
      class="icon-button confetti-button vp-raw"
      tabindex="0"
      @click="navigateToIcon"
      @keydown="handleKeydown"
      :class="{ active, animate }"
      :aria-label="name"
      :data-confetti-text="confettiText"
      ref="ref"
    >
      <KeepAlive>
        <component
          v-if="!hideIcon"
          :is="icon"
          class="lucide-icon"
          :class="{
            customizable,
          }"
        />
      </KeepAlive>
      <div
        v-if="externalLibrary"
        class="floating-diamond"
        aria-hidden="true"
      >
        <DiamondIcon
          fill="currentColor"
          :size="8"
        />
      </div>
    </a>
  </Tooltip>
</template>

<style src="./confetti.css" />

<style scoped>
.icon-button {
  position: relative;
  display: inline-block;
  border: 1px solid transparent;
  text-align: center;
  font-weight: 600;
  border-radius: 4px;
  white-space: nowrap;
  transition:
    color 0.25s,
    border-color 0.25s,
    background-color 0.25s;
  border-radius: 6px;
  background-color: var(--vp-c-bg-alt);
  display: inline-flex;
  width: 56px;
  height: 56px;
  font-size: 24px;
  color: var(--vp-c-text-1);
}

.floating-diamond {
  position: absolute;
  top: 4px;
  right: 4px;
  color: var(--vp-c-brand);
}

.confetti-button:before,
.confetti-button:after {
  z-index: 100;
}

.confetti-button:before {
  line-height: 80px;
  /* Center the "Copied ..." text over the icon (it started at the icon's left edge and ran off to the right). */
  width: 160px;
  max-width: none;
  left: calc(50% - 80px);
  text-align: center;
  white-space: nowrap;
}

.icon-button:active {
  transition:
    color 0.1s,
    border-color 0.1s,
    background-color 0.1s;
}

.icon-button.medium {
  border-radius: 20px;
  padding: 0 20px;
  line-height: 38px;
  font-size: 14px;
}

.icon-button.big {
  border-radius: 24px;
  padding: 0 24px;
  line-height: 46px;
  font-size: 16px;
}

.icon-button:hover {
  border-color: var(--vp-button-alt-hover-border);
  color: var(--vp-button-alt-hover-text);
  background-color: var(--vp-button-alt-hover-bg);
}

.icon-button:active {
  border-color: var(--vp-button-alt-active-border);
  color: var(--vp-button-alt-active-text);
  background-color: var(--vp-button-alt-active-bg);
}

.icon-button.active,
.icon-button.animate,
.icon-button:focus-visible {
  border-color: var(--vp-c-brand);
}

.icon-button:focus-visible {
  outline: none;
}

.lucide-icon {
  margin: auto;
  pointer-events: none;
}
.lucide-icon.customizable {
  will-change: width, height, stroke-width, stroke;
  color: var(--customize-color, currentColor);
  stroke-width: var(--customize-strokeWidth, 2);
  width: calc(var(--customize-size, 24) * 1px);
  height: calc(var(--customize-size, 24) * 1px);
  max-width: 3rem;
  max-height: 3rem;
}

html.non-scaling-stroke .lucide-icon.customizable {
  stroke-width: calc(var(--customize-strokeWidth, 2) * 24 / var(--customize-size, 24));
}
</style>
