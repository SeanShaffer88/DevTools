<script setup lang="ts">
import { computed, onMounted } from 'vue';
import { useIconStyle } from '../../composables/useIconStyle';
import HomeContainer from './HomeContainer.vue';
import RangeSlider from '../base/RangeSlider.vue';
import InputField from '../base/InputField.vue';
import ColorPicker from '../base/ColorPicker.vue';
import ResetButton from '../base/ResetButton.vue';
import HomeIconCustomizerIcons from './HomeIconCustomizerIcons.vue';
import Switch from '../base/Switch.vue';
import Card from '../base/Card.vue';
import useTrackStyleChanges from '../../composables/useTrackStyleChanges';
import { track } from '../../utils/openpanel';

const { color, strokeWidth, size, nonScalingStroke, isCustomized, resetStyle } = useIconStyle();

onMounted(() => {
  useTrackStyleChanges('home_customizer_change', { color, strokeWidth, size, nonScalingStroke });
});

function onReset() {
  track('home_customizer_reset');
  resetStyle();
}

const iconStyle = computed(() => ({
  '--home-icon-color': color.value,
  '--home-icon-stroke-width': String(strokeWidth.value),
  '--home-icon-size': String(size.value),
}));
</script>

<template>
  <HomeContainer>
    <Card class="customizer-card">
      <div class="card-column">
        <h2 class="title">
          Style as you please
          <ResetButton
            :disabled="!isCustomized"
            @click="onReset"
          />
        </h2>
        <p class="copy">
          Lucide has a lot of customization options to match the icons with your UI.
        </p>

        <div
          class="customizer"
          style="--color-picker-bg: var(--vp-input-switch-bg-color)"
        >
          <InputField
            id="icon-color"
            label="Color"
            class="color-picker-field"
          >
            <template #display>
              <ColorPicker
                v-model="color"
                id="icon-color-picker"
              />
            </template>
          </InputField>

          <InputField
            id="stroke-width"
            label="Stroke width"
          >
            <template #display>
              <span class="customize-label">{{ strokeWidth }}px</span>
            </template>
            <RangeSlider
              id="stroke-width-slider"
              name="stroke-width"
              v-model="strokeWidth"
              :min="1"
              :max="3"
              :step="0.25"
            />
          </InputField>

          <InputField
            id="size"
            label="Size"
          >
            <template #display>
              <span class="customize-label">{{ size }}px</span>
            </template>
            <RangeSlider
              id="size-slider"
              name="size"
              v-model="size"
              :min="16"
              :max="48"
              :step="4"
            />
          </InputField>

          <InputField
            id="non-scaling-stroke"
            label="Non-scaling stroke"
          >
            <template #display>
              <Switch
                id="non-scaling-stroke-switch"
                name="non-scaling-stroke"
                v-model="nonScalingStroke"
              />
            </template>
          </InputField>
        </div>
      </div>

      <div class="icons-container card-column">
        <HomeIconCustomizerIcons
          :class="{ 'non-scaling-stroke': nonScalingStroke }"
          :style="iconStyle"
        />
      </div>
    </Card>
  </HomeContainer>
</template>

<style scoped>
.customizer-card {
  display: flex;
  height: 100%;
  padding: 24px;
  --slider-bar-color: var(--vp-c-bg-soft-down);
  --color-picker-bg: var(--vp-c-bg-soft-down);
}

.title {
  line-height: 32px;
  font-size: 24px;
  font-weight: 600;
  display: flex;
  flex-direction: row;
  gap: 8px;
  justify-content: space-between;
  align-items: center;
}

.copy {
  padding-top: 8px;
  line-height: 24px;
  font-size: 14px;
  font-weight: 500;
  color: var(--vp-c-text-2);
}

.customizer {
  margin-top: 32px;
  padding: 0;
  background: none;
}

@media (min-width: 640px) {
  .card {
    display: grid;
    grid-template-columns: 8fr 10fr;
  }
}

@media (min-width: 960px) {
  .card {
    grid-template-columns: 1fr 2fr;
  }
}

.color-picker-field:deep(.icon-color-picker-input) {
  width: 116px;
}
</style>
