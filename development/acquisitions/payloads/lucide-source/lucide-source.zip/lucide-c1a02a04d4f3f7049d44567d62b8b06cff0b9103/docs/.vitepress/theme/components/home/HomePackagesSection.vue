<script setup lang="ts">
import HomeContainer from './HomeContainer.vue';
import HomeSectionTitle from './HomeSectionTitle.vue';
import { useRouter } from 'vitepress';
import { data } from './HomePackagesSection.data';
import VPButton from 'vitepress/dist/client/theme-default/components/VPButton.vue';
import { track } from '../../utils/openpanel';

const { go } = useRouter();

function onPackageClick(name: string, path: string) {
  track('home_package_click', { package: name });
  go(path);
}
</script>

<template>
  <HomeContainer>
    <HomeSectionTitle>Available For:</HomeSectionTitle>
    <div class="packages-list">
      <a
        v-for="{ name, label, path, logo, logoDark } in data.packages"
        :href="path"
        class="package-logo"
        @click.prevent="onPackageClick(name, path)"
      >
        <img
          :src="logo"
          :class="{ light: logoDark, 'image-logo': true }"
          :alt="label"
          loading="lazy"
        />
        <img
          v-if="logoDark"
          :src="logoDark"
          :alt="label"
          class="image-logo dark"
          loading="lazy"
        />
      </a>
    </div>
    <div class="more-button-wrapper">
      <VPButton
        text="And more"
        href="/packages"
        theme="alt"
        class="more-button"
        @click="track('home_packages_more_click')"
      />
    </div>
  </HomeContainer>
</template>

<style scoped>
.image-logo {
  object-fit: contain;
  width: 36px;
  height: 36px;
}

.packages-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  margin: 0 -0.5rem;
  gap: 16px;
}

.more-button-wrapper {
  margin-top: 24px;
  display: flex;
  justify-content: center;
}

.package-logo {
  transition: opacity ease-in 0.15s;
}

.package-logo:hover {
  opacity: 0.6;
}

html.dark .image-logo.light {
  display: none;
}
html:not(.dark) .image-logo.dark {
  display: none;
}
</style>
