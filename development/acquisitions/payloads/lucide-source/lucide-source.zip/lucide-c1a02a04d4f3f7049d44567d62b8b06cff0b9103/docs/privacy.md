---
title: Privacy Statement
description: How lucide.dev handles your data, which services we use, and what is stored in your browser.
aside: false
editLink: false
---

# Privacy Statement

_Last updated: 10 November 2026_

Lucide is an open-source project. We built lucide.dev to collect as little about you as possible: We aim to collect as little personal data as possible. We don't sell your personal data, and we don't require an account to browse our website. This page explains what does happen when you visit, and why.

This statement covers **lucide.dev** only. Our merch shop (merch.lucide.dev), GitHub, Discord, Open Collective and other sites we link to have their own privacy policies.

## Who is responsible

lucide.dev is run by the Lucide Icons, based in the Netherlands. For questions about this statement or your data, contact us at [info@lucide.dev](mailto:info@lucide.dev).

## What we collect and why

### Hosting

The site runs on [Vercel](https://vercel.com/legal/privacy-policy). Like any web server, Vercel processes your IP address, browser user agent and the pages you request so it can deliver the site and protect it against abuse. These logs are stored for 1 day and are not used to profile you.

### Analytics

We use privacy-friendly analytics to see which pages and icons are popular, so we know what to improve. We run **OpenPanel** on our own subdomain (insights.lucide.dev), and the data it collects is stored in the EU. It counts page views and how the site is used: which icons are copied or opened in Lucide Studio, when an icon search starts, changes to the icon customiser and sorting, clicks on the home page buttons and packages, clicks on early access menu items, waitlist sign-ups, and how far down a page you scroll.

OpenPanel doesn't set cookies or store anything in your browser. Along with these events it records general information such as the referring site, browser type, device type and country. Visits are counted with a temporary, anonymised identifier that cannot be used to recognise you on other sites or on later days. We don't track clicks on outgoing links, and we never combine this data with other sources.

### Waitlists

When you join a waitlist, we store your email address, the product you signed up for, the date, and any answers you give on the form or in the optional follow-up questions. We use this to send you launch updates for that product and to decide what to build. You are only added after you click the link in the confirmation email.

Emails and contacts are handled by [Resend](https://resend.com/legal/privacy-policy), our email provider, which acts as our processor. The optional follow-up questions are handled by [Tally](https://tally.so/help/gdpr), a Belgian form provider that stores responses in the EU and also acts as our processor. You can unsubscribe from any email. We keep your details until the waitlist closes or you ask us to delete them, whichever comes first.

### Search

Site search is provided by [Algolia DocSearch](https://www.algolia.com/policies/privacy/). When you use the search box, what you type and your IP address are sent to Algolia to return results. Your recent searches are kept in your own browser (see below).

### Advertising

On some pages, a single ad is shown by [Carbon Ads](https://www.carbonads.net/privacy) (BuySellAds). The ads help fund the project's development. Ads are chosen by the content of the page, not by your interests or browsing history. To show an ad, count impressions and clicks, and prevent fraud, Carbon receives your IP address (used to estimate your country) and basic browser information. Carbon's privacy policy describes how it handles this data.

### Third-party images

Contributor and team avatars are loaded directly from GitHub, so GitHub receives your IP address when those images load. See [GitHub's privacy statement](https://docs.github.com/site-policy/privacy-policies/github-general-privacy-statement).

The version and download badges on the packages page are loaded from [Shields.io](https://shields.io), so Shields.io receives your IP address when those images load.

## Cookies and browser storage

lucide.dev does not use tracking or advertising cookies of its own.

| What | Type | Purpose | Duration |
| --- | --- | --- | --- |
| Deployment version (`__vdpl`) | Cookie (Vercel) | Keeps you on the same version of the site while it's being updated, so pages don't break mid-visit | Session |
| Icon customiser settings | Local storage | Remembers the size, stroke width, colour and stroke scaling you chose | Until you clear them |
| Appearance | Local storage | Remembers light or dark mode | Until you clear them |
| Framework choice | Local storage | Remembers which framework you're reading the docs for | Until you clear them |
| Recent and favourite searches | Local storage | Shows them in the search box | Until you clear them |

These items are needed for features you use, or they store choices you made yourself. They never leave your browser, and you can clear them at any time in your browser settings.

## Legal basis

We process this data on the basis of our legitimate interest (Article 6(1)(f) GDPR) in running a fast, secure and sustainable website: hosting and protecting the site, understanding how it is used, and funding the project through non-tracking ads. We keep data minimal and avoid identifying individual visitors.

Waitlist data is processed on the basis of your consent (Article 6(1)(a) GDPR), which you give by submitting the form and confirming your email address. You can withdraw it at any time by unsubscribing or contacting us.

## International transfers

Vercel, Algolia, Carbon Ads, GitHub, Shields.io and Resend may process data outside the European Economic Area, including in the United States. Where this happens, these providers rely on safeguards such as the EU–US Data Privacy Framework or the European Commission's Standard Contractual Clauses.

## Your rights

Under the GDPR you have the right to access, correct or delete your personal data, to restrict or object to its processing, and to data portability. Because we don't link analytics data to individuals, we usually can't find data that belongs to you specifically, but we're happy to help. Contact us at [info@lucide.dev](mailto:info@lucide.dev).

You also have the right to file a complaint with a data protection authority. In the Netherlands, that is the [Autoriteit Persoonsgegevens](https://autoriteitpersoonsgegevens.nl).

## Changes

If we add new services or change how we handle data, we'll update this page and the date at the top. The full history of this page is available in our [GitHub repository](https://github.com/lucide-icons/lucide/commits/main/docs/privacy.md).
